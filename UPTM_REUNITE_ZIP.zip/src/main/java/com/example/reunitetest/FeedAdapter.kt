package com.example.reunitetest.adapter

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.reunitetest.R
import com.example.reunitetest.data.DatabaseRepository
import com.example.reunitetest.data.FeedItem
import com.example.reunitetest.data.User
import com.example.reunitetest.MessagesActivity
import com.example.reunitetest.utils.NotificationHelper
import java.io.File
import android.app.Dialog
import android.util.Log

class FeedAdapter(
    private val context: Context,
    private var feedItems: List<FeedItem>,
    private val databaseRepository: DatabaseRepository,
    private val currentUser: User,
    private val onItemUpdate: () -> Unit,
    private val onCommentClick: (FeedItem) -> Unit
) : BaseAdapter() {

    // ==================== BASE ADAPTER METHODS ====================
    override fun getCount(): Int = feedItems.size
    override fun getItem(position: Int): FeedItem = feedItems[position]
    override fun getItemId(position: Int): Long = feedItems[position].id.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val itemView = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.item_feed, parent, false)

        val item = feedItems[position]
        bindItemView(itemView, item)
        return itemView
    }

    fun updateItems(newItems: List<FeedItem>) {
        feedItems = newItems
        notifyDataSetChanged()
    }

    // ==================== ITEM VIEW BINDING ====================
    private fun bindItemView(itemView: View, item: FeedItem) {
        // Initialize views
        val userAvatar = itemView.findViewById<TextView>(R.id.user_avatar)
        val userName = itemView.findViewById<TextView>(R.id.user_name)
        val postTime = itemView.findViewById<TextView>(R.id.post_time)
        val itemTitle = itemView.findViewById<TextView>(R.id.item_title)
        val itemDescription = itemView.findViewById<TextView>(R.id.item_description)
        val itemLocation = itemView.findViewById<TextView>(R.id.item_location)
        val itemDate = itemView.findViewById<TextView>(R.id.item_date)
        val itemTime = itemView.findViewById<TextView>(R.id.item_time)
        val statusBadge = itemView.findViewById<TextView>(R.id.status_badge)
        val likeButton = itemView.findViewById<ImageButton>(R.id.like_button)
        val commentButton = itemView.findViewById<ImageButton>(R.id.comment_button)
        val shareButton = itemView.findViewById<ImageButton>(R.id.share_button)
        val messageButton = itemView.findViewById<ImageButton>(R.id.message_button)
        val likesCount = itemView.findViewById<TextView>(R.id.likes_count)
        val commentsCount = itemView.findViewById<TextView>(R.id.comments_count)
        val itemImage = itemView.findViewById<ImageView>(R.id.item_image)
        val flagButton = itemView.findViewById<ImageButton>(R.id.flag_button)
        val updateStatusButton = itemView.findViewById<Button>(R.id.update_status_button)

        // Set basic item data
        userAvatar.text = item.user.take(1).uppercase()
        userName.text = item.user
        postTime.text = item.postTime
        itemTitle.text = item.title
        itemDescription.text = item.description
        itemLocation.text = "📍 ${item.location}"
        itemDate.text = "📅 ${item.date}"
        itemTime.text = "⏰ ${item.time}"
        likesCount.text = item.likes.toString()
        commentsCount.text = item.comments.toString()

        // Load image
        loadImageForItem(item.id, itemImage)

        // Status badge
        statusBadge.text = item.status.uppercase()
        statusBadge.setBackgroundColor(
            ContextCompat.getColor(context,
                when (item.status.lowercase()) {
                    "lost" -> R.color.color_lost
                    "found" -> R.color.color_found
                    "reunited" -> R.color.color_success
                    "flagged" -> R.color.color_accent
                    "claimed" -> R.color.color_primary
                    else -> R.color.color_text_secondary
                }
            )
        )

        // Set up button listeners
        setupLikeButton(item, likeButton, likesCount)
        setupCommentButton(item, commentButton)
        setupShareButton(item, shareButton)
        setupMessageButton(item, messageButton)
        setupFlagButton(item, flagButton)
        setupUpdateStatusButton(item, updateStatusButton)
    }

    // ==================== IMAGE LOADING ====================
    private fun loadImageForItem(itemId: Int, imageView: ImageView) {
        Thread {
            try {
                val images = databaseRepository.getItemImages(itemId)
                if (images.isNotEmpty()) {
                    val firstImage = images[0]
                    (context as? android.app.Activity)?.runOnUiThread {
                        if (firstImage.startsWith("/")) {
                            val imageFile = File(firstImage)
                            if (imageFile.exists()) {
                                Glide.with(context)
                                    .load(imageFile.absolutePath)
                                    .placeholder(R.drawable.ic_placeholder)
                                    .error(R.drawable.ic_placeholder)
                                    .centerCrop()
                                    .into(imageView)
                                imageView.visibility = View.VISIBLE
                            } else {
                                imageView.visibility = View.GONE
                            }
                        } else {
                            imageView.visibility = View.GONE
                        }
                    }
                } else {
                    (context as? android.app.Activity)?.runOnUiThread {
                        imageView.visibility = View.GONE
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                (context as? android.app.Activity)?.runOnUiThread {
                    imageView.visibility = View.GONE
                }
            }
        }.start()
    }

    // ==================== BUTTON SETUP METHODS ====================
    private fun setupLikeButton(item: FeedItem, likeButton: ImageButton, likesCount: TextView) {
        updateLikeButton(likeButton, item.isLiked)
        likeButton.setOnClickListener {
            toggleLike(item, likeButton, likesCount)
        }
    }

    private fun setupCommentButton(item: FeedItem, commentButton: ImageButton) {
        commentButton.setOnClickListener {
            onCommentClick(item)
        }
    }

    private fun setupShareButton(item: FeedItem, shareButton: ImageButton) {
        shareButton.setOnClickListener {
            shareItem(item)
        }
    }

    // ==================== MESSAGE BUTTON SETUP ====================
    private fun setupMessageButton(item: FeedItem, messageButton: ImageButton) {
        // TEMP: Show on all posts for testing
        messageButton.visibility = View.VISIBLE
        messageButton.setImageResource(R.drawable.ic_messagesfeed)
        messageButton.contentDescription = "Message Poster"

        messageButton.setOnClickListener {
            if (item.isOwnPost) {
                Toast.makeText(context, "This is your own post", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // Directly open chat for both lost and found items
            openDirectMessage(item)
        }
    }

    // ==================== DIRECT MESSAGE FUNCTIONALITY ====================
    private fun openDirectMessage(item: FeedItem) {
        try {
            // Navigate directly to Messages page and open chat with this user
            navigateToMessagesPage(item.user)

            // Optional: You can still send an automatic intro message if you want
            sendQuickIntroMessage(item)

        } catch (e: Exception) {
            Log.e("FeedAdapter", "Error opening direct message: ${e.message}", e)
            Toast.makeText(context, "Error opening chat", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendQuickIntroMessage(item: FeedItem) {
        Thread {
            try {
                // Check if this is a new conversation before sending intro
                val existingMessages = databaseRepository.getConversationMessages(currentUser.name, item.user)

                if (existingMessages.isEmpty()) {
                    val introMessage = when (item.status.lowercase()) {
                        "found" -> "Hello! I'd like to claim this item: ${item.title}"
                        "lost" -> "Hello! I might have information about your lost item: ${item.title}"
                        else -> "Hello! I'm interested in your item: ${item.title}"
                    }

                    databaseRepository.addInAppMessage(
                        senderEmail = currentUser.email,
                        senderName = currentUser.name,
                        receiverName = item.user,
                        itemId = item.id.toLong(),
                        messageText = introMessage
                    )

                    Log.d("FeedAdapter", "Quick intro message sent to ${item.user}")
                }
            } catch (e: Exception) {
                Log.e("FeedAdapter", "Error sending quick intro: ${e.message}")
            }
        }.start()
    }

    private fun setupFlagButton(item: FeedItem, flagButton: ImageButton) {
        flagButton.setOnClickListener {
            showFlagDialog(item)
        }
    }

    // ==================== UPDATE STATUS BUTTON SETUP ====================
    private fun setupUpdateStatusButton(item: FeedItem, updateStatusButton: Button?) {
        // Show button based on status:
        // - "lost" -> "Mark as Found"
        // - "found" -> "Mark as ReUnite"
        when {
            item.isOwnPost && item.status.lowercase() == "lost" -> {
                updateStatusButton?.visibility = View.VISIBLE
                updateStatusButton?.text = "Mark as Found"
                updateStatusButton?.setOnClickListener {
                    showUpdateStatusDialog(item, "found")
                }
            }
            item.isOwnPost && item.status.lowercase() == "found" -> {
                updateStatusButton?.visibility = View.VISIBLE
                updateStatusButton?.text = "Mark as ReUnite"
                updateStatusButton?.setOnClickListener {
                    showUpdateStatusDialog(item, "reunited")
                }
            }
            else -> {
                updateStatusButton?.visibility = View.GONE
            }
        }
    }

    private fun showUpdateStatusDialog(item: FeedItem, newStatus: String) {
        val (title, message) = when (newStatus) {
            "found" -> Pair(
                "Update Item Status",
                "Have you found this item? This will change the status from 'Lost' to 'Found'."
            )
            "reunited" -> Pair(
                "Mark as ReUnite",
                "Has this item been reunited with its owner? This will mark the item as successfully reunited."
            )
            else -> Pair("Update Status", "Update item status?")
        }

        AlertDialog.Builder(context)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Yes") { dialog, _ ->
                updateItemStatus(item, newStatus)
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun updateItemStatus(item: FeedItem, newStatus: String) {
        Thread {
            try {
                // Update in database
                val result = databaseRepository.updateItemStatus(item.id, newStatus)
                
                (context as? android.app.Activity)?.runOnUiThread {
                    if (result > 0) {
                        // Update the item status in memory
                        item.status = newStatus
                        
                        val statusText = when (newStatus) {
                            "found" -> "Found"
                            "reunited" -> "ReUnited"
                            else -> newStatus.capitalize()
                        }
                        
                        Toast.makeText(context, "Item status updated to $statusText!", Toast.LENGTH_SHORT).show()
                        
                        // Create notification in database
                        databaseRepository.createNotification(
                            type = "status_update",
                            title = "Item Status Updated",
                            message = "Your item '${item.title}' has been marked as $statusText",
                            userId = currentUser.email,
                            category = item.category,
                            location = item.location,
                            itemId = item.itemId
                        )
                        
                        // Send push notification based on status
                        when (newStatus) {
                            "found" -> {
                                NotificationHelper.sendItemFoundNotification(
                                    context = context,
                                    itemTitle = item.title,
                                    location = item.location,
                                    itemId = item.itemId,
                                    userName = currentUser.name,
                                    userEmail = currentUser.email,
                                    userRole = currentUser.role
                                )
                            }
                            "reunited" -> {
                                NotificationHelper.sendItemReunitedNotification(
                                    context = context,
                                    itemTitle = item.title,
                                    itemId = item.itemId,
                                    userName = currentUser.name,
                                    userEmail = currentUser.email,
                                    userRole = currentUser.role
                                )
                            }
                            else -> {
                                NotificationHelper.sendStatusUpdateNotification(
                                    context = context,
                                    itemTitle = item.title,
                                    newStatus = statusText,
                                    itemId = item.itemId,
                                    userName = currentUser.name,
                                    userEmail = currentUser.email,
                                    userRole = currentUser.role
                                )
                            }
                        }
                        
                        // Trigger refresh to update the UI
                        onItemUpdate()
                    } else {
                        Toast.makeText(context, "Failed to update item status", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                Log.e("FeedAdapter", "Error updating status: ${e.message}", e)
                (context as? android.app.Activity)?.runOnUiThread {
                    Toast.makeText(context, "Error updating status", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    // ==================== LIKE FUNCTIONALITY ====================
    private fun toggleLike(item: FeedItem, likeButton: ImageButton, likesCount: TextView) {
        if (item.isLiked) {
            databaseRepository.removeLike(item.itemId, currentUser.email)
            item.likes--
            updateLikeButton(likeButton, false)
            item.isLiked = false
        } else {
            databaseRepository.addLike(item.itemId, currentUser.email)
            item.likes++
            updateLikeButton(likeButton, true)
            item.isLiked = true
        }
        likesCount.text = item.likes.toString()
        // Removed onItemUpdate() to prevent unnecessary refresh
    }

    private fun updateLikeButton(likeButton: ImageButton, isLiked: Boolean) {
        if (isLiked) {
            likeButton.setImageResource(R.drawable.ic_heart_outline)
            likeButton.setColorFilter(ContextCompat.getColor(context, R.color.color_accent))
        } else {
            likeButton.setImageResource(R.drawable.ic_heart_outline)
            likeButton.setColorFilter(ContextCompat.getColor(context, R.color.color_text_secondary))
        }
    }

    // ==================== SHARE FUNCTIONALITY ====================
    private fun shareItem(item: FeedItem) {
        val shareMessage = """
            ${if (item.status.lowercase() == "lost") "🚨 LOST ITEM" else "🎉 FOUND ITEM"}
            
            📋 ${item.title}
            📍 ${item.location}
            📅 ${item.date} at ${item.time}
            
            ${item.description}
            
            👤 Contact: ${item.user}
            
            ${if (item.status.lowercase() == "lost") "Please help find this item!" else "Please contact if this is yours!"}
        """.trimIndent()

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "${item.status.uppercase()}: ${item.title}")
            putExtra(Intent.EXTRA_TEXT, shareMessage)
        }

        context.startActivity(Intent.createChooser(shareIntent,
            if (item.status.lowercase() == "lost") "Share Lost Item" else "Share Found Item"
        ))
    }

    // ==================== FLAG/REPORT FUNCTIONALITY ====================
    private fun showFlagDialog(item: FeedItem) {
        AlertDialog.Builder(context)
            .setTitle("Report Item")
            .setMessage("Why are you reporting this item?")
            .setPositiveButton("Inappropriate Content") { dialog, _ ->
                flagItem(item, "Inappropriate Content")
                dialog.dismiss()
            }
            .setNeutralButton("False Information") { dialog, _ ->
                flagItem(item, "False Information")
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun flagItem(item: FeedItem, reason: String) {
        val result = databaseRepository.flagItem(item.id)
        if (result > 0) {
            Toast.makeText(context, "Item reported for review", Toast.LENGTH_SHORT).show()
            
            // Update the item status in the UI
            item.status = "flagged"
            
            databaseRepository.createNotification(
                type = "flag",
                title = "Item Flagged for Review",
                message = "Item '${item.title}' was flagged for: $reason",
                userId = "admin",
                category = item.category,
                location = item.location,
                itemId = item.itemId
            )
            
            // Trigger refresh to update the UI
            onItemUpdate()
        } else {
            Toast.makeText(context, "Failed to report item", Toast.LENGTH_SHORT).show()
        }
    }

    // ==================== MESSAGE/CHAT FUNCTIONALITY ====================
    private fun showClaimOptions(item: FeedItem) {
        val options = arrayOf("💬 Message Poster", "📋 Submit Claim Proof", "🔍 How to Verify?")

        AlertDialog.Builder(context)
            .setTitle("Claim Item: ${item.title}")
            .setMessage("Untuk barang yang dijumpai, sila hubungi poster dahulu atau hantar bukti pemilikan")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> openInAppChat(item)
                    1 -> showVerificationDialog(item)
                    2 -> showVerificationGuide()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openInAppChat(item: FeedItem) {
        try {
            // Send an automatic introductory message first
            val introMessage = "Hello! I'm interested in your ${item.status} item: ${item.title}"

            val result = databaseRepository.addInAppMessage(
                senderEmail = currentUser.email,
                senderName = currentUser.name,
                receiverName = item.user,
                itemId = item.id.toLong(),
                messageText = introMessage
            )

            if (result != -1L) {
                // Get poster's user ID properly
                val posterUserId = databaseRepository.getUserIdByUserName(item.user) ?: "general"

                // Create notification for the receiver
                databaseRepository.createNotification(
                    type = "message",
                    title = "New Message from ${currentUser.name}",
                    message = "Regarding your item: ${item.title}",
                    userId = posterUserId,
                    category = item.category,
                    location = item.location,
                    itemId = item.itemId
                )

                Log.d("FeedAdapter", "Intro message sent successfully to ${item.user}")

                // Navigate directly to Messages page and open chat with this user
                navigateToMessagesPage(item.user)
            } else {
                Log.e("FeedAdapter", "Failed to send intro message to database")
                Toast.makeText(context, "Failed to start conversation", Toast.LENGTH_SHORT).show()
                sendEmailToPoster(item) // Fallback to email
            }
        } catch (e: Exception) {
            Log.e("FeedAdapter", "Error starting conversation: ${e.message}", e)
            Toast.makeText(context, "Error starting conversation", Toast.LENGTH_SHORT).show()
            sendEmailToPoster(item) // Fallback to email
        }
    }

    private fun navigateToMessagesPage(otherUser: String? = null) {
        try {
            val intent = Intent(context, MessagesActivity::class.java)
            intent.putExtra("USER_NAME", currentUser.name)
            intent.putExtra("USER_EMAIL", currentUser.email)
            intent.putExtra("USER_ROLE", currentUser.role)

            // If we have a specific user to chat with, pass it along
            if (!otherUser.isNullOrEmpty()) {
                intent.putExtra("OTHER_USER", otherUser)
                intent.putExtra("OPEN_CHAT_DIRECTLY", true)
            }

            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("FeedAdapter", "Error navigating to messages: ${e.message}", e)
            Toast.makeText(context, "Error opening messages", Toast.LENGTH_SHORT).show()
        }
    }

    // ==================== VERIFICATION FUNCTIONALITY ====================
    private fun showVerificationDialog(item: FeedItem) {
        val dialog = Dialog(context)
        dialog.setContentView(R.layout.dialog_verification)

        val proofInput = dialog.findViewById<EditText>(R.id.proof_input)
        val submitButton = dialog.findViewById<Button>(R.id.submit_button)
        val cancelButton = dialog.findViewById<Button>(R.id.cancel_button)

        submitButton.setOnClickListener {
            val proof = proofInput.text.toString().trim()
            if (proof.isNotEmpty()) {
                databaseRepository.addVerificationRequest(
                    itemId = item.id,
                    claimantEmail = currentUser.email,
                    proofDescription = proof
                )
                Toast.makeText(context, "Tuntutan dihantar untuk semakan", Toast.LENGTH_SHORT).show()
                dialog.dismiss()

                // Notify poster
                databaseRepository.createNotification(
                    type = "verification",
                    title = "Tuntutan Baru untuk '${item.title}'",
                    message = "${currentUser.name} menuntut barang ini. Sila semak butiran.",
                    userId = "poster",
                    category = item.category,
                    location = item.location,
                    itemId = item.itemId
                )
            } else {
                Toast.makeText(context, "Sila berikan bukti pemilikan", Toast.LENGTH_SHORT).show()
            }
        }

        cancelButton.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun showVerificationGuide() {
        AlertDialog.Builder(context)
            .setTitle("🔍 Cara Mengesahkan Pemilikan")
            .setMessage("""
            Untuk mengesahkan barang adalah milik anda, sediakan:
            
            ✅ Resit pembelian
            ✅ Gambar barang dengan anda
            ✅ Butiran khusus (serial number, etc.)
            ✅ Sebarang bukti pemilikan lain
            
            Selepas hantar bukti, poster akan hubungi anda untuk pengesahan.
            
            Tips: Sentiasa berjumpa di tempat selamat & awam!
        """.trimIndent())
            .setPositiveButton("Faham", null)
            .show()
    }

    // ==================== EMAIL FALLBACK FUNCTIONALITY ====================
    private fun sendEmailToPoster(item: FeedItem) {
        val dbItem = databaseRepository.getItemById(item.id)
        var contactEmail = dbItem?.contactEmail ?: ""

        // If contact email is empty or invalid, create a fallback
        if (contactEmail.isEmpty() || !contactEmail.contains("@")) {
            contactEmail = "${item.user.replace(" ", ".").lowercase()}@student.uptm.edu.my"
        }

        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$contactEmail")
            putExtra(Intent.EXTRA_SUBJECT, "Regarding your ${item.status} item: ${item.title}")
            putExtra(Intent.EXTRA_TEXT, """
            Hello ${item.user},
            
            I saw your ${item.status} item "${item.title}" on ReUnite App.
            
            Item Details:
            - Category: ${item.category}
            - Location: ${item.location} 
            - Date: ${item.date} at ${item.time}
            
            ${if (item.status.lowercase() == "lost")
                "I think I might have found your item!"
            else
                "I believe this might be my lost item!"
            }
            
            Please contact me so we can discuss further.
            
            Best regards,
            ${currentUser.name}
        """.trimIndent())
        }

        try {
            context.startActivity(Intent.createChooser(emailIntent, "Send Email via..."))
        } catch (e: Exception) {
            Toast.makeText(context, "No email app found", Toast.LENGTH_SHORT).show()
        }
    }
}