package com.example.reunitetest

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import android.view.View
import android.graphics.Color
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.reunitetest.data.DatabaseRepository
import com.example.reunitetest.data.User
import com.example.reunitetest.utils.ImageUploadHelper
import com.example.reunitetest.utils.NotificationHelper
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.*

class ReportItemActivity : AppCompatActivity() {
    
    companion object {
        private const val CAMERA_PERMISSION_CODE = 100
    }

    private lateinit var typeLostButton: Button
    private lateinit var typeFoundButton: Button
    private lateinit var titleEditText: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var descriptionEditText: EditText
    private lateinit var locationSpinner: Spinner
    private lateinit var dateEditText: EditText
    private lateinit var timeEditText: EditText
    private lateinit var contactInfoEditText: EditText
    private lateinit var submitButton: Button
    private lateinit var backButton: ImageButton

    private lateinit var imageContainer: LinearLayout
    private lateinit var cameraButton: Button
    private lateinit var galleryButton: Button
    private lateinit var imageUploadHelper: ImageUploadHelper
    private val selectedImages = mutableListOf<Uri>()

    private var selectedType = ""

    private val categories = arrayOf(
        "Electronics", "Personal Items", "Documents", "Keys",
        "Jewelry", "Clothing", "Books/Stationery", "Sports Equipment", "Other"
    )

    private val locations = arrayOf(
        "Library Level 1", "Library Level 2", "Library Level 3",
        "Cafeteria", "Lecture Hall A", "Lecture Hall B", "Computer Lab 1",
        "Computer Lab 2", "Parking Area A", "Parking Area B", "Main Entrance",
        "Student Center", "Administration Building", "Sports Complex"
    )

    // Database
    private lateinit var databaseRepository: DatabaseRepository
    private lateinit var user: User

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report_item)

        initializeViews()
        databaseRepository = DatabaseRepository.getInstance(this)
        initializeUserData()
        setupSpinners()
        setupClickListeners()

        contactInfoEditText.setText(user.email)
    }

    private fun initializeViews() {
        typeLostButton = findViewById(R.id.type_lost_button)
        typeFoundButton = findViewById(R.id.type_found_button)
        titleEditText = findViewById(R.id.title_edittext)
        categorySpinner = findViewById(R.id.category_spinner)
        descriptionEditText = findViewById(R.id.description_edittext)
        locationSpinner = findViewById(R.id.location_spinner)
        dateEditText = findViewById(R.id.date_edittext)
        timeEditText = findViewById(R.id.time_edittext)
        contactInfoEditText = findViewById(R.id.contact_info_edittext)
        submitButton = findViewById(R.id.submit_button)
        backButton = findViewById(R.id.back_button)
        imageContainer = findViewById(R.id.image_container)
        cameraButton = findViewById(R.id.camera_button)
        galleryButton = findViewById(R.id.gallery_button)

        backButton.setOnClickListener {
            Toast.makeText(this, "Cancelling report...", Toast.LENGTH_SHORT).show()
            finish()
        }

        imageUploadHelper = ImageUploadHelper(this)

        cameraButton.setOnClickListener {
            checkCameraPermissionAndTakePhoto()
        }

        galleryButton.setOnClickListener {
            imageUploadHelper.chooseFromGallery()
        }

        typeLostButton.setOnClickListener { selectType("lost") }
        typeFoundButton.setOnClickListener { selectType("found") }

        // Set initial button styles
        updateTypeButtonStyles()

        titleEditText.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) updateSubmitButton()
        }

        descriptionEditText.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) updateSubmitButton()
        }

        contactInfoEditText.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) updateSubmitButton()
        }

        submitButton.setOnClickListener { submitReport() }

        setupRealTimeValidation()
    }

    private fun updateTypeButtonStyles() {
        val defaultColor = ContextCompat.getColor(this, R.color.gray_50)
        val lostColor = ContextCompat.getColor(this, R.color.color_lost)
        val foundColor = ContextCompat.getColor(this, R.color.color_found)

        // Reset both buttons to default first
        typeLostButton.setBackgroundColor(defaultColor)
        typeFoundButton.setBackgroundColor(defaultColor)

        // Then apply selected colors
        when (selectedType) {
            "lost" -> {
                typeLostButton.setBackgroundColor(lostColor)
                typeLostButton.setTextColor(ContextCompat.getColor(this, android.R.color.white))
                typeFoundButton.setTextColor(ContextCompat.getColor(this, R.color.color_black))
            }
            "found" -> {
                typeFoundButton.setBackgroundColor(foundColor)
                typeFoundButton.setTextColor(ContextCompat.getColor(this, android.R.color.white))
                typeLostButton.setTextColor(ContextCompat.getColor(this, R.color.color_black))
            }
            else -> {
                // Both buttons grey with black text
                typeLostButton.setTextColor(ContextCompat.getColor(this, R.color.color_black))
                typeFoundButton.setTextColor(ContextCompat.getColor(this, R.color.color_black))
            }
        }
    }

    private fun selectType(type: String) {
        selectedType = type
        updateTypeButtonStyles()
        updateSubmitButton()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        val imageUri = imageUploadHelper.handleActivityResult(requestCode, resultCode, data)
        imageUri?.let { uri ->
            if (selectedImages.size >= 5) {
                Toast.makeText(this, "Maximum 5 images allowed", Toast.LENGTH_SHORT).show()
                return
            }

            val compressedUri = compressImage(uri)
            compressedUri?.let { compressed ->
                if (!selectedImages.contains(compressed)) {
                    selectedImages.add(compressed)
                    addImageToContainerView(compressed)
                    updateSubmitButton()
                }
            }
        }
    }

    private fun addImageToContainerView(uri: Uri) {
        val imageLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(150, 150).apply {
                marginEnd = 12
            }
        }

        val imageView = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                120
            )
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = ContextCompat.getDrawable(this@ReportItemActivity, R.drawable.edit_text_background)
        }

        Glide.with(this)
            .load(uri)
            .placeholder(R.drawable.ic_placeholder)
            .error(R.drawable.ic_placeholder)
            .centerCrop()
            .into(imageView)

        val removeButton = TextView(this).apply {
            text = "✕"
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = android.view.Gravity.CENTER
            setBackgroundColor(Color.RED)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                30
            )
            setOnClickListener {
                selectedImages.remove(uri)
                imageContainer.removeView(imageLayout)
                updateSubmitButton()
            }
        }

        imageLayout.addView(imageView)
        imageLayout.addView(removeButton)
        imageContainer.addView(imageLayout)
    }

    private fun setupRealTimeValidation() {
        val textWatcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                updateSubmitButton()
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        }

        titleEditText.addTextChangedListener(textWatcher)
        descriptionEditText.addTextChangedListener(textWatcher)
        contactInfoEditText.addTextChangedListener(textWatcher)
    }

    private fun initializeUserData() {
        val userName = intent.getStringExtra("USER_NAME") ?: "User"
        val userRole = intent.getStringExtra("USER_ROLE") ?: "student"
        val userEmail = intent.getStringExtra("USER_EMAIL") ?: "user@student.uptm.edu.my"
        val studentId = intent.getStringExtra("USER_ID") ?: "STU12345"

        user = User(userName, userRole, userEmail, studentId)
    }

    private fun setupSpinners() {
        val categoryAdapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_item,
            categories
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                (view as TextView).setTextColor(Color.BLACK)
                return view
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getDropDownView(position, convertView, parent)
                (view as TextView).setTextColor(Color.BLACK)
                view.setBackgroundColor(Color.WHITE)
                return view
            }
        }

        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = categoryAdapter

        val locationAdapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_item,
            locations
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                (view as TextView).setTextColor(Color.BLACK)
                return view
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getDropDownView(position, convertView, parent)
                (view as TextView).setTextColor(Color.BLACK)
                view.setBackgroundColor(Color.WHITE)
                return view
            }
        }

        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        locationSpinner.adapter = locationAdapter

        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                updateSubmitButton()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        locationSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                updateSubmitButton()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupClickListeners() {
        dateEditText.setOnClickListener {
            showDatePicker()
        }

        timeEditText.setOnClickListener {
            showTimePicker()
        }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePicker = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            val selectedDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
            dateEditText.setText(selectedDate)
            dateEditText.setTextColor(Color.BLACK)
            updateSubmitButton()
        }, year, month, day)

        datePicker.datePicker.maxDate = System.currentTimeMillis()
        datePicker.show()
    }

    private fun showTimePicker() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        val timePicker = TimePickerDialog(this, { _, selectedHour, selectedMinute ->
            val timeFormat = String.format("%02d:%02d", selectedHour, selectedMinute)
            timeEditText.setText(timeFormat)
            timeEditText.setTextColor(Color.BLACK)
            updateSubmitButton()
        }, hour, minute, true)

        timePicker.show()
    }

    private fun updateSubmitButton() {
        val isFormValid = selectedType.isNotEmpty() &&
                titleEditText.text.toString().trim().isNotEmpty() &&
                categorySpinner.selectedItemPosition >= 0 &&
                descriptionEditText.text.toString().trim().isNotEmpty() &&
                locationSpinner.selectedItemPosition >= 0 &&
                dateEditText.text.toString().isNotEmpty() &&
                timeEditText.text.toString().isNotEmpty() &&
                contactInfoEditText.text.toString().trim().isNotEmpty() &&
                android.util.Patterns.EMAIL_ADDRESS.matcher(contactInfoEditText.text.toString().trim()).matches()

        submitButton.isEnabled = isFormValid

        // Visual feedback for submit button
        if (isFormValid) {
            submitButton.setBackgroundColor(ContextCompat.getColor(this, R.color.color_primary))
            submitButton.setTextColor(Color.WHITE)
        } else {
            submitButton.setBackgroundColor(ContextCompat.getColor(this, R.color.color_text_secondary))
            submitButton.setTextColor(ContextCompat.getColor(this, R.color.gray_600))
        }
    }

    private fun submitReport() {
        if (!submitButton.isEnabled) return

        val title = titleEditText.text.toString().trim()
        val category = categorySpinner.selectedItem.toString()
        val description = descriptionEditText.text.toString().trim()
        val location = locationSpinner.selectedItem.toString()
        val date = dateEditText.text.toString()
        val time = timeEditText.text.toString()
        val contactInfo = contactInfoEditText.text.toString().trim()

        val imagePaths = selectedImages.map { uri ->
            saveImageToFile(uri)
        }.filter { it.isNotEmpty() }

        submitButton.text = "Submitting Report..."
        submitButton.isEnabled = false

        val newItem = DatabaseRepository.Item(
            id = 0,
            title = title,
            category = category,
            description = description,
            location = location,
            date = date,
            time = time,
            status = selectedType,
            type = selectedType,
            reportedBy = user.name,
            contactEmail = contactInfo,
            images = imagePaths,
            timeAgo = "Just now"
        )

        val result = databaseRepository.insertItem(newItem)

        Handler(Looper.getMainLooper()).postDelayed({
            if (result != -1L) {
                val reportType = if (selectedType == "lost") "Lost" else "Found"
                val successMessage = "✅ $reportType item report submitted successfully!\n\n" +
                        "📦 Item: $title\n" +
                        "📁 Category: $category\n" +
                        "📍 Location: $location\n" +
                        "📅 Date: $date at $time"

                Toast.makeText(this, successMessage, Toast.LENGTH_LONG).show()

                // Save notification to database
                databaseRepository.createNotification(
                    type = "update",
                    title = "Report Submitted Successfully",
                    message = "Your $reportType item report for \"$title\" has been submitted.",
                    userId = user.email,
                    category = category,
                    location = location
                )

                // Send push notification
                NotificationHelper.sendReportUploadNotification(
                    context = this,
                    reportType = reportType,
                    itemTitle = title,
                    category = category,
                    location = location,
                    userName = user.name,
                    userEmail = user.email,
                    userRole = user.role
                )

                Handler(Looper.getMainLooper()).postDelayed({
                    Toast.makeText(this, "🎉 Report submitted! Returning to previous screen...", Toast.LENGTH_SHORT).show()
                    finish()
                }, 500)

            } else {
                Toast.makeText(this, "❌ Failed to submit report. Please check your connection and try again.", Toast.LENGTH_LONG).show()
                submitButton.text = "Submit Report"
                updateSubmitButton()
            }
        }, 1500)
    }

    private fun saveImageToFile(uri: Uri): String {
        return try {
            val inputStream = contentResolver.openInputStream(uri)
            val file = File(filesDir, "image_${System.currentTimeMillis()}.jpg")
            val outputStream = FileOutputStream(file)

            inputStream?.copyTo(outputStream)
            inputStream?.close()
            outputStream.close()

            file.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    private fun compressImage(uri: Uri): Uri? {
        return try {
            val inputStream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, outputStream)

            val file = File(filesDir, "compressed_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { fos ->
                fos.write(outputStream.toByteArray())
            }

            Uri.fromFile(file)
        } catch (e: Exception) {
            e.printStackTrace()
            uri
        }
    }

    private fun checkCameraPermissionAndTakePhoto() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) 
            != PackageManager.PERMISSION_GRANTED) {
            // Request camera permission
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_CODE
            )
        } else {
            // Permission already granted
            imageUploadHelper.takePhoto()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            CAMERA_PERMISSION_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission granted, take photo
                    imageUploadHelper.takePhoto()
                } else {
                    Toast.makeText(this, "Camera permission is required to take photos", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onBackPressed() {
        Toast.makeText(this, "Report cancelled", Toast.LENGTH_SHORT).show()
        super.onBackPressed()
    }
}