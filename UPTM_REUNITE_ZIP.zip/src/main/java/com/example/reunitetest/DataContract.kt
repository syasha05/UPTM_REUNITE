package com.example.reunitetest.data

import android.provider.BaseColumns

object DataContract {

    object UserEntry : BaseColumns {
        const val TABLE_NAME = "users"
        const val COLUMN_USER_ID = "user_id"
        const val COLUMN_NAME = "name"
        const val COLUMN_EMAIL = "email"
        const val COLUMN_ROLE = "role"
        const val COLUMN_STUDENT_ID = "student_id"
        const val COLUMN_CREATED_AT = "created_at"
    }

    object ItemEntry : BaseColumns {
        const val TABLE_NAME = "items"
        const val COLUMN_ITEM_ID = "item_id"
        const val COLUMN_TITLE = "title"
        const val COLUMN_DESCRIPTION = "description"
        const val COLUMN_CATEGORY = "category"
        const val COLUMN_LOCATION = "location"
        const val COLUMN_DATE = "date"
        const val COLUMN_TIME = "time"
        const val COLUMN_STATUS = "status" // lost or found
        const val COLUMN_TYPE = "type" // lost or found
        const val COLUMN_REPORTED_BY = "reported_by"
        const val COLUMN_CONTACT_EMAIL = "contact_email"
        const val COLUMN_IMAGES = "images"
        const val COLUMN_CREATED_AT = "created_at"
        const val COLUMN_IS_ACTIVE = "is_active"
    }

    object NotificationEntry : BaseColumns {
        const val TABLE_NAME = "notifications"
        const val COLUMN_NOTIFICATION_ID = "notification_id"
        const val COLUMN_TYPE = "type" // match, update, reminder
        const val COLUMN_TITLE = "title"
        const val COLUMN_MESSAGE = "message"
        const val COLUMN_TIMESTAMP = "timestamp"
        const val COLUMN_IS_READ = "is_read"
        const val COLUMN_CATEGORY = "category"
        const val COLUMN_LOCATION = "location"
        const val COLUMN_ITEM_ID = "item_id"
        const val COLUMN_USER_ID = "user_id"
    }

    object ReportEntry : BaseColumns {
        const val TABLE_NAME = "reports"
        const val COLUMN_REPORT_ID = "report_id"
        const val COLUMN_USER_ID = "user_id"
        const val COLUMN_ITEM_ID = "item_id"
        const val COLUMN_REPORT_TYPE = "report_type" // lost or found
        const val COLUMN_STATUS = "status" // active, resolved, reunited
        const val COLUMN_CREATED_AT = "created_at"
        const val COLUMN_UPDATED_AT = "updated_at"
    }

    object LikeEntry : BaseColumns {
        const val TABLE_NAME = "likes"
        const val COLUMN_LIKE_ID = "like_id"
        const val COLUMN_ITEM_ID = "item_id"
        const val COLUMN_USER_ID = "user_id"
        const val COLUMN_CREATED_AT = "created_at"
    }

    object CommentEntry : BaseColumns {
        const val TABLE_NAME = "comments"
        const val COLUMN_COMMENT_ID = "comment_id"
        const val COLUMN_ITEM_ID = "item_id"
        const val COLUMN_USER_ID = "user_id"
        const val COLUMN_USER_NAME = "user_name"
        const val COLUMN_COMMENT_TEXT = "comment_text"
        const val COLUMN_CREATED_AT = "created_at"
    }
}