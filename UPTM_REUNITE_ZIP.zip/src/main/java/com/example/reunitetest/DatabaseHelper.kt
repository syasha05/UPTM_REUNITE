package com.example.reunitetest.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.BaseColumns

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "reunite.db"
        const val DATABASE_VERSION = 5 // Fixed duplicate table creation
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Create users table
        val createUserTable = """
            CREATE TABLE ${DataContract.UserEntry.TABLE_NAME} (
                ${BaseColumns._ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${DataContract.UserEntry.COLUMN_USER_ID} TEXT UNIQUE NOT NULL,
                ${DataContract.UserEntry.COLUMN_NAME} TEXT NOT NULL,
                ${DataContract.UserEntry.COLUMN_EMAIL} TEXT UNIQUE NOT NULL,
                ${DataContract.UserEntry.COLUMN_ROLE} TEXT NOT NULL,
                ${DataContract.UserEntry.COLUMN_STUDENT_ID} TEXT,
                ${DataContract.UserEntry.COLUMN_CREATED_AT} TEXT NOT NULL
            )
        """.trimIndent()

        // Create items table
        val createItemTable = """
            CREATE TABLE ${DataContract.ItemEntry.TABLE_NAME} (
                ${BaseColumns._ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${DataContract.ItemEntry.COLUMN_ITEM_ID} TEXT UNIQUE NOT NULL,
                ${DataContract.ItemEntry.COLUMN_TITLE} TEXT NOT NULL,
                ${DataContract.ItemEntry.COLUMN_DESCRIPTION} TEXT NOT NULL,
                ${DataContract.ItemEntry.COLUMN_CATEGORY} TEXT NOT NULL,
                ${DataContract.ItemEntry.COLUMN_LOCATION} TEXT NOT NULL,
                ${DataContract.ItemEntry.COLUMN_DATE} TEXT NOT NULL,
                ${DataContract.ItemEntry.COLUMN_TIME} TEXT NOT NULL,
                ${DataContract.ItemEntry.COLUMN_STATUS} TEXT NOT NULL,
                ${DataContract.ItemEntry.COLUMN_TYPE} TEXT NOT NULL,
                ${DataContract.ItemEntry.COLUMN_REPORTED_BY} TEXT NOT NULL,
                ${DataContract.ItemEntry.COLUMN_CONTACT_EMAIL} TEXT NOT NULL,
                ${DataContract.ItemEntry.COLUMN_IMAGES} TEXT,
                ${DataContract.ItemEntry.COLUMN_CREATED_AT} TEXT NOT NULL,
                ${DataContract.ItemEntry.COLUMN_IS_ACTIVE} INTEGER DEFAULT 1
            )
        """.trimIndent()

        // Create notifications table
        val createNotificationTable = """
            CREATE TABLE ${DataContract.NotificationEntry.TABLE_NAME} (
                ${BaseColumns._ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${DataContract.NotificationEntry.COLUMN_NOTIFICATION_ID} TEXT UNIQUE NOT NULL,
                ${DataContract.NotificationEntry.COLUMN_TYPE} TEXT NOT NULL,
                ${DataContract.NotificationEntry.COLUMN_TITLE} TEXT NOT NULL,
                ${DataContract.NotificationEntry.COLUMN_MESSAGE} TEXT NOT NULL,
                ${DataContract.NotificationEntry.COLUMN_TIMESTAMP} TEXT NOT NULL,
                ${DataContract.NotificationEntry.COLUMN_IS_READ} INTEGER DEFAULT 0,
                ${DataContract.NotificationEntry.COLUMN_CATEGORY} TEXT,
                ${DataContract.NotificationEntry.COLUMN_LOCATION} TEXT,
                ${DataContract.NotificationEntry.COLUMN_ITEM_ID} TEXT,
                ${DataContract.NotificationEntry.COLUMN_USER_ID} TEXT NOT NULL
            )
        """.trimIndent()

        // Create reports table
        val createReportTable = """
            CREATE TABLE ${DataContract.ReportEntry.TABLE_NAME} (
                ${BaseColumns._ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${DataContract.ReportEntry.COLUMN_REPORT_ID} TEXT UNIQUE NOT NULL,
                ${DataContract.ReportEntry.COLUMN_USER_ID} TEXT NOT NULL,
                ${DataContract.ReportEntry.COLUMN_ITEM_ID} TEXT NOT NULL,
                ${DataContract.ReportEntry.COLUMN_REPORT_TYPE} TEXT NOT NULL,
                ${DataContract.ReportEntry.COLUMN_STATUS} TEXT DEFAULT 'active',
                ${DataContract.ReportEntry.COLUMN_CREATED_AT} TEXT NOT NULL,
                ${DataContract.ReportEntry.COLUMN_UPDATED_AT} TEXT NOT NULL
            )
        """.trimIndent()

        // Create likes table
        val createLikeTable = """
            CREATE TABLE ${DataContract.LikeEntry.TABLE_NAME} (
                ${BaseColumns._ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${DataContract.LikeEntry.COLUMN_LIKE_ID} TEXT UNIQUE NOT NULL,
                ${DataContract.LikeEntry.COLUMN_ITEM_ID} TEXT NOT NULL,
                ${DataContract.LikeEntry.COLUMN_USER_ID} TEXT NOT NULL,
                ${DataContract.LikeEntry.COLUMN_CREATED_AT} TEXT NOT NULL
            )
        """.trimIndent()

        // Create comments table
        val createCommentTable = """
            CREATE TABLE ${DataContract.CommentEntry.TABLE_NAME} (
                ${BaseColumns._ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${DataContract.CommentEntry.COLUMN_COMMENT_ID} TEXT UNIQUE NOT NULL,
                ${DataContract.CommentEntry.COLUMN_ITEM_ID} TEXT NOT NULL,
                ${DataContract.CommentEntry.COLUMN_USER_ID} TEXT NOT NULL,
                ${DataContract.CommentEntry.COLUMN_USER_NAME} TEXT NOT NULL,
                ${DataContract.CommentEntry.COLUMN_COMMENT_TEXT} TEXT NOT NULL,
                ${DataContract.CommentEntry.COLUMN_CREATED_AT} TEXT NOT NULL
            )
        """.trimIndent()

        // Create verification_requests table
        val createVerificationTable = """
            CREATE TABLE verification_requests (
                ${BaseColumns._ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                verification_id TEXT UNIQUE NOT NULL,
                item_id INTEGER NOT NULL,
                claimant_email TEXT NOT NULL,
                proof_description TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                created_at TEXT NOT NULL,
                FOREIGN KEY (item_id) REFERENCES ${DataContract.ItemEntry.TABLE_NAME} (${BaseColumns._ID})
            )
        """.trimIndent()

        // Create in_app_messages table
        val createMessagesTable = """
            CREATE TABLE in_app_messages (
                ${BaseColumns._ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                message_id TEXT UNIQUE NOT NULL,
                sender_email TEXT NOT NULL,
                sender_name TEXT NOT NULL,
                receiver_name TEXT NOT NULL,
                item_id INTEGER NOT NULL,
                message_text TEXT NOT NULL,
                is_read INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                FOREIGN KEY (item_id) REFERENCES ${DataContract.ItemEntry.TABLE_NAME} (${BaseColumns._ID})
            )
        """.trimIndent()

        db.execSQL(createUserTable)
        db.execSQL(createItemTable)
        db.execSQL(createNotificationTable)
        db.execSQL(createReportTable)
        db.execSQL(createLikeTable)
        db.execSQL(createCommentTable)
        db.execSQL(createVerificationTable)
        db.execSQL(createMessagesTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // For now, just drop and recreate tables
        db.execSQL("DROP TABLE IF EXISTS ${DataContract.UserEntry.TABLE_NAME}")
        db.execSQL("DROP TABLE IF EXISTS ${DataContract.ItemEntry.TABLE_NAME}")
        db.execSQL("DROP TABLE IF EXISTS ${DataContract.NotificationEntry.TABLE_NAME}")
        db.execSQL("DROP TABLE IF EXISTS ${DataContract.ReportEntry.TABLE_NAME}")
        db.execSQL("DROP TABLE IF EXISTS ${DataContract.LikeEntry.TABLE_NAME}")
        db.execSQL("DROP TABLE IF EXISTS ${DataContract.CommentEntry.TABLE_NAME}")
        db.execSQL("DROP TABLE IF EXISTS verification_requests")
        db.execSQL("DROP TABLE IF EXISTS in_app_messages")
        onCreate(db)
    }
}