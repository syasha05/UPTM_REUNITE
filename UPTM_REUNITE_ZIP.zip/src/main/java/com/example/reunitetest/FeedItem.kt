package com.example.reunitetest.data

import android.os.Message

data class FeedItem(
    val id: Int,
    val itemId: String,
    val title: String,
    val description: String,
    val category: String,
    val location: String,
    val date: String,
    val time: String,
    val postTime: String,
    var status: String,  // Changed to var to allow status updates
    val image: String,
    val user: String,
    val userAvatar: String,
    var likes: Int,
    var comments: Int,
    var message: String,
    val shares: Int,
    var isLiked: Boolean = false,
    val isOwnPost: Boolean = false,
    val contactEmail: String = ""
)