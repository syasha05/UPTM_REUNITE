package com.example.reunitetest

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.reunitetest.data.DatabaseRepository
import com.example.reunitetest.data.User

class ProfileActivity : AppCompatActivity() {

    // Data classes
    data class UserStats(
        val reportsSubmitted: Int,
        val itemsReunited: Int,
        val successRate: String
    )

    // UI References
    private lateinit var userNameText: TextView
    private lateinit var studentIdText: TextView
    private lateinit var userRoleBadge: TextView
    private lateinit var emailText: TextView
    private lateinit var reportsSubmittedText: TextView
    private lateinit var itemsReunitedText: TextView
    private lateinit var successRateText: TextView
    private lateinit var reportsCountText: TextView
    private lateinit var myReportsContainer: LinearLayout
    private lateinit var settingsButton: ImageButton
    private lateinit var welcomeText: TextView
    private lateinit var profileStatsContainer: LinearLayout
    private lateinit var recentReportsSection: LinearLayout
    private lateinit var emptyReportsState: LinearLayout

    private lateinit var user: User
    private var userStats = UserStats(0, 0, "0%")
    private val myReports = mutableListOf<DatabaseRepository.Item>()

    // Database
    private lateinit var databaseRepository: DatabaseRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Initialize database
        databaseRepository = DatabaseRepository.getInstance(this)

        initializeUserData()
        initializeViews()
        setupClickListeners()
        setupBottomNavigation()
        showLoadingStates()
        loadUserData()
    }

    private fun initializeUserData() {
        try {
            // Get real data from intent
            val userName = intent.getStringExtra("USER_NAME") ?: "User"
            val userRole = intent.getStringExtra("USER_ROLE") ?: "student"
            val userEmail = intent.getStringExtra("USER_EMAIL") ?: "user@email.com"

            // Extract Student ID from email (convert "kl" to "AM")
            val studentId = extractStudentIdFromEmail(userEmail)

            // Create user with real data
            user = User(
                name = userName,
                role = userRole,
                email = userEmail,
                studentId = studentId
            )
        } catch (e: Exception) {
            // Simple fallback
            user = User(
                name = "User",
                role = "student",
                email = "user@email.com",
                studentId = "AM0000000000"
            )
        }
    }

    private fun extractStudentIdFromEmail(email: String): String {
        return try {
            if (email.contains("@student.uptm.edu.my")) {
                // Extract the part before @ and convert "kl" to "AM"
                val username = email.substringBefore("@")
                if (username.startsWith("kl") && username.length > 2) {
                    // Replace "kl" with "AM" and keep the numbers
                    "AM" + username.substring(2)
                } else {
                    // If format doesn't match, return the username as is
                    username.uppercase()
                }
            } else {
                // For non-student emails, generate a default format
                "AM${(1000000000..9999999999).random()}"
            }
        } catch (e: Exception) {
            "AM${(1000000000..9999999999).random()}"
        }
    }

    private fun initializeViews() {
        // Initialize UI components
        userNameText = findViewById(R.id.user_name_text)
        studentIdText = findViewById(R.id.student_id_text)
        userRoleBadge = findViewById(R.id.user_role_badge)
        emailText = findViewById(R.id.email_text)
        reportsSubmittedText = findViewById(R.id.reports_submitted_text)
        itemsReunitedText = findViewById(R.id.items_reunited_text)
        successRateText = findViewById(R.id.success_rate_text)
        reportsCountText = findViewById(R.id.reports_count_text)
        myReportsContainer = findViewById(R.id.recent_reports_container)
        settingsButton = findViewById(R.id.settings_button)
        welcomeText = findViewById(R.id.welcome_text)
        profileStatsContainer = findViewById(R.id.profile_stats_container)
        recentReportsSection = findViewById(R.id.recent_reports_section)
        emptyReportsState = findViewById(R.id.empty_reports_state)
    }

    private fun setupBottomNavigation() {
        val homeButton: ImageButton = findViewById(R.id.nav_home)
        val searchButton: ImageButton = findViewById(R.id.nav_search)
        val profileButton: ImageButton = findViewById(R.id.nav_profile)
        val messagesButton: ImageButton = findViewById(R.id.nav_messages)

        homeButton.setOnClickListener {
            navigateToHome()
        }

        searchButton.setOnClickListener {
            navigateToSearchItems()
        }

        profileButton.setOnClickListener {
            // Refresh with loading animation
            showLoadingStates()
            loadUserData()
        }
        messagesButton.setOnClickListener {
            navigateToMessages()
        }

    }

    private fun setupClickListeners() {
        settingsButton.setOnClickListener {
            navigateToSettings()
        }
    }

    // ADDED: Loading states
    private fun showLoadingStates() {
        profileStatsContainer.visibility = View.GONE
        recentReportsSection.visibility = View.GONE
        emptyReportsState.visibility = View.GONE

        // Show loading animation for stats
        val loadingStatsLayout = findViewById<LinearLayout>(R.id.loading_stats_layout)
        loadingStatsLayout.visibility = View.VISIBLE

        // Show loading animation for reports
        val loadingReportsLayout = findViewById<LinearLayout>(R.id.loading_reports_layout)
        loadingReportsLayout.visibility = View.VISIBLE
    }

    private fun hideLoadingStates() {
        val loadingStatsLayout = findViewById<LinearLayout>(R.id.loading_stats_layout)
        val loadingReportsLayout = findViewById<LinearLayout>(R.id.loading_reports_layout)

        loadingStatsLayout.visibility = View.GONE
        loadingReportsLayout.visibility = View.GONE

        profileStatsContainer.visibility = View.VISIBLE
        recentReportsSection.visibility = View.VISIBLE
    }

    private fun loadUserData() {
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                // Load user's reports from database - REAL DATA
                myReports.clear()
                myReports.addAll(databaseRepository.getItemsByUser(user.name))

                // Calculate REAL statistics from actual database data
                val totalReports = myReports.size
                val reunitedItems = myReports.count { report ->
                    // Count items that are actually reunited/resolved
                    report.status.equals("reunited", ignoreCase = true) ||
                            report.status.equals("resolved", ignoreCase = true) ||
                            report.status.equals("found", ignoreCase = true)
                }

                val successRate = if (totalReports > 0) {
                    (reunitedItems * 100 / totalReports)
                } else {
                    0
                }

                userStats = UserStats(
                    reportsSubmitted = totalReports,
                    itemsReunited = reunitedItems,
                    successRate = "$successRate%"
                )

                updateUI()
                hideLoadingStates()
            } catch (e: Exception) {
                // Use actual zero stats if there's an error
                userStats = UserStats(0, 0, "0%")
                updateUI()
                hideLoadingStates()
                Toast.makeText(this, "Error loading profile data", Toast.LENGTH_SHORT).show()
            }
        }, 1000) // Simulate loading delay
    }

    private fun updateUI() {
        // Update user information with REAL DATA
        userNameText.text = user.name
        studentIdText.text = user.studentId
        emailText.text = user.email
        welcomeText.text = "My Profile"

        // Update user role badge (real data from intent)
        val roleText = when (user.role) {
            "admin" -> "Administrator"
            "staff" -> "Staff"
            else -> "Student"
        }
        userRoleBadge.text = roleText

        val roleColor = when (user.role) {
            "admin" -> ContextCompat.getColor(this, R.color.color_admin)
            "staff" -> ContextCompat.getColor(this, R.color.color_staff)
            else -> ContextCompat.getColor(this, R.color.color_student)
        }
        userRoleBadge.setBackgroundColor(roleColor)

        // Update statistics (real calculated data) with animation
        animateNumberChange(reportsSubmittedText, userStats.reportsSubmitted.toString())
        animateNumberChange(itemsReunitedText, userStats.itemsReunited.toString())
        animateNumberChange(successRateText, userStats.successRate)

        // Update reports count (real data)
        reportsCountText.text = "(${myReports.size})"

        // Display user's actual reports
        displayMyReports()
    }

    // ADDED: Number animation for stats
    private fun animateNumberChange(textView: TextView, newValue: String) {
        textView.text = newValue
        textView.alpha = 0f
        textView.animate()
            .alpha(1f)
            .setDuration(500)
            .start()
    }

    private fun displayMyReports() {
        myReportsContainer.removeAllViews()

        if (myReports.isEmpty()) {
            emptyReportsState.visibility = View.VISIBLE
            return
        }

        emptyReportsState.visibility = View.GONE

        // Display user's ACTUAL reports from database with staggered animation
        for ((index, report) in myReports.take(10).withIndex()) { // Limit to 10 most recent
            val reportLayout = createReportView(report)
            myReportsContainer.addView(reportLayout)

            // Staggered animation for reports
            reportLayout.alpha = 0f
            reportLayout.translationY = 20f
            reportLayout.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay((index * 100).toLong())
                .setDuration(400)
                .start()
        }
    }

    private fun createReportView(report: DatabaseRepository.Item): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 12)
            }
            setBackgroundResource(R.drawable.card_background)
            setPadding(20, 16, 20, 16)
            elevation = 4f
            isClickable = true
        }

        // Header with title and status
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            gravity = android.view.Gravity.CENTER_VERTICAL
        }

        val titleText = TextView(this).apply {
            text = report.title
            textSize = 16f
            setTextColor(ContextCompat.getColor(this@ProfileActivity, R.color.color_black))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        val statusBadge = TextView(this).apply {
            text = report.status.uppercase()
            textSize = 10f
            setTextColor(ContextCompat.getColor(this@ProfileActivity, android.R.color.white))
            setPadding(12, 6, 12, 6)

            val statusColor = when (report.status.lowercase()) {
                "reunited" -> R.color.color_success
                "found" -> R.color.color_found
                "lost" -> R.color.color_lost
                "flagged" -> R.color.color_error
                else -> R.color.color_text_secondary
            }

            setBackgroundColor(ContextCompat.getColor(this@ProfileActivity, statusColor))
        }

        headerLayout.addView(titleText)
        headerLayout.addView(statusBadge)

        // Description
        val descriptionText = TextView(this).apply {
            text = report.description
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@ProfileActivity, R.color.color_text_secondary))
            setPadding(0, 8, 0, 8)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        // Footer with location and date
        val footerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val locationText = TextView(this).apply {
            text = "📍 ${report.location}"
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@ProfileActivity, R.color.color_text_secondary))
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
        }

        val dateText = TextView(this).apply {
            text = "📅 ${report.date}"
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@ProfileActivity, R.color.color_text_secondary))
        }

        footerLayout.addView(locationText)
        footerLayout.addView(dateText)

        layout.addView(headerLayout)
        layout.addView(descriptionText)
        layout.addView(footerLayout)

        // Add click listener to view report details
        layout.setOnClickListener {
            showReportDetails(report)
        }

        return layout
    }

    // ADDED: Enhanced report details dialog
    private fun showReportDetails(report: DatabaseRepository.Item) {
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle(report.title)
            .setMessage(
                """
                ${report.description}
                
                📍 Location: ${report.location}
                📅 Date: ${report.date}
                ⏰ Time: ${report.time}
                🏷️ Category: ${report.category}
                📊 Status: ${report.status.uppercase()}
                👤 Reported by: ${report.reportedBy}
                
                ${if (report.status.equals("reunited", ignoreCase = true)) "✅ Successfully reunited!" else "⏳ Still active..."}
                """.trimIndent()
            )
            .setPositiveButton("Close") { dialog, _ -> dialog.dismiss() }
            .create()

        dialog.show()
    }

    private fun navigateToSettings() {
        try {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot open settings", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToHome() {
        try {
            val intent = Intent(this, DashboardActivity::class.java)
            intent.putExtra("USER_NAME", user.name)
            intent.putExtra("USER_ROLE", user.role)
            intent.putExtra("USER_EMAIL", user.email)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Error navigating home", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToSearchItems() {
        try {
            val intent = Intent(this, SearchItemsActivity::class.java)
            intent.putExtra("USER_NAME", user.name)
            intent.putExtra("USER_ROLE", user.role)
            intent.putExtra("USER_EMAIL", user.email)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Error navigating to search", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToMessages() {
        val intent = Intent(this, MessagesActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_EMAIL", user.email)
        startActivity(intent)
    }

    override fun onResume() {
        super.onResume()
        showLoadingStates()
        loadUserData()
    }
}