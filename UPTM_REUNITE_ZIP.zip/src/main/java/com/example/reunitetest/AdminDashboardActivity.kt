package com.example.reunitetest

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.reunitetest.data.DatabaseRepository
import com.example.reunitetest.data.User

class AdminDashboardActivity : AppCompatActivity() {

    // UI References
    private lateinit var adminWelcomeText: TextView
    private lateinit var adminTotalReportsText: TextView
    private lateinit var adminLostItemsText: TextView
    private lateinit var adminFoundItemsText: TextView
    private lateinit var adminActiveUsersText: TextView
    private lateinit var adminFlaggedItemsText: TextView
    private lateinit var adminReunitedItemsText: TextView
    private lateinit var adminPendingReportsText: TextView

    // Buttons
    private lateinit var adminProfileButton: ImageButton
    private lateinit var adminDashboardButton: ImageButton
    private lateinit var adminReportsButton: ImageButton
    private lateinit var adminFlaggedButton: ImageButton

    private lateinit var user: User
    private lateinit var databaseRepository: DatabaseRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_dashboard)

        databaseRepository = DatabaseRepository.getInstance(this)
        initializeUserData()
        initializeAdminViews()
        setupAdminClickListeners()
        setupAdminUI()
        loadAdminData()
    }

    private fun initializeUserData() {
        val userName = intent.getStringExtra("USER_NAME") ?: "Admin"
        val userRole = intent.getStringExtra("USER_ROLE") ?: "Admin"
        val userEmail = intent.getStringExtra("USER_EMAIL") ?: "admin@uptm.edu.my"
        val studentId = intent.getStringExtra("USER_ID") ?: "ADM001"

        user = User(
            name = userName,
            email = userEmail,
            role = userRole,
            studentId = studentId
        )
    }

    private fun initializeAdminViews() {
        adminWelcomeText = findViewById(R.id.welcome_text)
        adminProfileButton = findViewById(R.id.profile_button)

        // Stats texts
        adminTotalReportsText = findViewById(R.id.admin_total_reports_text)
        adminLostItemsText = findViewById(R.id.admin_lost_items_text)
        adminFoundItemsText = findViewById(R.id.admin_found_items_text)
        adminActiveUsersText = findViewById(R.id.admin_active_users_text)
        adminFlaggedItemsText = findViewById(R.id.admin_flagged_items_text)
        adminReunitedItemsText = findViewById(R.id.admin_reunited_cases_text)
        adminPendingReportsText = findViewById(R.id.admin_pending_reports_text)

        // Bottom nav
        adminDashboardButton = findViewById(R.id.nav_dashboard)
        adminReportsButton = findViewById(R.id.nav_reports)
        adminFlaggedButton = findViewById(R.id.nav_flagged)
    }

    private fun setupAdminClickListeners() {
        adminProfileButton.setOnClickListener { navigateToAdminProfile() }

        adminDashboardButton.setOnClickListener {
            // Already on dashboard, just refresh
            loadAdminData()
            updateAdminNavigationState(adminDashboardButton)
        }
        adminReportsButton.setOnClickListener {
            navigateToAdminReports()
            updateAdminNavigationState(adminReportsButton)
        }
        adminFlaggedButton.setOnClickListener {
            navigateToAdminFlagged()
            updateAdminNavigationState(adminFlaggedButton)
        }
    }

    private fun updateAdminNavigationState(selectedButton: ImageButton) {
        val buttons = listOf(adminDashboardButton, adminReportsButton, adminFlaggedButton)

        buttons.forEach { button ->
            val isSelected = button == selectedButton
            button.setColorFilter(
                ContextCompat.getColor(this,
                    if (isSelected) R.color.color_primary else R.color.color_black
                )
            )
            button.isSelected = isSelected
        }
    }

    private fun setupAdminUI() {
        adminWelcomeText.text = "Welcome, ${user.name}"
        updateAdminNavigationState(adminDashboardButton)
    }

    private fun loadAdminData() {
        showAdminLoadingStates()

        Handler(Looper.getMainLooper()).postDelayed({
            updateAdminStatsUI()
            hideAdminLoadingStates()
        }, 800)
    }

    private fun showAdminLoadingStates() {
        listOf(adminTotalReportsText, adminLostItemsText, adminFoundItemsText, adminActiveUsersText,
            adminFlaggedItemsText, adminReunitedItemsText, adminPendingReportsText).forEach { textView ->
            textView.text = "..."
        }
    }

    private fun hideAdminLoadingStates() {
        // Loading states are hidden when real data is displayed
    }

    // Method for admin to manually flag any item
    fun adminManualFlag(itemId: Int, reason: String) {
        val result = databaseRepository.flagItem(itemId)
        if (result > 0) {
            Toast.makeText(this, "Item flagged", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateAdminStatsUI() {
        val allItems = databaseRepository.getAllItems()
        val allUsers = databaseRepository.getAllUsers()

        adminTotalReportsText.text = allItems.size.toString()
        adminLostItemsText.text = allItems.count { it.type.equals("lost", ignoreCase = true) }.toString()
        adminFoundItemsText.text = allItems.count { it.type.equals("found", ignoreCase = true) }.toString()
        adminActiveUsersText.text = allUsers.size.toString()
        adminFlaggedItemsText.text = allItems.count { it.status.equals("flagged", ignoreCase = true) }.toString()
        adminReunitedItemsText.text = allItems.count { it.status.equals("reunited", ignoreCase = true) }.toString()
        adminPendingReportsText.text = allItems.count { it.status.equals("pending", ignoreCase = true) }.toString()
    }

    // Navigation methods
    private fun navigateToAdminProfile() {
        val intent = Intent(this, AdminProfileActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        intent.putExtra("USER_ID", user.studentId)
        startActivity(intent)
    }

    private fun navigateToAdminReports() {
        val intent = Intent(this, AdminReportsActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        intent.putExtra("USER_ID", user.studentId)
        startActivity(intent)
    }

    private fun navigateToAdminFlagged() {
        val intent = Intent(this, AdminFlaggedActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        intent.putExtra("USER_ID", user.studentId)
        startActivity(intent)
    }

    override fun onResume() {
        super.onResume()
        loadAdminData()
        updateAdminNavigationState(adminDashboardButton)
    }
}