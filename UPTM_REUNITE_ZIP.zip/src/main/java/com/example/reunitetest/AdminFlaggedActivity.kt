package com.example.reunitetest

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.reunitetest.data.DatabaseRepository
import com.example.reunitetest.data.User

class AdminFlaggedActivity : AppCompatActivity() {

    // UI References
    private lateinit var adminWelcomeText: TextView
    private lateinit var flaggedContainer: LinearLayout
    private lateinit var emptyFlaggedState: LinearLayout

    // Buttons
    private lateinit var adminProfileButton: ImageButton
    private lateinit var adminDashboardButton: ImageButton
    private lateinit var adminReportsButton: ImageButton
    private lateinit var adminFlaggedButton: ImageButton

    private lateinit var user: User
    private lateinit var databaseRepository: DatabaseRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_flagged)

        databaseRepository = DatabaseRepository.getInstance(this)
        initializeUserData()
        initializeAdminViews()
        setupAdminClickListeners()
        setupAdminUI()
        loadAdminData()
    }

    private fun initializeUserData() {
        val userName = intent.getStringExtra("USER_NAME") ?: "Admin"
        val userRole = intent.getStringExtra("USER_ROLE") ?: "admin"
        val userEmail = intent.getStringExtra("USER_EMAIL") ?: "admin@uptm.edu.my"
        val studentId = intent.getStringExtra("USER_ID") ?: "ADM001"

        user = User(
            name = userName,
            email = userEmail,
            role = userRole,
            studentId = studentId
        )
    }

    private fun initializeAdminViews() {
        adminWelcomeText = findViewById(R.id.welcome_text)
        adminProfileButton = findViewById(R.id.profile_button)

        flaggedContainer = findViewById(R.id.flagged_container)
        emptyFlaggedState = findViewById(R.id.empty_flagged_state)

        // Bottom nav
        adminDashboardButton = findViewById(R.id.nav_dashboard)
        adminReportsButton = findViewById(R.id.nav_reports)
        adminFlaggedButton = findViewById(R.id.nav_flagged)
    }

    private fun setupAdminClickListeners() {
        adminProfileButton.setOnClickListener { navigateToAdminProfile() }

        adminDashboardButton.setOnClickListener {
            navigateToAdminDashboard()
            updateAdminNavigationState(adminDashboardButton)
        }
        adminReportsButton.setOnClickListener {
            navigateToAdminReports()
            updateAdminNavigationState(adminReportsButton)
        }
        adminFlaggedButton.setOnClickListener {
            // Already on flagged, just refresh
            loadAdminData()
            updateAdminNavigationState(adminFlaggedButton)
        }
    }

    private fun updateAdminNavigationState(selectedButton: ImageButton) {
        val buttons = listOf(adminDashboardButton, adminReportsButton, adminFlaggedButton)

        buttons.forEach { button ->
            val isSelected = button == selectedButton
            button.setColorFilter(
                ContextCompat.getColor(this,
                    if (isSelected) R.color.color_primary else R.color.color_black
                )
            )
            button.isSelected = isSelected
        }
    }

    private fun setupAdminUI() {
        adminWelcomeText.text = "Flagged Items"
        updateAdminNavigationState(adminFlaggedButton)
    }

    private fun loadAdminData() {
        showAdminLoadingStates()

        Handler(Looper.getMainLooper()).postDelayed({
            displayFlaggedItems()
            hideAdminLoadingStates()
        }, 800)
    }

    private fun showAdminLoadingStates() {
        emptyFlaggedState.visibility = View.GONE
        flaggedContainer.removeAllViews()

        val loadingText = TextView(this).apply {
            text = "Loading flagged items..."
            setTextColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_text_secondary))
            setTextAlignment(View.TEXT_ALIGNMENT_CENTER)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 32, 0, 32)
            }
        }
        flaggedContainer.addView(loadingText)
    }

    private fun hideAdminLoadingStates() {
        // Loading states are hidden when real data is displayed
    }

    private fun displayFlaggedItems() {
        flaggedContainer.removeAllViews()
        emptyFlaggedState.visibility = View.GONE

        val flaggedItems = databaseRepository.getAllItems()
            .filter { it.status.equals("flagged", ignoreCase = true) }
            .sortedByDescending { it.id }
            .take(10)

        if (flaggedItems.isEmpty()) {
            showEmptyFlaggedState()
            return
        }

        for (item in flaggedItems) {
            val itemView = createFlaggedItemView(item)
            flaggedContainer.addView(itemView)
        }
    }

    private fun createFlaggedItemView(item: DatabaseRepository.Item): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 8, 0, 8)
            }
            setBackgroundResource(R.drawable.card_background)
            setPadding(16, 16, 16, 16)
        }

        // Status Badge
        val statusBadge = TextView(this).apply {
            text = "FLAGGED"
            textSize = 10f
            setTextColor(ContextCompat.getColor(this@AdminFlaggedActivity, android.R.color.white))
            setBackgroundColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_accent))
            setPadding(24, 12, 24, 12)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 8)
            }
        }

        val title = TextView(this).apply {
            text = item.title
            textSize = 18f
            setTextColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_black))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        val description = TextView(this).apply {
            text = item.description
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_text_secondary))
            maxLines = Int.MAX_VALUE // Show full description
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 8, 0, 8)
            }
        }

        val categoryText = TextView(this).apply {
            text = "📦 Category: ${item.category}"
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_text_secondary))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4, 0, 4)
            }
        }

        val locationText = TextView(this).apply {
            text = "📍 Location: ${item.location}"
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_text_secondary))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4, 0, 4)
            }
        }

        val dateTimeText = TextView(this).apply {
            text = "📅 Date: ${item.date} ⏰ Time: ${item.time}"
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_text_secondary))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4, 0, 4)
            }
        }

        val typeText = TextView(this).apply {
            text = "🏷️ Type: ${item.type.uppercase()}"
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_text_secondary))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4, 0, 4)
            }
        }

        val reporterText = TextView(this).apply {
            text = "👤 Reported by: ${item.reportedBy}"
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_text_secondary))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4, 0, 4)
            }
        }

        val contactText = TextView(this).apply {
            text = "📧 Contact: ${item.contactEmail}"
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_text_secondary))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4, 0, 8)
            }
        }

        val divider = View(this).apply {
            setBackgroundColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_text_secondary))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                2
            ).apply {
                setMargins(0, 16, 0, 16)
            }
        }

        val actionLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 16, 0, 0)
            }
        }

        val approveBtn = Button(this).apply {
            text = "Approve"
            setBackgroundColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_error))
            setTextColor(ContextCompat.getColor(this@AdminFlaggedActivity, android.R.color.white))
            setOnClickListener {
                approveFlaggedItem(item.id)
            }
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            ).apply {
                marginEnd = 8
            }
        }

        val declineBtn = Button(this).apply {
            text = "Decline"
            setBackgroundColor(ContextCompat.getColor(this@AdminFlaggedActivity, R.color.color_success))
            setTextColor(ContextCompat.getColor(this@AdminFlaggedActivity, android.R.color.white))
            setOnClickListener {
                declineFlaggedItem(item.id, item.type)
            }
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
        }

        actionLayout.addView(approveBtn)
        actionLayout.addView(declineBtn)

        layout.addView(statusBadge)
        layout.addView(title)
        layout.addView(description)
        layout.addView(categoryText)
        layout.addView(locationText)
        layout.addView(dateTimeText)
        layout.addView(typeText)
        layout.addView(reporterText)
        layout.addView(contactText)
        layout.addView(divider)
        layout.addView(actionLayout)

        return layout
    }

    private fun approveFlaggedItem(itemId: Int) {
        // Approve = Remove the item due to inappropriate/false information
        val result = databaseRepository.removeItem(itemId)
        if (result > 0) {
            Toast.makeText(this, "Item approved for removal (inappropriate/false information)", Toast.LENGTH_SHORT).show()
            loadAdminData() // Refresh the list
        } else {
            Toast.makeText(this, "Failed to remove item", Toast.LENGTH_SHORT).show()
        }
    }

    private fun declineFlaggedItem(itemId: Int, originalType: String) {
        // Decline = Restore to original status (lost/found)
        val result = databaseRepository.updateItemStatus(itemId, originalType)
        if (result > 0) {
            Toast.makeText(this, "Flag declined - Item restored to $originalType", Toast.LENGTH_SHORT).show()
            loadAdminData() // Refresh the list
        } else {
            Toast.makeText(this, "Failed to decline flag", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showEmptyFlaggedState() {
        emptyFlaggedState.visibility = View.VISIBLE
    }

    // Navigation methods
    private fun navigateToAdminProfile() {
        val intent = Intent(this, AdminProfileActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        intent.putExtra("USER_ID", user.studentId)
        startActivity(intent)
    }

    private fun navigateToAdminDashboard() {
        val intent = Intent(this, AdminDashboardActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        intent.putExtra("USER_ID", user.studentId)
        startActivity(intent)
    }

    private fun navigateToAdminReports() {
        val intent = Intent(this, AdminReportsActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        intent.putExtra("USER_ID", user.studentId)
        startActivity(intent)
    }

    override fun onResume() {
        super.onResume()
        loadAdminData()
        updateAdminNavigationState(adminFlaggedButton)
    }
}