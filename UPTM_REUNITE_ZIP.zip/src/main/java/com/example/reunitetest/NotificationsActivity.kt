package com.example.reunitetest

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.reunitetest.data.DatabaseRepository
import com.google.android.material.tabs.TabLayout

class NotificationsActivity : AppCompatActivity() {

    // UI References
    private lateinit var notificationsList: LinearLayout
    private lateinit var emptyNotificationsState: LinearLayout
    private lateinit var markAllReadButton: Button
    private lateinit var unreadCountText: TextView
    private lateinit var tabLayout: TabLayout
    private lateinit var backButton: ImageButton

    private lateinit var databaseRepository: DatabaseRepository
    private lateinit var currentUserId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notifications)

        // Initialize database
        databaseRepository = DatabaseRepository.getInstance(this)

        // Get current user ID from intent or use a default
        currentUserId = intent.getStringExtra("USER_EMAIL") ?: "default_user"

        initializeViews()
        setupClickListeners()
        loadNotifications()
        displayNotifications()
    }

    private fun initializeViews() {
        try {
            notificationsList = findViewById(R.id.notifications_list)
            emptyNotificationsState = findViewById(R.id.empty_notifications_state)
            markAllReadButton = findViewById(R.id.mark_all_read_button)
            unreadCountText = findViewById(R.id.unread_count_text)
            tabLayout = findViewById(R.id.tab_layout)
            backButton = findViewById(R.id.back_button)
        } catch (e: Exception) {
            Toast.makeText(this, "Error setting up UI", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun setupClickListeners() {
        backButton.setOnClickListener {
            finish()
        }

        markAllReadButton.setOnClickListener {
            markAllAsRead()
        }

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> showAllNotifications()
                    1 -> showUnreadNotifications()
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun loadNotifications() {
        // Notifications are loaded from database in display methods
    }

    private fun displayNotifications() {
        notificationsList.removeAllViews()

        val notifications = databaseRepository.getUserNotifications(currentUserId)

        if (notifications.isEmpty()) {
            showEmptyState()
            return
        }

        showAllNotifications()
        updateUnreadCount()
    }

    private fun showAllNotifications() {
        showNotifications(databaseRepository.getUserNotifications(currentUserId))
    }

    private fun showUnreadNotifications() {
        val unread = databaseRepository.getUserNotifications(currentUserId).filter { !it.isRead }
        showNotifications(unread)
    }

    private fun showNotifications(notificationList: List<DatabaseRepository.NotificationItem>) {
        notificationsList.removeAllViews()

        if (notificationList.isEmpty()) {
            showEmptyState()
            return
        }

        emptyNotificationsState.visibility = View.GONE

        notificationList.forEach { notification ->
            val notificationView = createNotificationView(notification)
            notificationsList.addView(notificationView)
        }
    }

    private fun createNotificationView(notification: DatabaseRepository.NotificationItem): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(8, 4, 8, 4)
            }
            setBackgroundColor(ContextCompat.getColor(this@NotificationsActivity, android.R.color.white))
            setPadding(16, 16, 16, 16)
            elevation = 2f
        }

        // Title
        val titleText = TextView(this).apply {
            text = notification.title
            textSize = 16f
            setTextColor(ContextCompat.getColor(this@NotificationsActivity, android.R.color.black))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        // Message
        val messageText = TextView(this).apply {
            text = notification.message
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@NotificationsActivity, android.R.color.darker_gray))
            setPadding(0, 4, 0, 0)
        }

        // Time and status
        val bottomLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 8, 0, 0)
            }
        }

        val timeText = TextView(this).apply {
            text = formatTimestamp(notification.timestamp)
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@NotificationsActivity, android.R.color.darker_gray))
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
        }

        val statusText = TextView(this).apply {
            text = if (notification.isRead) "READ" else "NEW"
            textSize = 10f
            setTextColor(ContextCompat.getColor(this@NotificationsActivity,
                if (notification.isRead) android.R.color.darker_gray else android.R.color.holo_red_dark
            ))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        bottomLayout.addView(timeText)
        bottomLayout.addView(statusText)

        layout.addView(titleText)
        layout.addView(messageText)
        layout.addView(bottomLayout)

        // Click listener
        layout.setOnClickListener {
            if (!notification.isRead) {
                markAsRead(notification.id)
            }
            handleNotificationClick(notification)
        }

        return layout
    }

    private fun formatTimestamp(timestamp: String): String {
        return try {
            val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.getDefault())
            val date = dateFormat.parse(timestamp)
            val currentDate = java.util.Date()

            val diff = currentDate.time - (date?.time ?: 0)
            val seconds = diff / 1000
            val minutes = seconds / 60
            val hours = minutes / 60
            val days = hours / 24

            when {
                days > 0 -> "$days days ago"
                hours > 0 -> "$hours hours ago"
                minutes > 0 -> "$minutes minutes ago"
                else -> "Just now"
            }
        } catch (e: Exception) {
            timestamp
        }
    }

    private fun markAsRead(notificationId: String) {
        databaseRepository.markNotificationAsRead(notificationId)
        updateUnreadCount()
        Toast.makeText(this, "Notification marked as read", Toast.LENGTH_SHORT).show()
    }

    private fun markAllAsRead() {
        databaseRepository.markAllNotificationsAsRead(currentUserId)
        updateUnreadCount()
        showAllNotifications()
        Toast.makeText(this, "All notifications marked as read", Toast.LENGTH_SHORT).show()
    }

    private fun updateUnreadCount() {
        val unreadCount = databaseRepository.getUserNotifications(currentUserId).count { !it.isRead }
        unreadCountText.text = "$unreadCount unread"
    }

    private fun handleNotificationClick(notification: DatabaseRepository.NotificationItem) {
        when (notification.type) {
            "match" -> {
                // Navigate to item details or match screen
                Toast.makeText(this, "Match found: ${notification.message}", Toast.LENGTH_SHORT).show()
            }
            "update" -> {
                // Show update details
                Toast.makeText(this, "Update: ${notification.message}", Toast.LENGTH_SHORT).show()
            }
            "reminder" -> {
                // Handle reminder
                Toast.makeText(this, "Reminder: ${notification.message}", Toast.LENGTH_SHORT).show()
            }
            else -> {
                Toast.makeText(this, "${notification.title}: ${notification.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showEmptyState() {
        emptyNotificationsState.visibility = View.VISIBLE
        notificationsList.visibility = View.GONE
    }
}