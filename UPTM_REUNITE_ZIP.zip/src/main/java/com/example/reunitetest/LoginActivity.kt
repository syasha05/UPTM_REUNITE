package com.example.reunitetest

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.isVisible
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

class LoginActivity : AppCompatActivity() {

    private lateinit var googleSignInButton: Button
    private lateinit var errorTextView: TextView
    private lateinit var loadingOverlay: CardView

    private lateinit var auth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient

    companion object {
        private const val TAG = "LoginActivity"
    }

    // Use the new Activity Result API
    private val signInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            // Google Sign In was successful, authenticate with Firebase
            val account = task.getResult(ApiException::class.java)
            Log.d(TAG, "Google sign-in successful: ${account?.email}")
            firebaseAuthWithGoogle(account)
        } catch (e: ApiException) {
            // Google Sign In failed
            Log.e(TAG, "Google sign-in failed: ${e.statusCode} - ${e.message}")
            errorTextView.text = "Google sign in failed: ${e.message}"
            errorTextView.isVisible = true
            loadingOverlay.isVisible = false
            googleSignInButton.isEnabled = true
            Toast.makeText(this, "Authentication failed", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize views
        googleSignInButton = findViewById(R.id.google_sign_in_button)
        errorTextView = findViewById(R.id.error_textview)
        loadingOverlay = findViewById(R.id.loading_overlay)

        // Configure Google Sign In
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        // Set up Google sign-in button click listener
        googleSignInButton.setOnClickListener {
            signInWithGoogle()
        }
    }

    private fun showLoginScreen() {
        // Make sure login screen is visible
        loadingOverlay.isVisible = false
        googleSignInButton.isEnabled = true
        errorTextView.isVisible = false
    }

    private fun isValidUPTMEmail(email: String): Boolean {
        val studentPattern = Regex("^[a-zA-Z0-9._%+-]+@student\\.uptm\\.edu\\.my\$")
        val adminPattern = Regex("^[a-zA-Z0-9._%+-]+@uptm\\.edu\\.my\$")
        
        // Whitelist specific Gmail accounts
        val whitelistedEmails = listOf(
            "nsyasha00@gmail.com",
            "muhammadshafiq457@gmail.com"
        )

        return studentPattern.matches(email) || 
               adminPattern.matches(email) || 
               whitelistedEmails.contains(email)
    }

    private fun getRoleFromEmail(email: String): String {
        val adminEmails = listOf(
            "nsyasha00@gmail.com",
            "muhammadshafiq457@gmail.com"
        )
        return if (email.endsWith("@uptm.edu.my") || adminEmails.contains(email)) "admin" else "student"
    }

    private fun extractStudentIdFromEmail(email: String): String {
        return email.substringBefore("@")
    }

    private fun signInWithGoogle() {
        // Always start fresh sign-in process
        googleSignInClient.signOut().addOnCompleteListener {
            val signInIntent = googleSignInClient.signInIntent
            loadingOverlay.isVisible = true
            googleSignInButton.isEnabled = false
            signInLauncher.launch(signInIntent)
        }
    }

    private fun firebaseAuthWithGoogle(account: GoogleSignInAccount?) {
        if (account == null) {
            errorTextView.text = "Google account is null"
            errorTextView.isVisible = true
            loadingOverlay.isVisible = false
            googleSignInButton.isEnabled = true
            return
        }

        val credential = GoogleAuthProvider.getCredential(account.idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Log.d(TAG, "Firebase authentication successful")
                    // Sign in success
                    val user = auth.currentUser
                    user?.let {
                        // Check if the email is a valid UPTM email
                        if (isValidUPTMEmail(it.email ?: "")) {
                            proceedToDashboard(it.email ?: "", it.displayName ?: "User")
                        } else {
                            // Sign out if not a UPTM email
                            errorTextView.text = "Please use a valid UPTM email account (@student.uptm.edu.my or @uptm.edu.my)"
                            errorTextView.isVisible = true
                            auth.signOut()
                            googleSignInClient.signOut()
                            loadingOverlay.isVisible = false
                            googleSignInButton.isEnabled = true
                            Toast.makeText(this, "Please use UPTM email", Toast.LENGTH_LONG).show()
                        }
                    }
                } else {
                    // Sign in failed
                    Log.e(TAG, "Firebase auth failed: ${task.exception?.message}")
                    errorTextView.text = "Authentication failed: ${task.exception?.message}"
                    errorTextView.isVisible = true
                    loadingOverlay.isVisible = false
                    googleSignInButton.isEnabled = true
                    Toast.makeText(this, "Authentication failed", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun proceedToDashboard(email: String, displayName: String) {
        val userRole = getRoleFromEmail(email)
        val studentId = extractStudentIdFromEmail(email)

        val user = User(
            id = auth.currentUser?.uid ?: "",
            name = displayName,
            email = email,
            role = userRole,
            faculty = "Computer Science",
            studentId = studentId
        )

        onLoginSuccess(user)
    }

    private fun onLoginSuccess(user: User) {
        Log.d(TAG, "Login successful, navigating to dashboard for user: ${user.name}")

        // Navigate to appropriate activity based on user role
        val intent = if (user.role == "admin") {
            Intent(this, AdminDashboardActivity::class.java)
        } else {
            Intent(this, DashboardActivity::class.java)
        }

        // Pass user data
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_EMAIL", user.email)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_ID", user.studentId)

        // Clear back stack so user can't go back to login
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

        startActivity(intent)
        finish() // Close login activity
    }

    data class User(
        val id: String,
        val name: String,
        val email: String,
        val role: String,
        val faculty: String,
        val studentId: String
    )
}