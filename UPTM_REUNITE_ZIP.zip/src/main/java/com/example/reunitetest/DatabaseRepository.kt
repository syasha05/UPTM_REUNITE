package com.example.reunitetest.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.provider.BaseColumns
import android.util.Log
import java.text.SimpleDateFormat
import java.util.*

class DatabaseRepository private constructor(context: Context) {
    private val databaseHelper: DatabaseHelper = DatabaseHelper(context)

    companion object {
        @Volatile
        private var INSTANCE: DatabaseRepository? = null

        fun getInstance(context: Context): DatabaseRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: DatabaseRepository(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    // Data classes
    data class User(
        val id: String = "",
        val name: String,
        val email: String,
        val role: String,
        val studentId: String = ""
    )

    data class Item(
        val id: Int,
        val title: String,
        val category: String,
        val description: String,
        val location: String,
        val date: String,
        val time: String,
        val status: String,
        val type: String,
        val reportedBy: String,
        val contactEmail: String,
        val images: List<String>,
        val timeAgo: String
    )

    data class NotificationItem(
        val id: String,
        val type: String,
        val title: String,
        val message: String,
        val timestamp: String,
        val isRead: Boolean,
        val category: String,
        val location: String,
        val itemId: String?
    )

    data class Comment(
        val id: String,
        val itemId: String,
        val userId: String,
        val userName: String,
        val commentText: String,
        val timeAgo: String
    )

    data class Like(
        val id: String,
        val itemId: String,
        val userId: String,
        val createdAt: String
    )

    data class VerificationRequest(
        val id: String,
        val itemId: Int,
        val claimantEmail: String,
        val proofDescription: String,
        val status: String,
        val createdAt: String
    )

    data class InAppMessage(
        val id: String,
        val senderEmail: String,
        val senderName: String,
        val receiverName: String,
        val itemId: Long,
        val messageText: String,
        val isRead: Boolean,
        val createdAt: String
    )

    // User operations
    fun createUser(userId: String, name: String, email: String, role: String = "student", studentId: String = ""): Long {
        val db = databaseHelper.writableDatabase
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val currentTime = dateFormat.format(Date())

        val values = ContentValues().apply {
            put(DataContract.UserEntry.COLUMN_USER_ID, userId)
            put(DataContract.UserEntry.COLUMN_NAME, name)
            put(DataContract.UserEntry.COLUMN_EMAIL, email)
            put(DataContract.UserEntry.COLUMN_ROLE, role)
            put(DataContract.UserEntry.COLUMN_STUDENT_ID, studentId)
            put(DataContract.UserEntry.COLUMN_CREATED_AT, currentTime)
        }

        return db.insert(DataContract.UserEntry.TABLE_NAME, null, values)
    }

    fun getUserByEmail(email: String): User? {
        val db = databaseHelper.readableDatabase
        val cursor = db.query(
            DataContract.UserEntry.TABLE_NAME,
            null,
            "${DataContract.UserEntry.COLUMN_EMAIL} = ?",
            arrayOf(email),
            null, null, null
        )

        return cursor.use {
            if (it.moveToFirst()) {
                User(
                    id = it.getString(it.getColumnIndexOrThrow(DataContract.UserEntry.COLUMN_USER_ID)),
                    name = it.getString(it.getColumnIndexOrThrow(DataContract.UserEntry.COLUMN_NAME)),
                    email = it.getString(it.getColumnIndexOrThrow(DataContract.UserEntry.COLUMN_EMAIL)),
                    role = it.getString(it.getColumnIndexOrThrow(DataContract.UserEntry.COLUMN_ROLE)),
                    studentId = it.getString(it.getColumnIndexOrThrow(DataContract.UserEntry.COLUMN_STUDENT_ID))
                )
            } else {
                null
            }
        }
    }

    fun getAllUsers(): List<User> {
        val users = mutableListOf<User>()
        val db = databaseHelper.readableDatabase
        val cursor = db.query(
            DataContract.UserEntry.TABLE_NAME,
            null,
            null,
            null,
            null, null,
            "${DataContract.UserEntry.COLUMN_CREATED_AT} DESC"
        )

        cursor.use {
            while (it.moveToNext()) {
                users.add(User(
                    id = it.getString(it.getColumnIndexOrThrow(DataContract.UserEntry.COLUMN_USER_ID)),
                    name = it.getString(it.getColumnIndexOrThrow(DataContract.UserEntry.COLUMN_NAME)),
                    email = it.getString(it.getColumnIndexOrThrow(DataContract.UserEntry.COLUMN_EMAIL)),
                    role = it.getString(it.getColumnIndexOrThrow(DataContract.UserEntry.COLUMN_ROLE)),
                    studentId = it.getString(it.getColumnIndexOrThrow(DataContract.UserEntry.COLUMN_STUDENT_ID))
                ))
            }
        }
        return users
    }

    // Get user ID by username
    fun getUserIdByUserName(userName: String): String? {
        val db = databaseHelper.readableDatabase
        val cursor = db.query(
            DataContract.UserEntry.TABLE_NAME,
            arrayOf(DataContract.UserEntry.COLUMN_USER_ID),
            "${DataContract.UserEntry.COLUMN_NAME} = ?",
            arrayOf(userName),
            null, null, null
        )

        return cursor.use {
            if (it.moveToFirst()) {
                it.getString(it.getColumnIndexOrThrow(DataContract.UserEntry.COLUMN_USER_ID))
            } else {
                null
            }
        }
    }

    // Item operations
    fun getItemsByUser(userName: String): List<Item> {
        val items = mutableListOf<Item>()
        val db = databaseHelper.readableDatabase

        val cursor = db.query(
            DataContract.ItemEntry.TABLE_NAME,
            null,
            "${DataContract.ItemEntry.COLUMN_REPORTED_BY} = ? AND ${DataContract.ItemEntry.COLUMN_IS_ACTIVE} = ?",
            arrayOf(userName, "1"),
            null, null,
            "${DataContract.ItemEntry.COLUMN_CREATED_AT} DESC"
        )

        cursor.use {
            while (it.moveToNext()) {
                items.add(Item(
                    id = it.getInt(it.getColumnIndexOrThrow(BaseColumns._ID)),
                    title = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_TITLE)),
                    category = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_CATEGORY)),
                    description = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_DESCRIPTION)),
                    location = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_LOCATION)),
                    date = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_DATE)),
                    time = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_TIME)),
                    status = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_STATUS)),
                    type = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_TYPE)),
                    reportedBy = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_REPORTED_BY)),
                    contactEmail = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_CONTACT_EMAIL)),
                    images = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_IMAGES)).split(","),
                    timeAgo = calculateTimeAgo(it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_CREATED_AT)))
                ))
            }
        }
        return items
    }

    fun insertItem(item: Item): Long {
        val db = databaseHelper.writableDatabase
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val currentTime = dateFormat.format(Date())

        val values = ContentValues().apply {
            put(DataContract.ItemEntry.COLUMN_ITEM_ID, "item_${System.currentTimeMillis()}")
            put(DataContract.ItemEntry.COLUMN_TITLE, item.title)
            put(DataContract.ItemEntry.COLUMN_DESCRIPTION, item.description)
            put(DataContract.ItemEntry.COLUMN_CATEGORY, item.category)
            put(DataContract.ItemEntry.COLUMN_LOCATION, item.location)
            put(DataContract.ItemEntry.COLUMN_DATE, item.date)
            put(DataContract.ItemEntry.COLUMN_TIME, item.time)
            put(DataContract.ItemEntry.COLUMN_STATUS, item.status)
            put(DataContract.ItemEntry.COLUMN_TYPE, item.type)
            put(DataContract.ItemEntry.COLUMN_REPORTED_BY, item.reportedBy)
            put(DataContract.ItemEntry.COLUMN_CONTACT_EMAIL, item.contactEmail)
            put(DataContract.ItemEntry.COLUMN_IMAGES, item.images.joinToString(","))
            put(DataContract.ItemEntry.COLUMN_CREATED_AT, currentTime)
            put(DataContract.ItemEntry.COLUMN_IS_ACTIVE, 1)
        }

        return db.insert(DataContract.ItemEntry.TABLE_NAME, null, values)
    }

    fun getAllItems(): List<Item> {
        val items = mutableListOf<Item>()
        val db = databaseHelper.readableDatabase

        val columns = arrayOf(
            BaseColumns._ID,
            DataContract.ItemEntry.COLUMN_ITEM_ID,
            DataContract.ItemEntry.COLUMN_TITLE,
            DataContract.ItemEntry.COLUMN_DESCRIPTION,
            DataContract.ItemEntry.COLUMN_CATEGORY,
            DataContract.ItemEntry.COLUMN_LOCATION,
            DataContract.ItemEntry.COLUMN_DATE,
            DataContract.ItemEntry.COLUMN_TIME,
            DataContract.ItemEntry.COLUMN_STATUS,
            DataContract.ItemEntry.COLUMN_TYPE,
            DataContract.ItemEntry.COLUMN_REPORTED_BY,
            DataContract.ItemEntry.COLUMN_CONTACT_EMAIL,
            DataContract.ItemEntry.COLUMN_CREATED_AT,
            DataContract.ItemEntry.COLUMN_IS_ACTIVE
        )

        val cursor = db.query(
            DataContract.ItemEntry.TABLE_NAME,
            columns,
            "${DataContract.ItemEntry.COLUMN_IS_ACTIVE} = ?",
            arrayOf("1"),
            null, null,
            "${DataContract.ItemEntry.COLUMN_CREATED_AT} DESC"
        )

        cursor.use {
            while (it.moveToNext()) {
                items.add(Item(
                    id = it.getInt(it.getColumnIndexOrThrow(BaseColumns._ID)),
                    title = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_TITLE)),
                    category = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_CATEGORY)),
                    description = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_DESCRIPTION)),
                    location = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_LOCATION)),
                    date = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_DATE)),
                    time = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_TIME)),
                    status = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_STATUS)),
                    type = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_TYPE)),
                    reportedBy = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_REPORTED_BY)),
                    contactEmail = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_CONTACT_EMAIL)),
                    images = emptyList(),
                    timeAgo = calculateTimeAgo(it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_CREATED_AT)))
                ))
            }
        }
        return items
    }

    fun getItemImages(itemId: Int): List<String> {
        val db = databaseHelper.readableDatabase
        val cursor = db.query(
            DataContract.ItemEntry.TABLE_NAME,
            arrayOf(DataContract.ItemEntry.COLUMN_IMAGES),
            "${BaseColumns._ID} = ?",
            arrayOf(itemId.toString()),
            null, null, null
        )

        return cursor.use {
            if (it.moveToFirst()) {
                it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_IMAGES)).split(",")
            } else {
                emptyList()
            }
        }
    }

    fun searchItems(query: String, category: String = "", location: String = "", status: String = ""): List<Item> {
        val items = mutableListOf<Item>()
        val db = databaseHelper.readableDatabase

        var selection = "${DataContract.ItemEntry.COLUMN_IS_ACTIVE} = ?"
        val selectionArgs = mutableListOf("1")

        if (query.isNotEmpty()) {
            selection += " AND (${DataContract.ItemEntry.COLUMN_TITLE} LIKE ? OR ${DataContract.ItemEntry.COLUMN_DESCRIPTION} LIKE ?)"
            selectionArgs.add("%$query%")
            selectionArgs.add("%$query%")
        }

        if (category.isNotEmpty()) {
            selection += " AND ${DataContract.ItemEntry.COLUMN_CATEGORY} = ?"
            selectionArgs.add(category)
        }

        if (location.isNotEmpty()) {
            selection += " AND ${DataContract.ItemEntry.COLUMN_LOCATION} = ?"
            selectionArgs.add(location)
        }

        if (status.isNotEmpty()) {
            selection += " AND ${DataContract.ItemEntry.COLUMN_STATUS} = ?"
            selectionArgs.add(status)
        }

        val cursor = db.query(
            DataContract.ItemEntry.TABLE_NAME,
            null,
            selection,
            selectionArgs.toTypedArray(),
            null, null,
            "${DataContract.ItemEntry.COLUMN_CREATED_AT} DESC"
        )

        cursor.use {
            while (it.moveToNext()) {
                items.add(Item(
                    id = it.getInt(it.getColumnIndexOrThrow(BaseColumns._ID)),
                    title = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_TITLE)),
                    category = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_CATEGORY)),
                    description = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_DESCRIPTION)),
                    location = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_LOCATION)),
                    date = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_DATE)),
                    time = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_TIME)),
                    status = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_STATUS)),
                    type = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_TYPE)),
                    reportedBy = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_REPORTED_BY)),
                    contactEmail = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_CONTACT_EMAIL)),
                    images = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_IMAGES)).split(","),
                    timeAgo = calculateTimeAgo(it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_CREATED_AT)))
                ))
            }
        }
        return items
    }

    fun getItemById(itemId: Int): Item? {
        val db = databaseHelper.readableDatabase
        val cursor = db.query(
            DataContract.ItemEntry.TABLE_NAME,
            null,
            "${BaseColumns._ID} = ? AND ${DataContract.ItemEntry.COLUMN_IS_ACTIVE} = ?",
            arrayOf(itemId.toString(), "1"),
            null, null, null
        )

        return cursor.use {
            if (it.moveToFirst()) {
                Item(
                    id = it.getInt(it.getColumnIndexOrThrow(BaseColumns._ID)),
                    title = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_TITLE)),
                    category = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_CATEGORY)),
                    description = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_DESCRIPTION)),
                    location = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_LOCATION)),
                    date = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_DATE)),
                    time = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_TIME)),
                    status = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_STATUS)),
                    type = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_TYPE)),
                    reportedBy = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_REPORTED_BY)),
                    contactEmail = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_CONTACT_EMAIL)),
                    images = it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_IMAGES)).split(","),
                    timeAgo = calculateTimeAgo(it.getString(it.getColumnIndexOrThrow(DataContract.ItemEntry.COLUMN_CREATED_AT)))
                )
            } else {
                null
            }
        }
    }

    // Like operations
    fun addLike(itemId: String, userId: String): Long {
        val db = databaseHelper.writableDatabase
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val currentTime = dateFormat.format(Date())

        val values = ContentValues().apply {
            put(DataContract.LikeEntry.COLUMN_LIKE_ID, "like_${System.currentTimeMillis()}")
            put(DataContract.LikeEntry.COLUMN_ITEM_ID, itemId)
            put(DataContract.LikeEntry.COLUMN_USER_ID, userId)
            put(DataContract.LikeEntry.COLUMN_CREATED_AT, currentTime)
        }

        return db.insert(DataContract.LikeEntry.TABLE_NAME, null, values)
    }

    fun removeLike(itemId: String, userId: String): Int {
        val db = databaseHelper.writableDatabase
        return db.delete(
            DataContract.LikeEntry.TABLE_NAME,
            "${DataContract.LikeEntry.COLUMN_ITEM_ID} = ? AND ${DataContract.LikeEntry.COLUMN_USER_ID} = ?",
            arrayOf(itemId, userId)
        )
    }

    fun getLikeCount(itemId: String): Int {
        val db = databaseHelper.readableDatabase
        val cursor = db.rawQuery(
            "SELECT COUNT(*) FROM ${DataContract.LikeEntry.TABLE_NAME} WHERE ${DataContract.LikeEntry.COLUMN_ITEM_ID} = ?",
            arrayOf(itemId)
        )
        return cursor.use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }
    }

    fun isLikedByUser(itemId: String, userId: String): Boolean {
        val db = databaseHelper.readableDatabase
        val cursor = db.query(
            DataContract.LikeEntry.TABLE_NAME,
            null,
            "${DataContract.LikeEntry.COLUMN_ITEM_ID} = ? AND ${DataContract.LikeEntry.COLUMN_USER_ID} = ?",
            arrayOf(itemId, userId),
            null, null, null
        )
        return cursor.use { it.count > 0 }
    }

    // Comment operations
    fun addComment(itemId: String, userId: String, userName: String, commentText: String): Long {
        val db = databaseHelper.writableDatabase
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val currentTime = dateFormat.format(Date())

        val values = ContentValues().apply {
            put(DataContract.CommentEntry.COLUMN_COMMENT_ID, "comment_${System.currentTimeMillis()}")
            put(DataContract.CommentEntry.COLUMN_ITEM_ID, itemId)
            put(DataContract.CommentEntry.COLUMN_USER_ID, userId)
            put(DataContract.CommentEntry.COLUMN_USER_NAME, userName)
            put(DataContract.CommentEntry.COLUMN_COMMENT_TEXT, commentText)
            put(DataContract.CommentEntry.COLUMN_CREATED_AT, currentTime)
        }

        return db.insert(DataContract.CommentEntry.TABLE_NAME, null, values)
    }

    fun getComments(itemId: String): List<Comment> {
        val comments = mutableListOf<Comment>()
        val db = databaseHelper.readableDatabase
        val cursor = db.query(
            DataContract.CommentEntry.TABLE_NAME,
            null,
            "${DataContract.CommentEntry.COLUMN_ITEM_ID} = ?",
            arrayOf(itemId),
            null, null,
            "${DataContract.CommentEntry.COLUMN_CREATED_AT} ASC"
        )

        cursor.use {
            while (it.moveToNext()) {
                comments.add(Comment(
                    id = it.getString(it.getColumnIndexOrThrow(DataContract.CommentEntry.COLUMN_COMMENT_ID)),
                    itemId = it.getString(it.getColumnIndexOrThrow(DataContract.CommentEntry.COLUMN_ITEM_ID)),
                    userId = it.getString(it.getColumnIndexOrThrow(DataContract.CommentEntry.COLUMN_USER_ID)),
                    userName = it.getString(it.getColumnIndexOrThrow(DataContract.CommentEntry.COLUMN_USER_NAME)),
                    commentText = it.getString(it.getColumnIndexOrThrow(DataContract.CommentEntry.COLUMN_COMMENT_TEXT)),
                    timeAgo = calculateTimeAgo(it.getString(it.getColumnIndexOrThrow(DataContract.CommentEntry.COLUMN_CREATED_AT)))
                ))
            }
        }
        return comments
    }

    fun getCommentCount(itemId: String): Int {
        val db = databaseHelper.readableDatabase
        val cursor = db.rawQuery(
            "SELECT COUNT(*) FROM ${DataContract.CommentEntry.TABLE_NAME} WHERE ${DataContract.CommentEntry.COLUMN_ITEM_ID} = ?",
            arrayOf(itemId)
        )
        return cursor.use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }
    }

    // Notification operations
    fun createNotification(type: String, title: String, message: String, userId: String, category: String = "", location: String = "", itemId: String = ""): Long {
        val db = databaseHelper.writableDatabase
        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.getDefault())
        val currentTime = dateFormat.format(Date())

        val values = ContentValues().apply {
            put(DataContract.NotificationEntry.COLUMN_NOTIFICATION_ID, "notif_${System.currentTimeMillis()}")
            put(DataContract.NotificationEntry.COLUMN_TYPE, type)
            put(DataContract.NotificationEntry.COLUMN_TITLE, title)
            put(DataContract.NotificationEntry.COLUMN_MESSAGE, message)
            put(DataContract.NotificationEntry.COLUMN_TIMESTAMP, currentTime)
            put(DataContract.NotificationEntry.COLUMN_IS_READ, 0)
            put(DataContract.NotificationEntry.COLUMN_CATEGORY, category)
            put(DataContract.NotificationEntry.COLUMN_LOCATION, location)
            put(DataContract.NotificationEntry.COLUMN_ITEM_ID, itemId)
            put(DataContract.NotificationEntry.COLUMN_USER_ID, userId)
        }

        return db.insert(DataContract.NotificationEntry.TABLE_NAME, null, values)
    }

    fun getUserNotifications(userId: String): List<NotificationItem> {
        val notifications = mutableListOf<NotificationItem>()
        val db = databaseHelper.readableDatabase
        val cursor = db.query(
            DataContract.NotificationEntry.TABLE_NAME,
            null,
            "${DataContract.NotificationEntry.COLUMN_USER_ID} = ?",
            arrayOf(userId),
            null, null,
            "${DataContract.NotificationEntry.COLUMN_TIMESTAMP} DESC"
        )

        cursor.use {
            while (it.moveToNext()) {
                notifications.add(NotificationItem(
                    id = it.getString(it.getColumnIndexOrThrow(DataContract.NotificationEntry.COLUMN_NOTIFICATION_ID)),
                    type = it.getString(it.getColumnIndexOrThrow(DataContract.NotificationEntry.COLUMN_TYPE)),
                    title = it.getString(it.getColumnIndexOrThrow(DataContract.NotificationEntry.COLUMN_TITLE)),
                    message = it.getString(it.getColumnIndexOrThrow(DataContract.NotificationEntry.COLUMN_MESSAGE)),
                    timestamp = it.getString(it.getColumnIndexOrThrow(DataContract.NotificationEntry.COLUMN_TIMESTAMP)),
                    isRead = it.getInt(it.getColumnIndexOrThrow(DataContract.NotificationEntry.COLUMN_IS_READ)) == 1,
                    category = it.getString(it.getColumnIndexOrThrow(DataContract.NotificationEntry.COLUMN_CATEGORY)),
                    location = it.getString(it.getColumnIndexOrThrow(DataContract.NotificationEntry.COLUMN_LOCATION)),
                    itemId = it.getString(it.getColumnIndexOrThrow(DataContract.NotificationEntry.COLUMN_ITEM_ID))
                ))
            }
        }
        return notifications
    }

    fun markNotificationAsRead(notificationId: String): Int {
        val db = databaseHelper.writableDatabase
        val values = ContentValues().apply {
            put(DataContract.NotificationEntry.COLUMN_IS_READ, 1)
        }

        return db.update(
            DataContract.NotificationEntry.TABLE_NAME,
            values,
            "${DataContract.NotificationEntry.COLUMN_NOTIFICATION_ID} = ?",
            arrayOf(notificationId)
        )
    }

    fun markAllNotificationsAsRead(userId: String): Int {
        val db = databaseHelper.writableDatabase
        val values = ContentValues().apply {
            put(DataContract.NotificationEntry.COLUMN_IS_READ, 1)
        }

        return db.update(
            DataContract.NotificationEntry.TABLE_NAME,
            values,
            "${DataContract.NotificationEntry.COLUMN_USER_ID} = ?",
            arrayOf(userId)
        )
    }

    // Update item status
    fun updateItemStatus(itemId: Int, newStatus: String): Int {
        val db = databaseHelper.writableDatabase
        val values = ContentValues().apply {
            put(DataContract.ItemEntry.COLUMN_STATUS, newStatus)
        }

        return db.update(
            DataContract.ItemEntry.TABLE_NAME,
            values,
            "${BaseColumns._ID} = ?",
            arrayOf(itemId.toString())
        )
    }

    // Remove item (soft delete)
    fun removeItem(itemId: Int): Int {
        val db = databaseHelper.writableDatabase
        val values = ContentValues().apply {
            put(DataContract.ItemEntry.COLUMN_IS_ACTIVE, 0)
        }

        return db.update(
            DataContract.ItemEntry.TABLE_NAME,
            values,
            "${BaseColumns._ID} = ?",
            arrayOf(itemId.toString())
        )
    }

    // FIXED: Only ONE flagItem method (remove the duplicate)
    fun flagItem(itemId: Int): Int {
        val db = databaseHelper.writableDatabase
        val values = ContentValues().apply {
            put(DataContract.ItemEntry.COLUMN_STATUS, "flagged")
        }

        return db.update(
            DataContract.ItemEntry.TABLE_NAME,
            values,
            "${BaseColumns._ID} = ?",
            arrayOf(itemId.toString())
        )
    }

    fun checkAndFlagSuspiciousItems() {
        val allItems = getAllItems()

        allItems.forEach { item ->
            val suspiciousKeywords = listOf("free", "money", "click", "http", "www")
            val hasSuspiciousContent = suspiciousKeywords.any { keyword ->
                item.title.contains(keyword, ignoreCase = true) ||
                        item.description.contains(keyword, ignoreCase = true)
            }

            if (hasSuspiciousContent && item.status != "flagged") {
                flagItem(item.id)
            }
        }
    }

    // Verification methods
    fun addVerificationRequest(itemId: Int, claimantEmail: String, proofDescription: String): Long {
        val db = databaseHelper.writableDatabase
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val currentTime = dateFormat.format(Date())

        val values = ContentValues().apply {
            put("verification_id", "verify_${System.currentTimeMillis()}")
            put("item_id", itemId)
            put("claimant_email", claimantEmail)
            put("proof_description", proofDescription)
            put("status", "pending")
            put("created_at", currentTime)
        }

        return db.insert("verification_requests", null, values)
    }

    fun getVerificationRequests(itemId: Int): List<VerificationRequest> {
        val requests = mutableListOf<VerificationRequest>()
        val db = databaseHelper.readableDatabase
        val cursor = db.query(
            "verification_requests",
            null,
            "item_id = ?",
            arrayOf(itemId.toString()),
            null, null,
            "created_at DESC"
        )

        cursor.use {
            while (it.moveToNext()) {
                requests.add(VerificationRequest(
                    id = it.getString(it.getColumnIndexOrThrow("verification_id")),
                    itemId = it.getInt(it.getColumnIndexOrThrow("item_id")),
                    claimantEmail = it.getString(it.getColumnIndexOrThrow("claimant_email")),
                    proofDescription = it.getString(it.getColumnIndexOrThrow("proof_description")),
                    status = it.getString(it.getColumnIndexOrThrow("status")),
                    createdAt = it.getString(it.getColumnIndexOrThrow("created_at"))
                ))
            }
        }
        return requests
    }

    // In DatabaseRepository.kt - ENSURE this method exists and works:

    fun addInAppMessage(
        senderEmail: String,
        senderName: String,
        receiverName: String,
        itemId: Long,
        messageText: String
    ): Long {
        val db = databaseHelper.writableDatabase
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val currentTime = dateFormat.format(Date())

        return try {
            // Check if messages table exists
            val cursor = db.rawQuery(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='in_app_messages'",
                null
            )
            val tableExists = cursor.use { it.moveToFirst() }
            if (!tableExists) {
                Log.e("Database", "in_app_messages table doesn't exist")
                return -1
            }

            val values = ContentValues().apply {
                put("message_id", "msg_${System.currentTimeMillis()}")
                put("sender_email", senderEmail)
                put("sender_name", senderName)
                put("receiver_name", receiverName)
                put("item_id", itemId)
                put("message_text", messageText)
                put("is_read", 0)
                put("created_at", currentTime)
            }

            val result = db.insert("in_app_messages", null, values)
            Log.d("Database", "Message inserted with result: $result")
            result
        } catch (e: Exception) {
            Log.e("Database", "Error inserting message: ${e.message}", e)
            -1
        }
    }

    // FIXED: Improved getConversationMessages method
    fun getConversationMessages(user1: String, user2: String): List<InAppMessage> {
        val messages = mutableListOf<InAppMessage>()
        val db = databaseHelper.readableDatabase

        return try {
            val cursor = db.rawQuery(
                """
                SELECT * FROM in_app_messages 
                WHERE (sender_name = ? AND receiver_name = ?) 
                   OR (sender_name = ? AND receiver_name = ?) 
                ORDER BY created_at ASC
                """.trimIndent(),
                arrayOf(user1, user2, user2, user1)
            )

            cursor.use {
                while (it.moveToNext()) {
                    messages.add(InAppMessage(
                        id = it.getString(it.getColumnIndexOrThrow("message_id")),
                        senderEmail = it.getString(it.getColumnIndexOrThrow("sender_email")),
                        senderName = it.getString(it.getColumnIndexOrThrow("sender_name")),
                        receiverName = it.getString(it.getColumnIndexOrThrow("receiver_name")),
                        itemId = it.getLong(it.getColumnIndexOrThrow("item_id")),
                        messageText = it.getString(it.getColumnIndexOrThrow("message_text")),
                        isRead = it.getInt(it.getColumnIndexOrThrow("is_read")) == 1,
                        createdAt = it.getString(it.getColumnIndexOrThrow("created_at"))
                    ))
                }
            }
            messages
        } catch (e: Exception) {
            Log.e("Database", "Error loading messages: ${e.message}", e)
            emptyList()
        }
    }

    fun getUserConversations(userName: String): List<String> {
        val conversations = mutableSetOf<String>()
        val db = databaseHelper.readableDatabase

        try {
            val cursor = db.rawQuery(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='in_app_messages'",
                null
            )
            val tableExists = cursor.use { it.moveToFirst() }
            if (!tableExists) {
                Log.e("Database", "in_app_messages table doesn't exist")
                return emptyList()
            }

            val conversationCursor = db.rawQuery(
                """
                SELECT DISTINCT 
                    CASE 
                        WHEN sender_name = ? THEN receiver_name 
                        ELSE sender_name 
                    END as other_user
                FROM in_app_messages 
                WHERE sender_name = ? OR receiver_name = ?
                ORDER BY created_at DESC
                """.trimIndent(),
                arrayOf(userName, userName, userName)
            )

            conversationCursor.use {
                while (it.moveToNext()) {
                    val otherUser = it.getString(it.getColumnIndexOrThrow("other_user"))
                    if (otherUser != userName) {
                        conversations.add(otherUser)
                    }
                }
            }

            Log.d("Database", "Found ${conversations.size} conversations for $userName")
            return conversations.toList()

        } catch (e: Exception) {
            Log.e("Database", "Error getting conversations: ${e.message}", e)
            return emptyList()
        }
    }

    fun getUnreadMessageCount(userName: String): Int {
        val db = databaseHelper.readableDatabase
        val cursor = db.rawQuery(
            "SELECT COUNT(*) FROM in_app_messages WHERE receiver_name = ? AND is_read = 0",
            arrayOf(userName)
        )
        return cursor.use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }
    }

    fun markMessagesAsRead(senderName: String, receiverName: String): Int {
        val db = databaseHelper.writableDatabase
        val values = ContentValues().apply {
            put("is_read", 1)
        }

        return try {
            db.update(
                "in_app_messages",
                values,
                "sender_name = ? AND receiver_name = ? AND is_read = 0",
                arrayOf(senderName, receiverName)
            )
        } catch (e: Exception) {
            Log.e("Database", "Error marking messages as read: ${e.message}")
            0
        }
    }


    private fun calculateTimeAgo(createdAt: String): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val createdDate = dateFormat.parse(createdAt)
        val currentDate = Date()

        val diff = currentDate.time - (createdDate?.time ?: 0)
        val seconds = diff / 1000
        val minutes = seconds / 60
        val hours = minutes / 60
        val days = hours / 24

        return when {
            days > 0 -> "$days days ago"
            hours > 0 -> "$hours hours ago"
            minutes > 0 -> "$minutes minutes ago"
            else -> "Just now"
        }
    }
}