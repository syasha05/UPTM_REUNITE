package com.example.reunitetest

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat

class SettingsActivity : AppCompatActivity() {

    private lateinit var backButton: ImageButton
    private lateinit var darkModeSwitch: Switch
    private lateinit var notificationsSwitch: Switch
    private lateinit var notificationNewItemSwitch: Switch
    private lateinit var notificationMessageSwitch: Switch
    private lateinit var notificationStatusSwitch: Switch
    private lateinit var helpButton: Button
    private lateinit var aboutButton: Button
    private lateinit var logoutButton: Button

    private lateinit var sharedPreferences: SharedPreferences

    companion object {
        private const val PREFS_NAME = "ReUnitePrefs"
        private const val KEY_DARK_MODE = "dark_mode"
        private const val KEY_NOTIFICATIONS = "notifications_enabled"
        private const val KEY_NOTIF_NEW_ITEM = "notif_new_item"
        private const val KEY_NOTIF_MESSAGE = "notif_message"
        private const val KEY_NOTIF_STATUS = "notif_status"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Apply saved theme before setting content view
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        applySavedTheme()
        
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        initializeViews()
        loadSavedSettings()
        setupClickListeners()
    }

    private fun initializeViews() {
        backButton = findViewById(R.id.back_button)
        darkModeSwitch = findViewById(R.id.dark_mode_switch)
        notificationsSwitch = findViewById(R.id.notifications_switch)
        notificationNewItemSwitch = findViewById(R.id.notification_new_item_switch)
        notificationMessageSwitch = findViewById(R.id.notification_message_switch)
        notificationStatusSwitch = findViewById(R.id.notification_status_switch)
        helpButton = findViewById(R.id.help_button)
        aboutButton = findViewById(R.id.about_button)
        logoutButton = findViewById(R.id.logout_button)
    }

    private fun applySavedTheme() {
        val isDarkMode = sharedPreferences.getBoolean(KEY_DARK_MODE, false)
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    private fun loadSavedSettings() {
        // Load dark mode setting
        darkModeSwitch.isChecked = sharedPreferences.getBoolean(KEY_DARK_MODE, false)
        
        // Load notification settings
        notificationsSwitch.isChecked = sharedPreferences.getBoolean(KEY_NOTIFICATIONS, true)
        notificationNewItemSwitch.isChecked = sharedPreferences.getBoolean(KEY_NOTIF_NEW_ITEM, true)
        notificationMessageSwitch.isChecked = sharedPreferences.getBoolean(KEY_NOTIF_MESSAGE, true)
        notificationStatusSwitch.isChecked = sharedPreferences.getBoolean(KEY_NOTIF_STATUS, true)
        
        // Update notification switches enabled state based on master switch
        updateNotificationSwitchesState(notificationsSwitch.isChecked)
    }

    private fun setupClickListeners() {
        backButton.setOnClickListener {
            onBackPressed()
        }

        darkModeSwitch.setOnCheckedChangeListener { _, isChecked ->
            // Save setting
            sharedPreferences.edit().putBoolean(KEY_DARK_MODE, isChecked).apply()
            
            // Apply theme
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                Toast.makeText(this, "Dark mode enabled", Toast.LENGTH_SHORT).show()
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                Toast.makeText(this, "Dark mode disabled", Toast.LENGTH_SHORT).show()
            }
        }

        notificationsSwitch.setOnCheckedChangeListener { _, isChecked ->
            // Save setting
            sharedPreferences.edit().putBoolean(KEY_NOTIFICATIONS, isChecked).apply()
            
            // Update sub-switches state
            updateNotificationSwitchesState(isChecked)
            
            val message = if (isChecked) "Notifications enabled" else "Notifications disabled"
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }

        notificationNewItemSwitch.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean(KEY_NOTIF_NEW_ITEM, isChecked).apply()
            Toast.makeText(this, if (isChecked) "New item notifications ON" else "New item notifications OFF", Toast.LENGTH_SHORT).show()
        }

        notificationMessageSwitch.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean(KEY_NOTIF_MESSAGE, isChecked).apply()
            Toast.makeText(this, if (isChecked) "Message notifications ON" else "Message notifications OFF", Toast.LENGTH_SHORT).show()
        }

        notificationStatusSwitch.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean(KEY_NOTIF_STATUS, isChecked).apply()
            Toast.makeText(this, if (isChecked) "Status update notifications ON" else "Status update notifications OFF", Toast.LENGTH_SHORT).show()
        }

        helpButton.setOnClickListener {
            openHelpManual()
        }

        aboutButton.setOnClickListener {
            openAboutDialog()
        }

        logoutButton.setOnClickListener {
            onLogout()
        }
    }

    private fun updateNotificationSwitchesState(enabled: Boolean) {
        notificationNewItemSwitch.isEnabled = enabled
        notificationMessageSwitch.isEnabled = enabled
        notificationStatusSwitch.isEnabled = enabled
    }

    private fun openHelpManual() {
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Help & Manual")
            .setMessage("Welcome to ReUnite!\n\nHere you can:\n• Enable/disable dark mode\n• Manage notifications\n• Get help with the app\n• Learn more about ReUnite")
            .setPositiveButton("OK", null)
            .create()
        dialog.show()
    }

    private fun openAboutDialog() {
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("About ReUnite")
            .setMessage("ReUnite v1.0\n\nA lost and found platform for university community.\n\nDeveloped to help students and staff reunite with their lost items.")
            .setPositiveButton("OK", null)
            .create()
        dialog.show()
    }

    private fun onLogout() {
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Logout") { _, _ ->
                performLogout()
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show()
    }

    private fun performLogout() {
        // Navigate back to login screen
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show()
    }
}