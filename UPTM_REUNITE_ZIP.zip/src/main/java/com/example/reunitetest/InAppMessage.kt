package com.example.reunitetest.data

import java.text.SimpleDateFormat
import java.util.*

data class InAppMessage(
    val id: Long = 0,
    val senderEmail: String,
    val senderName: String,
    val receiverName: String,
    val itemId: Long,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun getFormattedTime(): String {
        val date = Date(timestamp)
        val format = SimpleDateFormat("HH:mm", Locale.getDefault())
        return format.format(date)
    }
}