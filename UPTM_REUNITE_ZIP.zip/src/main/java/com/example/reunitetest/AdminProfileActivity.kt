package com.example.reunitetest

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.reunitetest.data.DatabaseRepository
import com.example.reunitetest.data.User

class AdminProfileActivity : AppCompatActivity() {

    // Data classes
    data class AdminStats(
        val totalReports: Int,
        val resolvedCases: Int,
        val activeUsers: Int,
        val flaggedItems: Int,
        val successRate: String
    )

    // UI References
    private lateinit var adminWelcomeText: TextView
    private lateinit var userNameText: TextView
    private lateinit var userRoleBadge: TextView
    private lateinit var emailText: TextView
    private lateinit var totalReportsText: TextView
    private lateinit var resolvedCasesText: TextView
    private lateinit var activeUsersText: TextView
    private lateinit var flaggedItemsText: TextView
    private lateinit var successRateText: TextView
    private lateinit var settingsButton: ImageButton
    private lateinit var adminIdText: TextView
    private lateinit var backButton: ImageButton

    private lateinit var user: User
    private var adminStats = AdminStats(0, 0, 0, 0, "0%")
    private val recentActivities = mutableListOf<DatabaseRepository.Item>()

    // Database
    private lateinit var databaseRepository: DatabaseRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_profile)

        databaseRepository = DatabaseRepository.getInstance(this)
        initializeUserData()
        initializeAdminViews()
        setupAdminClickListeners()
        setupAdminUI()
        loadAdminData()
    }

    private fun initializeUserData() {
        val userName = intent.getStringExtra("USER_NAME") ?: "Admin"
        val userRole = intent.getStringExtra("USER_ROLE") ?: "admin"
        val userEmail = intent.getStringExtra("USER_EMAIL") ?: "admin@uptm.edu.my"
        val userFaculty = intent.getStringExtra("USER_FACULTY") ?: "Administration"
        val studentId = intent.getStringExtra("USER_ID") ?: "ADM001"

        user = User(userName, userRole, userEmail, userFaculty, studentId)
    }

    private fun initializeAdminViews() {
        // Header views from XML
        backButton = findViewById(R.id.back_button)
        adminWelcomeText = findViewById(R.id.welcome_text)
        settingsButton = findViewById(R.id.settings_button)

        // Profile info views
        userNameText = findViewById(R.id.user_name_text)
        adminIdText = findViewById(R.id.admin_id_text)
        userRoleBadge = findViewById(R.id.user_role_badge)
        emailText = findViewById(R.id.email_text)

        // Statistics views
        totalReportsText = findViewById(R.id.total_reports_text)
        resolvedCasesText = findViewById(R.id.resolved_cases_text)
        activeUsersText = findViewById(R.id.active_users_text)
        flaggedItemsText = findViewById(R.id.flagged_items_text)
        successRateText = findViewById(R.id.success_rate_text)

    }

    private fun setupAdminClickListeners() {
        // Back button - navigate back to previous activity
        backButton.setOnClickListener {
            onBackPressed()
        }

        // Settings button
        settingsButton.setOnClickListener {
            navigateToSettings()
        }

        // Note: The XML doesn't have bottom navigation or refresh button
        // If you need them, you'll need to add them to the XML first
    }

    private fun setupAdminUI() {
        adminWelcomeText.text = "Admin Profile"
        updateUserInfo()
    }

    private fun updateUserInfo() {
        userNameText.text = user.name
        adminIdText.text = "ID: ${user.studentId}"
        emailText.text = user.email

        userRoleBadge.text = "Administrator"
        userRoleBadge.setBackgroundColor(ContextCompat.getColor(this, R.color.color_admin))
    }

    private fun loadAdminData() {
        showAdminLoadingStates()

        Handler(Looper.getMainLooper()).postDelayed({
            loadAdminStats()
            updateAdminUI()
            hideAdminLoadingStates()
        }, 800)
    }

    private fun showAdminLoadingStates() {
        listOf(totalReportsText, resolvedCasesText, activeUsersText, flaggedItemsText, successRateText).forEach { textView ->
            textView.text = "..."
        }
    }

    private fun hideAdminLoadingStates() {
        // Loading states are hidden when real data is displayed
    }

    private fun loadAdminStats() {
        try {
            val allItems = databaseRepository.getAllItems()
            val allUsers = databaseRepository.getAllUsers()
            val recentItems = allItems.sortedByDescending { it.id }.take(10)

            recentActivities.clear()
            recentActivities.addAll(recentItems)

            val totalReports = allItems.size
            val resolvedCases = allItems.count { it.status.equals("reunited", ignoreCase = true) }
            val activeUsers = allUsers.size
            val flaggedItems = allItems.count { it.status.equals("flagged", ignoreCase = true) }

            val successRate = if (totalReports > 0) {
                (resolvedCases * 100 / totalReports)
            } else {
                0
            }

            adminStats = AdminStats(
                totalReports = totalReports,
                resolvedCases = resolvedCases,
                activeUsers = activeUsers,
                flaggedItems = flaggedItems,
                successRate = "$successRate%"
            )
        } catch (e: Exception) {
            adminStats = AdminStats(0, 0, 0, 0, "0%")
        }
    }

    private fun updateAdminUI() {
        // Update statistics
        totalReportsText.text = adminStats.totalReports.toString()
        resolvedCasesText.text = adminStats.resolvedCases.toString()
        activeUsersText.text = adminStats.activeUsers.toString()
        flaggedItemsText.text = adminStats.flaggedItems.toString()
        successRateText.text = adminStats.successRate

    }

    private fun createActivityView(activity: DatabaseRepository.Item): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 12)
            }
            setBackgroundResource(R.drawable.card_background)
            setPadding(16, 12, 16, 12)
            isClickable = true
        }

        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val typeText = TextView(this).apply {
            text = "${activity.type.uppercase()} REPORT"
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@AdminProfileActivity, R.color.color_primary))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
        }

        val timeText = TextView(this).apply {
            text = activity.timeAgo
            textSize = 10f
            setTextColor(ContextCompat.getColor(this@AdminProfileActivity, R.color.color_text_secondary))
        }

        headerLayout.addView(typeText)
        headerLayout.addView(timeText)

        val titleText = TextView(this).apply {
            text = activity.title
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@AdminProfileActivity, R.color.color_black))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 4, 0, 0)
        }

        val reporterText = TextView(this).apply {
            text = "By: ${activity.reportedBy}"
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@AdminProfileActivity, R.color.color_text_secondary))
        }

        val footerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4, 0, 0)
            }
        }

        val statusBadge = TextView(this).apply {
            text = activity.status.uppercase()
            textSize = 10f
            setTextColor(ContextCompat.getColor(this@AdminProfileActivity, android.R.color.white))
            setPadding(6, 2, 6, 2)
            setBackgroundColor(
                ContextCompat.getColor(this@AdminProfileActivity,
                    when (activity.status.lowercase()) {
                        "reunited" -> R.color.color_success
                        "found" -> R.color.color_found
                        "lost" -> R.color.color_lost
                        "flagged" -> R.color.color_error
                        else -> R.color.color_warning
                    }
                )
            )
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = 8
            }
        }

        val locationText = TextView(this).apply {
            text = "📍 ${activity.location}"
            textSize = 10f
            setTextColor(ContextCompat.getColor(this@AdminProfileActivity, R.color.color_text_secondary))
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
        }

        footerLayout.addView(statusBadge)
        footerLayout.addView(locationText)

        layout.addView(headerLayout)
        layout.addView(titleText)
        layout.addView(reporterText)
        layout.addView(footerLayout)

        layout.setOnClickListener {
            Toast.makeText(this, "Viewing: ${activity.title}", Toast.LENGTH_SHORT).show()
        }

        return layout
    }

    // Navigation methods
    private fun navigateToSettings() {
        try {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot open settings", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        loadAdminData()
    }
}