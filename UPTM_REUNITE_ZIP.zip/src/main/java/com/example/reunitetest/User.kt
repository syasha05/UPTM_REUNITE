package com.example.reunitetest.data

data class User(
    val name: String,
    val role: String,
    val email: String = "",
    val faculty: String = "",
    val studentId: String = ""
)