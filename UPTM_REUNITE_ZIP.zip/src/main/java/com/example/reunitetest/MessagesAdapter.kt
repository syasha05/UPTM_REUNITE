package com.example.reunitetest

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.reunitetest.data.DatabaseRepository
import com.example.reunitetest.data.User

class MessagesAdapter(
    private val context: Context,
    private var conversations: List<String> = emptyList(),
    private var messages: List<DatabaseRepository.InAppMessage> = emptyList(),
    private val currentUser: User? = null,
    private val currentUserName: String = "",
    private val onUserClick: ((String) -> Unit)? = null,
    private val mode: Int
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val MODE_CONVERSATIONS = 1
        const val MODE_CHAT = 2
    }

    private val databaseRepository = DatabaseRepository.getInstance(context)

    // Custom ViewHolder that stores references to created views
    class CustomViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // Store references to the TextViews we create
        var userName: TextView? = null
        var lastMessage: TextView? = null
        var timeStamp: TextView? = null
        var messageText: TextView? = null
        var messageTime: TextView? = null
        var bubbleLayout: LinearLayout? = null // Store reference to bubble layout
    }

    override fun getItemViewType(position: Int): Int {
        return mode
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            MODE_CONVERSATIONS -> createConversationViewHolder(parent)
            MODE_CHAT -> createMessageViewHolder(parent)
            else -> throw IllegalArgumentException("Invalid mode")
        }
    }

    private fun createConversationViewHolder(parent: ViewGroup): CustomViewHolder {
        // Create conversation item programmatically
        val itemView = LinearLayout(parent.context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 16)
            }
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            background = ContextCompat.getDrawable(context, R.drawable.bg_edittext)
        }

        // User name
        val userName = TextView(context).apply {
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(context, R.color.color_black))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // Last message
        val lastMessage = TextView(context).apply {
            textSize = 14f
            setTextColor(ContextCompat.getColor(context, R.color.color_text_secondary))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4, 0, 0)
            }
        }

        // Time stamp
        val timeStamp = TextView(context).apply {
            textSize = 12f
            setTextColor(ContextCompat.getColor(context, R.color.color_text_hint))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4, 0, 0)
            }
            gravity = Gravity.END
        }

        itemView.addView(userName)
        itemView.addView(lastMessage)
        itemView.addView(timeStamp)

        val viewHolder = CustomViewHolder(itemView)
        viewHolder.userName = userName
        viewHolder.lastMessage = lastMessage
        viewHolder.timeStamp = timeStamp

        return viewHolder
    }

    private fun createMessageViewHolder(parent: ViewGroup): CustomViewHolder {
        // Create message bubble programmatically
        val itemView = LinearLayout(parent.context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(16, 8, 16, 8)
            }
            orientation = LinearLayout.VERTICAL
        }

        // Message bubble container
        val bubbleLayout = LinearLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            // Set default background (will be updated in bind)
            setBackgroundColor(ContextCompat.getColor(context, R.color.color_primary))
        }

        // Message text
        val messageText = TextView(context).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // Message time
        val messageTime = TextView(context).apply {
            textSize = 10f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4, 0, 0)
            }
            gravity = Gravity.END
        }

        bubbleLayout.addView(messageText)
        bubbleLayout.addView(messageTime)
        itemView.addView(bubbleLayout)

        val viewHolder = CustomViewHolder(itemView)
        viewHolder.messageText = messageText
        viewHolder.messageTime = messageTime
        viewHolder.bubbleLayout = bubbleLayout // Store bubble layout reference

        return viewHolder
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val customHolder = holder as CustomViewHolder

        when (mode) {
            MODE_CONVERSATIONS -> bindConversationViewHolder(customHolder, position)
            MODE_CHAT -> bindMessageViewHolder(customHolder, position)
        }
    }

    private fun bindConversationViewHolder(holder: CustomViewHolder, position: Int) {
        val otherUser = conversations[position]
        holder.userName?.text = otherUser

        // Load last message
        val lastMessage = getLastMessage(otherUser)
        holder.lastMessage?.text = lastMessage?.messageText ?: "Tap to start conversation"

        // Show timestamp
        holder.timeStamp?.text = lastMessage?.let { formatTime(it.createdAt) } ?: ""

        holder.itemView.setOnClickListener {
            onUserClick?.invoke(otherUser)
        }
    }

    private fun bindMessageViewHolder(holder: CustomViewHolder, position: Int) {
        val message = messages[position]
        val isSent = message.senderName == currentUserName

        // Set message content
        holder.messageText?.text = message.messageText
        holder.messageTime?.text = formatTime(message.createdAt)

        // Style based on sender using the stored bubbleLayout reference
        holder.bubbleLayout?.let { bubble ->
            // Set background color based on sender
            val backgroundColor = if (isSent) {
                ContextCompat.getColor(context, R.color.color_primary)
            } else {
                ContextCompat.getColor(context, R.color.color_text_hint)
            }
            bubble.setBackgroundColor(backgroundColor)

            // Set gravity (alignment) based on sender
            (holder.itemView as LinearLayout).gravity = if (isSent) Gravity.END else Gravity.START

            // Set margins based on sender
            val layoutParams = bubble.layoutParams as LinearLayout.LayoutParams
            layoutParams.setMargins(
                if (isSent) 50 else 0,
                0,
                if (isSent) 0 else 50,
                0
            )
            bubble.layoutParams = layoutParams
        }
    }

    override fun getItemCount(): Int {
        return when (mode) {
            MODE_CONVERSATIONS -> conversations.size
            MODE_CHAT -> messages.size
            else -> 0
        }
    }

    // Helper methods for conversations mode
    private fun getLastMessage(otherUser: String): DatabaseRepository.InAppMessage? {
        val messages = databaseRepository.getConversationMessages(currentUser?.name ?: "", otherUser)
        return messages.lastOrNull()
    }

    // Update messages for chat mode
    fun updateMessages(newMessages: List<DatabaseRepository.InAppMessage>) {
        if (mode == MODE_CHAT) {
            messages = newMessages
            notifyDataSetChanged()
        }
    }

    // Update conversations for conversations mode
    fun updateConversations(newConversations: List<String>) {
        if (mode == MODE_CONVERSATIONS) {
            conversations = newConversations
            notifyDataSetChanged()
        }
    }

    private fun formatTime(createdAt: String): String {
        return try {
            if (createdAt.length >= 16) {
                createdAt.substring(11, 16) // HH:mm
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }
    }
}