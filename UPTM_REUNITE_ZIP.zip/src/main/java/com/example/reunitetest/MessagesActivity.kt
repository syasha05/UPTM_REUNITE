package com.example.reunitetest

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.reunitetest.data.DatabaseRepository
import com.example.reunitetest.data.User
import com.example.reunitetest.utils.NotificationHelper

class MessagesActivity : AppCompatActivity() {

    private lateinit var user: User
    private lateinit var databaseRepository: DatabaseRepository

    // Containers
    private lateinit var conversationsContainer: LinearLayout
    private lateinit var chatContainer: LinearLayout

    // Conversations List Views
    private lateinit var conversationsRecyclerView: RecyclerView
    private lateinit var emptyState: LinearLayout
    private lateinit var titleText: TextView

    // Chat Views
    private lateinit var chatRecyclerView: RecyclerView
    private lateinit var messageInput: EditText
    private lateinit var sendButton: ImageButton
    private lateinit var backButton: ImageButton
    private lateinit var chatTitle: TextView

    // Navigation
    private lateinit var navHome: ImageButton
    private lateinit var navSearch: ImageButton
    private lateinit var navMessages: ImageButton
    private lateinit var navProfile: ImageButton

    // Chat variables
    private lateinit var currentChatUser: String
    private lateinit var messagesAdapter: MessagesAdapter
    private val messageRefreshHandler = Handler(Looper.getMainLooper())
    private val messageRefreshRunnable = object : Runnable {
        override fun run() {
            if (::currentChatUser.isInitialized) {
                loadChatMessages()
            }
            messageRefreshHandler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_messages)

        try {
            databaseRepository = DatabaseRepository.getInstance(this)
            initializeUserData()
            initializeViews()
            setupBottomNavigation()

            // Check if we should open chat directly (from FeedAdapter)
            val shouldOpenChatDirectly = intent.getBooleanExtra("OPEN_CHAT_DIRECTLY", false)
            val directChatUser = intent.getStringExtra("OTHER_USER")

            if (shouldOpenChatDirectly && !directChatUser.isNullOrEmpty()) {
                // Open chat directly with the specified user
                openChatWith(directChatUser)
                // Send automatic intro message if this is a new conversation
                sendIntroMessage(directChatUser)
            } else {
                showConversationsList()
            }

        } catch (e: Exception) {
            Toast.makeText(this, "Error initializing messages: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        messageRefreshHandler.removeCallbacks(messageRefreshRunnable)
    }

    private fun initializeUserData() {
        val userName = intent.getStringExtra("USER_NAME") ?: "user"
        val userRole = intent.getStringExtra("USER_ROLE") ?: "student"
        val userEmail = intent.getStringExtra("USER_EMAIL") ?: "${userName.replace(" ", ".").lowercase()}@student.uptm.edu.my"

        user = User(
            name = userName,
            email = userEmail,
            role = userRole,
            studentId = "STU${(10000..99999).random()}"
        )
    }

    private fun initializeViews() {
        // Containers
        conversationsContainer = findViewById(R.id.conversations_container)
        chatContainer = findViewById(R.id.chat_container)

        // Conversations List Views
        conversationsRecyclerView = findViewById(R.id.conversations_recycler_view)
        emptyState = findViewById(R.id.empty_state)
        titleText = findViewById(R.id.title_text)

        // Chat Views
        chatRecyclerView = findViewById(R.id.chat_recycler_view)
        messageInput = findViewById(R.id.message_input)
        sendButton = findViewById(R.id.send_button)
        backButton = findViewById(R.id.back_button)
        chatTitle = findViewById(R.id.chat_title)

        // Navigation
        navHome = findViewById(R.id.nav_home)
        navSearch = findViewById(R.id.nav_search)
        navMessages = findViewById(R.id.nav_messages)
        navProfile = findViewById(R.id.nav_profile)

        // Setup RecyclerViews
        conversationsRecyclerView.layoutManager = LinearLayoutManager(this)
        chatRecyclerView.layoutManager = LinearLayoutManager(this)

        // Back button - goes back to conversations list
        backButton.setOnClickListener {
            showConversationsList()
        }

        // Send message button
        sendButton.setOnClickListener {
            sendMessage()
        }

        // Send on Enter key
        messageInput.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_ENTER && event.action == android.view.KeyEvent.ACTION_DOWN) {
                sendMessage()
                return@setOnKeyListener true
            }
            false
        }
    }

    // ==================== CONVERSATIONS LIST MODE ====================
    private fun showConversationsList() {
        conversationsContainer.visibility = View.VISIBLE
        chatContainer.visibility = View.GONE
        loadConversations()
        messageRefreshHandler.removeCallbacks(messageRefreshRunnable)
    }

    private fun loadConversations() {
        try {
            val conversations = databaseRepository.getUserConversations(user.name)
            Log.d("MessagesActivity", "Loaded ${conversations.size} conversations")

            if (conversations.isEmpty()) {
                showEmptyState()
            } else {
                hideEmptyState()
                val adapter = MessagesAdapter(
                    context = this,
                    conversations = conversations,
                    currentUser = user,
                    onUserClick = { otherUser ->
                        openChatWith(otherUser)
                    },
                    mode = MessagesAdapter.MODE_CONVERSATIONS
                )
                conversationsRecyclerView.adapter = adapter
            }
        } catch (e: Exception) {
            Log.e("MessagesActivity", "Error loading conversations: ${e.message}", e)
            showEmptyState()
            Toast.makeText(this, "No messages yet", Toast.LENGTH_SHORT).show()
        }
    }

    // ==================== CHAT MODE ====================
    private fun openChatWith(otherUser: String) {
        currentChatUser = otherUser
        showChat()

        // Send automatic intro message for new conversations
        sendIntroMessage(otherUser)
    }

    private fun showChat() {
        conversationsContainer.visibility = View.GONE
        chatContainer.visibility = View.VISIBLE
        chatTitle.text = currentChatUser

        loadChatMessages()
        messageRefreshHandler.postDelayed(messageRefreshRunnable, 2000)

        // Focus on message input for better UX
        messageInput.requestFocus()
    }

    private fun loadChatMessages() {
        Thread {
            try {
                val messages = databaseRepository.getConversationMessages(user.name, currentChatUser)
                runOnUiThread {
                    if (::messagesAdapter.isInitialized) {
                        messagesAdapter.updateMessages(messages)
                    } else {
                        messagesAdapter = MessagesAdapter(
                            context = this,
                            messages = messages,
                            currentUserName = user.name,
                            mode = MessagesAdapter.MODE_CHAT
                        )
                        chatRecyclerView.adapter = messagesAdapter
                    }

                    // Scroll to bottom if there are messages
                    if (messages.isNotEmpty()) {
                        chatRecyclerView.scrollToPosition(messages.size - 1)
                    }

                    // Show helpful message if this is a new conversation
                    if (messages.isEmpty()) {
                        Toast.makeText(this, "Start a conversation with $currentChatUser!", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                Log.e("MessagesActivity", "Error loading chat messages: ${e.message}", e)
                runOnUiThread {
                    Toast.makeText(this, "Error loading messages", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun sendMessage() {
        val messageText = messageInput.text.toString().trim()
        if (messageText.isEmpty()) {
            Toast.makeText(this, "Please type a message", Toast.LENGTH_SHORT).show()
            return
        }

        Thread {
            try {
                val result = databaseRepository.addInAppMessage(
                    senderEmail = user.email,
                    senderName = user.name,
                    receiverName = currentChatUser,
                    itemId = 0L,
                    messageText = messageText
                )

                runOnUiThread {
                    if (result != -1L) {
                        messageInput.text.clear()
                        loadChatMessages() // Refresh to show the new message

                        // Create notification in database for the receiver
                        databaseRepository.createNotification(
                            type = "message",
                            title = "New Message from ${user.name}",
                            message = messageText.take(50) + if (messageText.length > 50) "..." else "",
                            userId = databaseRepository.getUserIdByUserName(currentChatUser) ?: "general",
                            category = "chat",
                            location = "",
                            itemId = "0"
                        )

                        // Send push notification for the message
                        NotificationHelper.sendMessageNotification(
                            context = this,
                            senderName = user.name,
                            messageText = messageText,
                            userName = user.name,
                            userEmail = user.email,
                            userRole = user.role
                        )

                    } else {
                        Toast.makeText(this, "Failed to send message. Please try again.", Toast.LENGTH_SHORT).show()
                        Log.e("MessagesActivity", "Database insert failed for message")
                    }
                }
            } catch (e: Exception) {
                Log.e("MessagesActivity", "Error sending message: ${e.message}", e)
                runOnUiThread {
                    Toast.makeText(this, "Error sending message: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }
    private fun sendIntroMessage(otherUser: String) {
        Thread {
            try {
                // Check if there are already messages in this conversation
                val existingMessages = databaseRepository.getConversationMessages(user.name, otherUser)

                if (existingMessages.isEmpty()) {
                    // Get item info from intent if available
                    val itemTitle = intent.getStringExtra("ITEM_TITLE") ?: "your item"
                    val itemStatus = intent.getStringExtra("ITEM_STATUS") ?: "lost/found"

                    val introMessage = when (itemStatus.lowercase()) {
                        "found" -> "Hello! I'd like to claim your found item: $itemTitle"
                        "lost" -> "Hello! I might have information about your lost item: $itemTitle"
                        else -> "Hello! I'm interested in your $itemStatus item: $itemTitle"
                    }

                    val result = databaseRepository.addInAppMessage(
                        senderEmail = user.email,
                        senderName = user.name,
                        receiverName = otherUser,
                        itemId = 0L,
                        messageText = introMessage
                    )

                    if (result != -1L) {
                        Log.d("MessagesActivity", "Intro message sent to $otherUser")
                        runOnUiThread {
                            loadChatMessages() // Refresh to show the intro message
                        }
                    } else {
                        Log.e("MessagesActivity", "Failed to send intro message")
                    }
                }
            } catch (e: Exception) {
                Log.e("MessagesActivity", "Error sending intro message: ${e.message}")
            }
        }.start()
    }

    // ==================== COMMON METHODS ====================
    private fun showEmptyState() {
        emptyState.visibility = View.VISIBLE
        conversationsRecyclerView.visibility = View.GONE

        // Update empty state text
        val emptyTitle = emptyState.findViewById<TextView>(R.id.empty_title)
        val emptyDescription = emptyState.findViewById<TextView>(R.id.empty_description)

        emptyTitle.text = "No conversations yet"
        emptyDescription.text = "Start a conversation by contacting someone from a post!"
    }

    private fun hideEmptyState() {
        emptyState.visibility = View.GONE
        conversationsRecyclerView.visibility = View.VISIBLE
    }

    private fun setupBottomNavigation() {
        navHome.setOnClickListener { navigateToHome() }
        navSearch.setOnClickListener { navigateToSearch() }
        navMessages.setOnClickListener {
            if (conversationsContainer.visibility == View.VISIBLE) {
                loadConversations() // Refresh conversations
            } else {
                showConversationsList() // Go back to conversations list from chat
            }
        }
        navProfile.setOnClickListener { navigateToProfile() }
    }

    private fun navigateToHome() {
        val intent = Intent(this, DashboardActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        startActivity(intent)
        finish()
    }

    private fun navigateToSearch() {
        val intent = Intent(this, SearchItemsActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        startActivity(intent)
        finish()
    }

    private fun navigateToProfile() {
        val intent = Intent(this, ProfileActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        startActivity(intent)
        finish()
    }

    override fun onResume() {
        super.onResume()
        // Refresh data when returning to the activity
        if (conversationsContainer.visibility == View.VISIBLE) {
            loadConversations()
        } else if (chatContainer.visibility == View.VISIBLE && ::currentChatUser.isInitialized) {
            loadChatMessages()
        }
    }

    override fun onBackPressed() {
        if (chatContainer.visibility == View.VISIBLE) {
            // If in chat mode, go back to conversations list
            showConversationsList()
        } else {
            // If in conversations list, use normal back behavior
            super.onBackPressed()
        }
    }
}