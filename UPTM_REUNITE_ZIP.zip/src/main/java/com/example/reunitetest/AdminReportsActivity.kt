package com.example.reunitetest

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.reunitetest.data.DatabaseRepository
import com.example.reunitetest.data.User
import java.io.File

class AdminReportsActivity : AppCompatActivity() {

    // UI References
    private lateinit var adminWelcomeText: TextView
    private lateinit var activityContainer: LinearLayout
    private lateinit var emptyActivityState: LinearLayout

    // Buttons
    private lateinit var adminProfileButton: ImageButton
    private lateinit var adminDashboardButton: ImageButton
    private lateinit var adminReportsButton: ImageButton
    private lateinit var adminFlaggedButton: ImageButton

    private lateinit var user: User
    private lateinit var databaseRepository: DatabaseRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_reports)

        databaseRepository = DatabaseRepository.getInstance(this)
        initializeUserData()
        initializeAdminViews()
        setupAdminClickListeners()
        setupAdminUI()
        loadAdminData()
    }

    private fun initializeUserData() {
        val userName = intent.getStringExtra("USER_NAME") ?: "Admin"
        val userRole = intent.getStringExtra("USER_ROLE") ?: "admin"
        val userEmail = intent.getStringExtra("USER_EMAIL") ?: "admin@uptm.edu.my"
        val userFaculty = intent.getStringExtra("USER_FACULTY") ?: "Administration"
        val studentId = intent.getStringExtra("USER_ID") ?: "ADM001"

        user = User(userName, userRole, userEmail, userFaculty, studentId)
    }

    private fun initializeAdminViews() {
        adminWelcomeText = findViewById(R.id.welcome_text)
        adminProfileButton = findViewById(R.id.profile_button)

        activityContainer = findViewById(R.id.reports_container)
        emptyActivityState = findViewById(R.id.empty_reports_state)

        // Bottom nav
        adminDashboardButton = findViewById(R.id.nav_dashboard)
        adminReportsButton = findViewById(R.id.nav_reports)
        adminFlaggedButton = findViewById(R.id.nav_flagged)
    }

    private fun setupAdminClickListeners() {
        adminProfileButton.setOnClickListener { navigateToAdminProfile() }
        // REMOVED: adminRefreshButton click listener

        adminDashboardButton.setOnClickListener {
            navigateToAdminDashboard()
            updateAdminNavigationState(adminDashboardButton)
        }
        adminReportsButton.setOnClickListener {
            // Already on reports, just refresh
            loadAdminData()
            updateAdminNavigationState(adminReportsButton)
        }
        adminFlaggedButton.setOnClickListener {
            navigateToAdminFlagged()
            updateAdminNavigationState(adminFlaggedButton)
        }
    }

    private fun updateAdminNavigationState(selectedButton: ImageButton) {
        val buttons = listOf(adminDashboardButton, adminReportsButton, adminFlaggedButton)

        buttons.forEach { button ->
            val isSelected = button == selectedButton
            button.setColorFilter(
                ContextCompat.getColor(this,
                    if (isSelected) R.color.color_primary else R.color.color_black
                )
            )
            button.isSelected = isSelected
        }
    }
    private fun setupAdminUI() {
        adminWelcomeText.text = "Recent Activity"
        updateAdminNavigationState(adminReportsButton)
    }

    private fun loadAdminData() {
        showAdminLoadingStates()

        Handler(Looper.getMainLooper()).postDelayed({
            displayRecentActivity()
            hideAdminLoadingStates()
        }, 800)
    }

    private fun showAdminLoadingStates() {
        emptyActivityState.visibility = View.GONE
        activityContainer.removeAllViews()

        val loadingLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 40, 0, 40)
            }
        }

        val progressBar = ProgressBar(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val loadingText = TextView(this).apply {
            text = "Loading recent activity..."
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@AdminReportsActivity, R.color.color_text_secondary))
            setTextAlignment(View.TEXT_ALIGNMENT_CENTER)
            setPadding(0, 16, 0, 0)
        }

        loadingLayout.addView(progressBar)
        loadingLayout.addView(loadingText)
        activityContainer.addView(loadingLayout)
    }

    private fun hideAdminLoadingStates() {
        // Loading states are hidden when real data is displayed
    }

    private fun displayRecentActivity() {
        activityContainer.removeAllViews()
        emptyActivityState.visibility = View.GONE

        val recentItems = databaseRepository.getAllItems()
            .sortedByDescending { it.id }
            .take(15)

        if (recentItems.isEmpty()) {
            showEmptyActivityState()
            return
        }

        // Group items by type for better organization
        val groupedItems = recentItems.groupBy {
            when {
                it.status.equals("reunited", ignoreCase = true) -> "reunited"
                it.status.equals("flagged", ignoreCase = true) -> "flagged"
                else -> it.type
            }
        }

        // Display items in priority order: flagged -> reunited -> lost -> found
        val priorityOrder = listOf("flagged", "reunited", "lost", "found")

        for (category in priorityOrder) {
            groupedItems[category]?.forEach { item ->
                val itemView = createFeedItemView(item)
                activityContainer.addView(itemView)
            }
        }
    }

    private fun createFeedItemView(item: DatabaseRepository.Item): View {
        val itemView = LayoutInflater.from(this).inflate(R.layout.item_feed, activityContainer, false)

        val userAvatar = itemView.findViewById<TextView>(R.id.user_avatar)
        val userName = itemView.findViewById<TextView>(R.id.user_name)
        val postTime = itemView.findViewById<TextView>(R.id.post_time)
        val itemTitle = itemView.findViewById<TextView>(R.id.item_title)
        val itemDescription = itemView.findViewById<TextView>(R.id.item_description)
        val itemLocation = itemView.findViewById<TextView>(R.id.item_location)
        val itemDate = itemView.findViewById<TextView>(R.id.item_date)
        val itemTime = itemView.findViewById<TextView>(R.id.item_time)
        val statusBadge = itemView.findViewById<TextView>(R.id.status_badge)
        val likeButton = itemView.findViewById<ImageButton>(R.id.like_button)
        val commentButton = itemView.findViewById<ImageButton>(R.id.comment_button)
        val shareButton = itemView.findViewById<ImageButton>(R.id.share_button)
        val likesCount = itemView.findViewById<TextView>(R.id.likes_count)
        val commentsCount = itemView.findViewById<TextView>(R.id.comments_count)
        val itemImage = itemView.findViewById<ImageView>(R.id.item_image)
        val updateStatusButton = itemView.findViewById<Button>(R.id.update_status_button)

        // Set item data
        userAvatar.text = item.reportedBy.take(1).uppercase()
        userName.text = item.reportedBy
        postTime.text = item.timeAgo
        itemTitle.text = item.title
        itemDescription.text = item.description
        itemLocation.text = "📍 ${item.location}"
        itemDate.text = "📅 ${item.date}"
        itemTime.text = "⏰ ${item.time}"

        // Get like and comment counts
        val likeCount = databaseRepository.getLikeCount(item.id.toString())
        val commentCount = databaseRepository.getCommentCount(item.id.toString())
        likesCount.text = likeCount.toString()
        commentsCount.text = commentCount.toString()

        // Load image
        loadImageForItem(item.id, itemImage)

        // Set up status badge with appropriate color
        statusBadge.text = getStatusText(item).uppercase()
        statusBadge.setBackgroundColor(getStatusColor(item))

        // Admin status update button
        setupAdminStatusButton(item, updateStatusButton)

        // Set up like button (admin can see but not interact)
        likeButton.setImageResource(android.R.drawable.btn_star_big_off)
        likeButton.setColorFilter(ContextCompat.getColor(this, R.color.color_text_secondary))
        likeButton.isEnabled = false // Admin cannot like posts

        // Set up comment button (admin can view comments)
        commentButton.setOnClickListener {
            showCommentsDialog(item)
        }

        // Set up share button
        shareButton.setOnClickListener {
            shareItem(item)
        }

        return itemView
    }

    private fun loadImageForItem(itemId: Int, imageView: ImageView) {
        Thread {
            try {
                val images = databaseRepository.getItemImages(itemId)
                if (images.isNotEmpty()) {
                    val firstImage = images[0]
                    runOnUiThread {
                        if (firstImage.startsWith("/")) {
                            // It's a file path
                            val imageFile = File(firstImage)
                            if (imageFile.exists()) {
                                Glide.with(this)
                                    .load(imageFile.absolutePath)
                                    .placeholder(R.drawable.ic_placeholder)
                                    .error(R.drawable.ic_placeholder)
                                    .centerCrop()
                                    .into(imageView)
                                imageView.visibility = View.VISIBLE
                            } else {
                                imageView.visibility = View.GONE
                            }
                        } else if (firstImage.startsWith("data:image")) {
                            // It's Base64
                            Glide.with(this)
                                .load(firstImage)
                                .placeholder(R.drawable.ic_placeholder)
                                .error(R.drawable.ic_placeholder)
                                .centerCrop()
                                .into(imageView)
                            imageView.visibility = View.VISIBLE
                        } else {
                            imageView.visibility = View.GONE
                        }
                    }
                } else {
                    runOnUiThread {
                        imageView.visibility = View.GONE
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    imageView.visibility = View.GONE
                }
            }
        }.start()
    }

    private fun getStatusText(item: DatabaseRepository.Item): String {
        return when {
            item.status.equals("reunited", ignoreCase = true) -> "REUNITED"
            item.status.equals("flagged", ignoreCase = true) -> "FLAGGED"
            item.type.equals("lost", ignoreCase = true) -> "LOST"
            else -> "FOUND"
        }
    }

    private fun getStatusColor(item: DatabaseRepository.Item): Int {
        return ContextCompat.getColor(this,
            when {
                item.status.equals("reunited", ignoreCase = true) -> R.color.color_success
                item.status.equals("flagged", ignoreCase = true) -> R.color.color_error
                item.type.equals("lost", ignoreCase = true) -> R.color.color_lost
                else -> R.color.color_found
            }
        )
    }

    private fun showCommentsDialog(item: DatabaseRepository.Item) {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_comments)

        val commentsList = dialog.findViewById<LinearLayout>(R.id.comments_list)
        val commentInput = dialog.findViewById<EditText>(R.id.comment_input)
        val postCommentButton = dialog.findViewById<Button>(R.id.post_comment_button)

        // Admin cannot post comments, so hide the input section
        commentInput.visibility = View.GONE
        postCommentButton.visibility = View.GONE

        loadComments(item.id.toString(), commentsList)

        dialog.show()
    }

    private fun loadComments(itemId: String, commentsList: LinearLayout) {
        val comments = databaseRepository.getComments(itemId)

        commentsList.removeAllViews()

        for (comment in comments) {
            val commentView = LayoutInflater.from(this).inflate(R.layout.item_comment, commentsList, false)

            val userName = commentView.findViewById<TextView>(R.id.user_name)
            val commentText = commentView.findViewById<TextView>(R.id.comment_text)
            val commentTime = commentView.findViewById<TextView>(R.id.comment_time)

            userName.text = comment.userName
            commentText.text = comment.commentText
            commentTime.text = comment.timeAgo

            commentsList.addView(commentView)
        }
    }

    private fun setupAdminStatusButton(item: DatabaseRepository.Item, button: Button?) {
        // Admin can change status for any item
        button?.visibility = View.VISIBLE
        
        when (item.status.lowercase()) {
            "lost" -> {
                button?.text = "Admin: Mark as Found"
                button?.setOnClickListener {
                    showAdminStatusChangeDialog(item, "found")
                }
            }
            "found" -> {
                button?.text = "Admin: Mark as ReUnite"
                button?.setOnClickListener {
                    showAdminStatusChangeDialog(item, "reunited")
                }
            }
            "reunited" -> {
                button?.text = "Status: ReUnited ✓"
                button?.isEnabled = false
            }
            else -> {
                button?.visibility = View.GONE
            }
        }
    }

    private fun showAdminStatusChangeDialog(item: DatabaseRepository.Item, newStatus: String) {
        val (title, message) = when (newStatus) {
            "found" -> Pair(
                "Mark Item as Found",
                "Change '${item.title}' status from Lost to Found?"
            )
            "reunited" -> Pair(
                "Mark Item as ReUnite",
                "Mark '${item.title}' as successfully reunited with owner?"
            )
            else -> Pair("Update Status", "Update item status?")
        }

        android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Yes") { dialog, _ ->
                updateItemStatus(item.id, newStatus)
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun updateItemStatus(itemId: Int, newStatus: String) {
        val result = databaseRepository.updateItemStatus(itemId, newStatus)
        if (result > 0) {
            val statusText = when (newStatus) {
                "found" -> "Found"
                "reunited" -> "ReUnited"
                else -> newStatus.capitalize()
            }
            Toast.makeText(this, "Item marked as $statusText", Toast.LENGTH_SHORT).show()
            loadAdminData() // Refresh the list
        } else {
            Toast.makeText(this, "Failed to update item status", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareItem(item: DatabaseRepository.Item) {
        val shareMessage = """
        ${if (item.type.lowercase() == "lost") "🚨 LOST ITEM" else "🎉 FOUND ITEM"}
        
        📋 ${item.title}
        📍 ${item.location}
        📅 ${item.date} at ${item.time}
        
        ${item.description}
        
        👤 Reported by: ${item.reportedBy}
        📧 Contact: ${item.contactEmail}
        
        Status: ${item.status.uppercase()}
        
        ${if (item.type.lowercase() == "lost") "Please help find this item!" else "Please contact if this is yours!"}
    """.trimIndent()

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "${item.type.uppercase()}: ${item.title}")
            putExtra(Intent.EXTRA_TEXT, shareMessage)
        }

        startActivity(Intent.createChooser(shareIntent, "Share Item Report"))
    }

    private fun showEmptyActivityState() {
        emptyActivityState.visibility = View.VISIBLE
    }

    // Navigation methods
    private fun navigateToAdminProfile() {
        val intent = Intent(this, AdminProfileActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        intent.putExtra("USER_ID", user.studentId)
        startActivity(intent)
    }

    private fun navigateToAdminDashboard() {
        val intent = Intent(this, AdminDashboardActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        intent.putExtra("USER_ID", user.studentId)
        startActivity(intent)
    }

    private fun navigateToAdminFlagged() {
        val intent = Intent(this, AdminFlaggedActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        intent.putExtra("USER_ID", user.studentId)
        startActivity(intent)
    }

    override fun onResume() {
        super.onResume()
        loadAdminData()
        updateAdminNavigationState(adminReportsButton)
    }
}