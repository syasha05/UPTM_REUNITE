package com.example.reunitetest.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.reunitetest.DashboardActivity
import com.example.reunitetest.MainActivity
import com.example.reunitetest.MessagesActivity
import com.example.reunitetest.R

object NotificationHelper {

    // Notification Channel IDs
    private const val CHANNEL_ID_MESSAGES = "messages_channel"
    private const val CHANNEL_ID_REPORTS = "reports_channel"
    private const val CHANNEL_ID_STATUS = "status_channel"
    private const val CHANNEL_ID_GENERAL = "general_channel"

    // Notification Types
    const val TYPE_MESSAGE = "message"
    const val TYPE_CHAT = "chat"
    const val TYPE_REPORT = "report"
    const val TYPE_UPLOAD = "upload"
    const val TYPE_STATUS_UPDATE = "status_update"
    const val TYPE_FOUND = "found"
    const val TYPE_REUNITED = "reunited"
    const val TYPE_GENERAL = "general"

    /**
     * Initialize notification channels (for Android O and above)
     */
    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Messages Channel
            val messagesChannel = NotificationChannel(
                CHANNEL_ID_MESSAGES,
                "Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for new chat messages"
                enableLights(true)
                lightColor = android.graphics.Color.BLUE
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 250, 250)
            }

            // Reports Channel
            val reportsChannel = NotificationChannel(
                CHANNEL_ID_REPORTS,
                "Item Reports",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for new lost/found item reports"
                enableLights(true)
                lightColor = android.graphics.Color.GREEN
                enableVibration(true)
            }

            // Status Updates Channel
            val statusChannel = NotificationChannel(
                CHANNEL_ID_STATUS,
                "Status Updates",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for item status changes (found, reunited)"
                enableLights(true)
                lightColor = android.graphics.Color.YELLOW
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500)
            }

            // General Channel
            val generalChannel = NotificationChannel(
                CHANNEL_ID_GENERAL,
                "General",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "General notifications"
                enableLights(true)
                enableVibration(true)
            }

            // Create all channels
            notificationManager.createNotificationChannel(messagesChannel)
            notificationManager.createNotificationChannel(reportsChannel)
            notificationManager.createNotificationChannel(statusChannel)
            notificationManager.createNotificationChannel(generalChannel)
        }
    }

    /**
     * Send a local notification
     */
    fun sendNotification(
        context: Context,
        type: String,
        title: String,
        message: String,
        itemId: String? = null,
        category: String? = null,
        location: String? = null,
        userName: String? = null,
        userEmail: String? = null,
        userRole: String? = null
    ) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Determine channel based on type
        val channelId = when (type) {
            TYPE_MESSAGE, TYPE_CHAT -> CHANNEL_ID_MESSAGES
            TYPE_REPORT, TYPE_UPLOAD -> CHANNEL_ID_REPORTS
            TYPE_STATUS_UPDATE, TYPE_FOUND, TYPE_REUNITED -> CHANNEL_ID_STATUS
            else -> CHANNEL_ID_GENERAL
        }

        // Create intent based on notification type
        val intent = createIntentForType(
            context, type, itemId, category, location,
            userName, userEmail, userRole
        )
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)

        val pendingIntent = PendingIntent.getActivity(
            context,
            System.currentTimeMillis().toInt(),
            intent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )

        // Get icon based on type
        val iconRes = getIconForType(type)

        // Get default notification sound
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        // Build notification
        val notificationBuilder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(iconRes)
            .setContentTitle(title)
            .setContentText(message)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setColor(context.getColor(R.color.color_primary))

        // Add category based on type
        when (type) {
            TYPE_MESSAGE, TYPE_CHAT -> {
                notificationBuilder.setCategory(NotificationCompat.CATEGORY_MESSAGE)
            }
            TYPE_STATUS_UPDATE, TYPE_FOUND, TYPE_REUNITED -> {
                notificationBuilder.setCategory(NotificationCompat.CATEGORY_EVENT)
            }
            else -> {
                notificationBuilder.setCategory(NotificationCompat.CATEGORY_STATUS)
            }
        }

        // Show notification
        val notificationId = System.currentTimeMillis().toInt()
        notificationManager.notify(notificationId, notificationBuilder.build())
    }

    /**
     * Create intent based on notification type
     */
    private fun createIntentForType(
        context: Context,
        type: String,
        itemId: String?,
        category: String?,
        location: String?,
        userName: String?,
        userEmail: String?,
        userRole: String?
    ): Intent {
        return when (type) {
            TYPE_MESSAGE, TYPE_CHAT -> {
                Intent(context, MessagesActivity::class.java).apply {
                    putExtra("NOTIFICATION_TYPE", type)
                    itemId?.let { putExtra("ITEM_ID", it) }
                    userName?.let { putExtra("USER_NAME", it) }
                    userEmail?.let { putExtra("USER_EMAIL", it) }
                    userRole?.let { putExtra("USER_ROLE", it) }
                }
            }
            TYPE_REPORT, TYPE_UPLOAD, TYPE_STATUS_UPDATE, TYPE_FOUND, TYPE_REUNITED -> {
                Intent(context, DashboardActivity::class.java).apply {
                    putExtra("NOTIFICATION_TYPE", type)
                    itemId?.let { putExtra("ITEM_ID", it) }
                    category?.let { putExtra("CATEGORY", it) }
                    location?.let { putExtra("LOCATION", it) }
                    userName?.let { putExtra("USER_NAME", it) }
                    userEmail?.let { putExtra("USER_EMAIL", it) }
                    userRole?.let { putExtra("USER_ROLE", it) }
                }
            }
            else -> {
                Intent(context, MainActivity::class.java)
            }
        }
    }

    /**
     * Get icon resource based on notification type
     */
    private fun getIconForType(type: String): Int {
        return when (type) {
            TYPE_MESSAGE, TYPE_CHAT -> R.drawable.ic_messagesfeed
            TYPE_REPORT, TYPE_UPLOAD -> R.drawable.ic_upload
            TYPE_STATUS_UPDATE, TYPE_FOUND, TYPE_REUNITED -> R.drawable.ic_heart_outline
            else -> R.drawable.ic_launcher_foreground
        }
    }

    /**
     * Send notification for new message
     */
    fun sendMessageNotification(
        context: Context,
        senderName: String,
        messageText: String,
        userName: String?,
        userEmail: String?,
        userRole: String?
    ) {
        sendNotification(
            context = context,
            type = TYPE_MESSAGE,
            title = "New message from $senderName",
            message = messageText,
            userName = userName,
            userEmail = userEmail,
            userRole = userRole
        )
    }

    /**
     * Send notification for new report upload
     */
    fun sendReportUploadNotification(
        context: Context,
        reportType: String,
        itemTitle: String,
        category: String,
        location: String,
        userName: String?,
        userEmail: String?,
        userRole: String?
    ) {
        sendNotification(
            context = context,
            type = TYPE_UPLOAD,
            title = "$reportType Item Report Submitted",
            message = "Your $reportType item report for \"$itemTitle\" has been submitted successfully.",
            category = category,
            location = location,
            userName = userName,
            userEmail = userEmail,
            userRole = userRole
        )
    }

    /**
     * Send notification for item status update
     */
    fun sendStatusUpdateNotification(
        context: Context,
        itemTitle: String,
        newStatus: String,
        itemId: String?,
        userName: String?,
        userEmail: String?,
        userRole: String?
    ) {
        val statusText = when (newStatus.lowercase()) {
            "found" -> "Found"
            "reunited" -> "ReUnited"
            else -> newStatus
        }

        sendNotification(
            context = context,
            type = TYPE_STATUS_UPDATE,
            title = "Item Status Updated",
            message = "Your item \"$itemTitle\" has been marked as $statusText!",
            itemId = itemId,
            userName = userName,
            userEmail = userEmail,
            userRole = userRole
        )
    }

    /**
     * Send notification when item is found
     */
    fun sendItemFoundNotification(
        context: Context,
        itemTitle: String,
        location: String,
        itemId: String?,
        userName: String?,
        userEmail: String?,
        userRole: String?
    ) {
        sendNotification(
            context = context,
            type = TYPE_FOUND,
            title = "🎉 Item Found!",
            message = "Your lost item \"$itemTitle\" has been found at $location!",
            itemId = itemId,
            location = location,
            userName = userName,
            userEmail = userEmail,
            userRole = userRole
        )
    }

    /**
     * Send notification when item is reunited
     */
    fun sendItemReunitedNotification(
        context: Context,
        itemTitle: String,
        itemId: String?,
        userName: String?,
        userEmail: String?,
        userRole: String?
    ) {
        sendNotification(
            context = context,
            type = TYPE_REUNITED,
            title = "🎊 Item ReUnited!",
            message = "Great news! The item \"$itemTitle\" has been successfully reunited with its owner!",
            itemId = itemId,
            userName = userName,
            userEmail = userEmail,
            userRole = userRole
        )
    }
}
