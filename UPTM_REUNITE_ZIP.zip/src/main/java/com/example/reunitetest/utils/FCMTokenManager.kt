package com.example.reunitetest.utils

import android.content.Context
import android.util.Log
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.messaging.FirebaseMessaging

object FCMTokenManager {

    private const val TAG = "FCMTokenManager"
    private const val PREFS_NAME = "FCM"
    private const val KEY_FCM_TOKEN = "fcm_token"

    /**
     * Get FCM token and save it to SharedPreferences
     */
    fun getAndSaveToken(context: Context, onTokenReceived: ((String) -> Unit)? = null) {
        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w(TAG, "Fetching FCM registration token failed", task.exception)
                return@OnCompleteListener
            }

            // Get new FCM registration token
            val token = task.result
            Log.d(TAG, "FCM Token: $token")

            // Save token to SharedPreferences
            saveTokenToPreferences(context, token)

            // Callback with token
            onTokenReceived?.invoke(token)

            // TODO: If you have a backend server, send the token to it
            // sendTokenToServer(token)
        })
    }

    /**
     * Save FCM token to SharedPreferences
     */
    private fun saveTokenToPreferences(context: Context, token: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_FCM_TOKEN, token)
            .apply()
        Log.d(TAG, "FCM token saved to SharedPreferences")
    }

    /**
     * Get saved FCM token from SharedPreferences
     */
    fun getSavedToken(context: Context): String? {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_FCM_TOKEN, null)
    }

    /**
     * Subscribe to a topic
     */
    fun subscribeToTopic(topic: String, onSuccess: (() -> Unit)? = null, onFailure: ((Exception) -> Unit)? = null) {
        FirebaseMessaging.getInstance().subscribeToTopic(topic)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Log.d(TAG, "Subscribed to topic: $topic")
                    onSuccess?.invoke()
                } else {
                    Log.e(TAG, "Failed to subscribe to topic: $topic", task.exception)
                    task.exception?.let { onFailure?.invoke(it) }
                }
            }
    }

    /**
     * Unsubscribe from a topic
     */
    fun unsubscribeFromTopic(topic: String, onSuccess: (() -> Unit)? = null, onFailure: ((Exception) -> Unit)? = null) {
        FirebaseMessaging.getInstance().unsubscribeFromTopic(topic)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Log.d(TAG, "Unsubscribed from topic: $topic")
                    onSuccess?.invoke()
                } else {
                    Log.e(TAG, "Failed to unsubscribe from topic: $topic", task.exception)
                    task.exception?.let { onFailure?.invoke(it) }
                }
            }
    }

    /**
     * Delete FCM token
     */
    fun deleteToken(context: Context, onComplete: ((Boolean) -> Unit)? = null) {
        FirebaseMessaging.getInstance().deleteToken()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Log.d(TAG, "FCM token deleted successfully")
                    // Remove from SharedPreferences
                    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit()
                        .remove(KEY_FCM_TOKEN)
                        .apply()
                    onComplete?.invoke(true)
                } else {
                    Log.e(TAG, "Failed to delete FCM token", task.exception)
                    onComplete?.invoke(false)
                }
            }
    }

    /**
     * Check if notification permissions are enabled (for Android 13+)
     */
    fun hasNotificationPermission(context: Context): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == 
                android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            true // No permission needed for older versions
        }
    }
}
