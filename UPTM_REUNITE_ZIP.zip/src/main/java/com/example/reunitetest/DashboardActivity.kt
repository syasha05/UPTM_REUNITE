package com.example.reunitetest

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.*
import android.view.View
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.reunitetest.adapter.FeedAdapter
import com.example.reunitetest.data.DatabaseRepository
import com.example.reunitetest.data.FeedItem
import com.example.reunitetest.data.User
import com.example.reunitetest.utils.NotificationHelper
import com.example.reunitetest.utils.FCMTokenManager
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat

class DashboardActivity : AppCompatActivity() {

    // UI References
    private lateinit var welcomeText: TextView
    private lateinit var feedContainer: LinearLayout
    private lateinit var emptyFeedState: LinearLayout
    private lateinit var floatingReportButton: ImageButton
    private lateinit var feedTitleText: TextView

    private lateinit var user: User
    private lateinit var databaseRepository: DatabaseRepository
    private lateinit var feedAdapter: FeedAdapter
    private val feedItems = mutableListOf<FeedItem>()

    private var isShowingUserPosts = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Initialize notification channels
        NotificationHelper.createNotificationChannels(this)
        
        // Request notification permission for Android 13+
        requestNotificationPermission()
        
        // Get and save FCM token
        FCMTokenManager.getAndSaveToken(this)

        // Test database first
        try {
            databaseRepository = DatabaseRepository.getInstance(this)
            val testItems = databaseRepository.getAllItems()
            Log.d("DatabaseTest", "Database test successful. Items count: ${testItems.size}")
        } catch (e: Exception) {
            Log.e("DatabaseTest", "Database initialization failed: ${e.message}", e)
            Toast.makeText(this, "Database error: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }

        initializeUserData()
        initializeViews()
        setupAdapter()
        setupBottomNavigation()
        setupUI()
        loadCommunityFeed()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }
    }

    private fun initializeUserData() {
        val userName = intent.getStringExtra("USER_NAME") ?: "user"
        val userRole = intent.getStringExtra("USER_ROLE") ?: "student"
        val userEmail = intent.getStringExtra("USER_EMAIL") ?: "${userName.replace(" ", ".").lowercase()}@student.uptm.edu.my"
        val userFaculty = intent.getStringExtra("USER_FACULTY") ?: "Faculty of Computer Science & IT"
        val studentId = intent.getStringExtra("USER_ID") ?: "STU${(10000..99999).random()}"

        user = User(userName, userRole, userEmail, userFaculty, studentId)
    }

    private fun initializeViews() {
        welcomeText = findViewById(R.id.welcome_text)
        feedContainer = findViewById(R.id.feed_container)
        emptyFeedState = findViewById(R.id.empty_feed_state)
        floatingReportButton = findViewById(R.id.floating_report_button)
        feedTitleText = findViewById(R.id.feed_title_text)
    }

    private fun setupAdapter() {
        feedAdapter = FeedAdapter(
            context = this,
            feedItems = feedItems,
            databaseRepository = databaseRepository,
            currentUser = user,
            onItemUpdate = {
                // Refresh when items update (like toggles, etc.)
                loadCommunityFeed()
            },
            onCommentClick = { item ->
                showCommentsDialog(item)
            }
        )
    }

    private fun setupBottomNavigation() {
        val homeButton: ImageButton = findViewById(R.id.nav_home)
        val searchButton: ImageButton = findViewById(R.id.nav_search)
        val profileButton: ImageButton = findViewById(R.id.nav_profile)
        val messagesButton: ImageButton = findViewById(R.id.nav_messages)
        val notificationsButton: ImageButton = findViewById(R.id.notification_button)

        homeButton.setOnClickListener {
            if (isShowingUserPosts) {
                loadCommunityFeed()
            } else {
                loadCommunityFeed()
            }
        }

        profileButton.setOnClickListener {
            navigateToProfile()
        }

        searchButton.setOnClickListener { navigateToSearchItems() }
        messagesButton.setOnClickListener { navigateToMessages() }
        notificationsButton.setOnClickListener { navigateToNotifications() }
        floatingReportButton.setOnClickListener { navigateToReportItem() }
    }

    private fun setupUI() {
        welcomeText.text = "Welcome, ${user.name}"
    }

    private fun loadCommunityFeed() {
        showLoadingStates()

        Handler(Looper.getMainLooper()).postDelayed({
            isShowingUserPosts = false
            feedItems.clear()

            feedTitleText.text = "Community Feed"

            val dbItems = databaseRepository.getAllItems()

            dbItems.forEach { dbItem ->
                val likeCount = databaseRepository.getLikeCount(dbItem.id.toString())
                val isLiked = databaseRepository.isLikedByUser(dbItem.id.toString(), user.email)
                val commentCount = databaseRepository.getCommentCount(dbItem.id.toString())

                // Get the first image if available
                val firstImage = if (dbItem.images.isNotEmpty() && dbItem.images[0].isNotEmpty()) {
                    dbItem.images[0]
                } else {
                    ""
                }

                // IMPROVISED: Better contact email handling with multiple fallbacks
                val contactEmail = when {
                    dbItem.contactEmail.isNotEmpty() -> dbItem.contactEmail
                    dbItem.reportedBy.contains("@") -> dbItem.reportedBy
                    else -> {
                        val cleanName = dbItem.reportedBy.replace(" ", ".").lowercase()
                        "$cleanName@student.uptm.edu.my"
                    }
                }

                // IMPROVISED: Check if it's user's own post
                val isOwnPost = dbItem.reportedBy.equals(user.name, ignoreCase = true) ||
                        dbItem.contactEmail.equals(user.email, ignoreCase = true)

                feedItems.add(FeedItem(
                    id = dbItem.id,
                    itemId = dbItem.id.toString(),
                    title = dbItem.title,
                    description = dbItem.description,
                    category = dbItem.category,
                    location = dbItem.location,
                    date = dbItem.date,
                    time = dbItem.time,
                    postTime = dbItem.timeAgo,
                    status = dbItem.status,
                    image = firstImage,
                    user = dbItem.reportedBy,
                    userAvatar = dbItem.reportedBy.take(1).uppercase(), // IMPROVISED: Generate avatar from first letter
                    likes = likeCount,
                    comments = commentCount,
                    message = "",
                    shares = 0,
                    isLiked = isLiked,
                    isOwnPost = isOwnPost, // IMPROVISED: Better ownership check
                ))
            }

            // IMPROVISED: Sort by latest posts first
            feedItems.sortByDescending { it.id }

            displayFeedItems()
            hideLoadingStates()
        }, 800)
    }

    private fun loadUserPosts() {
        showLoadingStates()

        Handler(Looper.getMainLooper()).postDelayed({
            isShowingUserPosts = true
            feedItems.clear()

            feedTitleText.text = "My Reports"

            val userItems = databaseRepository.getItemsByUser(user.name)

            userItems.forEach { dbItem ->
                val likeCount = databaseRepository.getLikeCount(dbItem.id.toString())
                val isLiked = databaseRepository.isLikedByUser(dbItem.id.toString(), user.email)
                val commentCount = databaseRepository.getCommentCount(dbItem.id.toString())

                val firstImage = if (dbItem.images.isNotEmpty() && dbItem.images[0].isNotEmpty()) {
                    dbItem.images[0]
                } else ""

                feedItems.add(FeedItem(
                    id = dbItem.id,
                    itemId = dbItem.id.toString(),
                    title = dbItem.title,
                    description = dbItem.description,
                    category = dbItem.category,
                    location = dbItem.location,
                    date = dbItem.date,
                    time = dbItem.time,
                    postTime = dbItem.timeAgo,
                    status = dbItem.status,
                    image = firstImage,
                    user = dbItem.reportedBy,
                    userAvatar = "",
                    likes = likeCount,
                    comments = commentCount,
                    message = "",
                    shares = 0,
                    isLiked = isLiked,
                    isOwnPost = true,
                    contactEmail = dbItem.contactEmail
                ))
            }

            displayFeedItems()
            hideLoadingStates()
        }, 200)
    }

    private fun showLoadingStates() {
        emptyFeedState.visibility = View.GONE
        feedContainer.removeAllViews()

        val loadingLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 40, 0, 40)
            }
        }

        val progressBar = ProgressBar(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val loadingText = TextView(this).apply {
            text = "Loading feed..."
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@DashboardActivity, R.color.color_text_secondary))
            setTextAlignment(View.TEXT_ALIGNMENT_CENTER)
            setPadding(0, 16, 0, 0)
        }

        loadingLayout.addView(progressBar)
        loadingLayout.addView(loadingText)
        feedContainer.addView(loadingLayout)
    }

    private fun hideLoadingStates() {
        // Loading states are hidden when real data is displayed
    }

    private fun displayFeedItems() {
        feedContainer.removeAllViews()
        emptyFeedState.visibility = View.GONE

        if (feedItems.isEmpty()) {
            showEmptyFeedState()
            return
        }

        // Use adapter to populate views
        for (i in 0 until feedAdapter.count) {
            val itemView = feedAdapter.getView(i, null, feedContainer)
            feedContainer.addView(itemView)
        }
    }

    private fun showCommentsDialog(item: FeedItem) {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_comments)

        val commentsList = dialog.findViewById<LinearLayout>(R.id.comments_list)
        val commentInput = dialog.findViewById<EditText>(R.id.comment_input)
        val postCommentButton = dialog.findViewById<Button>(R.id.post_comment_button)

        loadComments(item.itemId, commentsList)

        postCommentButton.setOnClickListener {
            val commentText = commentInput.text.toString().trim()
            if (commentText.isNotEmpty()) {
                postComment(item.itemId, commentText, commentsList)
                commentInput.text.clear()
            }
        }

        dialog.show()
    }

    private fun loadComments(itemId: String, commentsList: LinearLayout) {
        val comments = databaseRepository.getComments(itemId)

        commentsList.removeAllViews()

        for (comment in comments) {
            val commentView = LayoutInflater.from(this).inflate(R.layout.item_comment, commentsList, false)

            val userName = commentView.findViewById<TextView>(R.id.user_name)
            val commentText = commentView.findViewById<TextView>(R.id.comment_text)
            val commentTime = commentView.findViewById<TextView>(R.id.comment_time)

            userName.text = comment.userName
            commentText.text = comment.commentText
            commentTime.text = comment.timeAgo

            commentsList.addView(commentView)
        }
    }

    private fun postComment(itemId: String, commentText: String, commentsList: LinearLayout) {
        databaseRepository.addComment(itemId, user.email, user.name, commentText)
        loadComments(itemId, commentsList)
    }

    private fun showEmptyFeedState() {
        emptyFeedState.visibility = View.VISIBLE

        val emptyTitle = emptyFeedState.findViewById<TextView>(R.id.empty_title)
        val emptyDescription = emptyFeedState.findViewById<TextView>(R.id.empty_description)
        val reportButton = emptyFeedState.findViewById<Button>(R.id.report_button)

        if (isShowingUserPosts) {
            emptyTitle.text = "No reports yet"
            emptyDescription.text = "You haven't reported any lost or found items yet."
        } else {
            emptyTitle.text = "No posts yet"
            emptyDescription.text = "Be the first to report a lost or found item!"
        }

        reportButton.setOnClickListener {
            navigateToReportItem()
        }
    }

    private fun navigateToProfile() {
        try {
            val intent = Intent(this, ProfileActivity::class.java)
            intent.putExtra("USER_NAME", user.name)
            intent.putExtra("USER_ROLE", user.role)
            intent.putExtra("USER_EMAIL", user.email)
            intent.putExtra("USER_ID", user.studentId)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Error opening profile: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToNotifications() {
        try {
            val intent = Intent(this, NotificationsActivity::class.java)
            intent.putExtra("USER_NAME", user.name)
            intent.putExtra("USER_ROLE", user.role)
            intent.putExtra("USER_EMAIL", user.email)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Error opening notifications: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToSearchItems() {
        val intent = Intent(this, SearchItemsActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        startActivity(intent)
    }

    private fun navigateToReportItem() {
        val intent = Intent(this, ReportItemActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        startActivity(intent)
    }

    private fun navigateToMessages() {
        val intent = Intent(this, MessagesActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_EMAIL", user.email)
        startActivity(intent)
    }

    override fun onResume() {
        super.onResume()
        loadCommunityFeed()
    }
}