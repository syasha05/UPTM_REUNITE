package com.example.reunitetest

import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.reunitetest.data.DatabaseRepository
import com.example.reunitetest.data.User
import java.io.File

class SearchItemsActivity : AppCompatActivity() {

    private val items = mutableListOf<DatabaseRepository.Item>()
    private val filteredItems = mutableListOf<DatabaseRepository.Item>()

    // UI References
    private lateinit var searchEditText: EditText
    private lateinit var filtersCard: CardView
    private lateinit var itemsContainer: LinearLayout
    private lateinit var resultsCountText: TextView

    private lateinit var badgeText: TextView
    private lateinit var categorySpinner: Spinner
    private lateinit var locationSpinner: Spinner
    private lateinit var lostButton: Button
    private lateinit var foundButton: Button

    private lateinit var user: User

    private var categoryFilter = ""
    private var locationFilter = ""
    private var statusFilter = ""

    // Database
    private lateinit var databaseRepository: DatabaseRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_items)

        databaseRepository = DatabaseRepository.getInstance(this)
        initializeUserData()
        initializeViews()
        setupBottomNavigation()
        setupSpinners()
        setupFilterButtons()
        loadData()
        updateResults()
    }

    private fun initializeUserData() {
        val userName = intent.getStringExtra("USER_NAME") ?: "user"
        val userRole = intent.getStringExtra("USER_ROLE") ?: "student"
        val userEmail = intent.getStringExtra("USER_EMAIL") ?: "${userName.replace(" ", ".").lowercase()}@student.uptm.edu.my"

        user = User(
            name = userName,
            role = userRole,
            email = userEmail,
            studentId = "STU${(10000..99999).random()}"
        )
    }

    private fun initializeViews() {
        searchEditText = findViewById(R.id.search_edittext)
        filtersCard = findViewById(R.id.filters_card)
        itemsContainer = findViewById(R.id.items_container)
        resultsCountText = findViewById(R.id.results_count_text)
        badgeText = findViewById(R.id.badge_text)
        categorySpinner = findViewById(R.id.category_spinner)
        locationSpinner = findViewById(R.id.location_spinner)
        lostButton = findViewById(R.id.lost_button)
        foundButton = findViewById(R.id.found_button)

        searchEditText.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                updateResults()
            }
        })

        val filterButton: ImageButton = findViewById(R.id.filter_button)
        filterButton.setOnClickListener {
            filtersCard.visibility =
                if (filtersCard.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }

    private fun setupBottomNavigation() {
        val homeButton: ImageButton = findViewById(R.id.nav_home)
        val searchButton: ImageButton = findViewById(R.id.nav_search)
        val profileButton: ImageButton = findViewById(R.id.nav_profile)
        val messagesButton: ImageButton = findViewById(R.id.nav_messages)

        homeButton.setOnClickListener {
            navigateToHome()
        }

        searchButton.setOnClickListener {
            // Already on search page, refresh with loading animation
            loadData()
            updateResults()
        }

        profileButton.setOnClickListener {
            navigateToProfile()
        }
        messagesButton.setOnClickListener {
            navigateToMessages()
        }
    }

    private fun loadData() {
        showLoadingStates()

        Handler(Looper.getMainLooper()).postDelayed({
            items.clear()
            items.addAll(databaseRepository.getAllItems())
            filteredItems.clear()
            filteredItems.addAll(items)
            hideLoadingStates()
        }, 800)
    }

    private fun showLoadingStates() {
        itemsContainer.removeAllViews()

        val loadingLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 40, 0, 40)
            }
        }

        val progressBar = ProgressBar(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val loadingText = TextView(this).apply {
            text = "Loading search results..."
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@SearchItemsActivity, R.color.color_text_secondary))
            setTextAlignment(View.TEXT_ALIGNMENT_CENTER)
            setPadding(0, 16, 0, 0)
        }

        loadingLayout.addView(progressBar)
        loadingLayout.addView(loadingText)
        itemsContainer.addView(loadingLayout)
    }

    private fun hideLoadingStates() {
        // Loading states are hidden when real data is displayed
    }

    private fun setupSpinners() {
        val categories = arrayOf("All Categories", "Electronics", "Personal Items", "Documents", "Keys", "Jewelry", "Clothing", "Books/Stationery", "Sports Equipment", "Other")
        val categoryAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = categoryAdapter

        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                categoryFilter = if (position == 0) "" else categories[position]
                updateResults()
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        val locations = arrayOf("All Locations", "Library Level 1", "Library Level 2", "Library Level 3", "Cafeteria", "Lecture Hall A", "Lecture Hall B", "Computer Lab 1", "Computer Lab 2", "Parking Area A", "Parking Area B", "Main Entrance", "Student Center", "Administration Building", "Sports Complex")
        val locationAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, locations)
        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        locationSpinner.adapter = locationAdapter

        locationSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                locationFilter = if (position == 0) "" else locations[position]
                updateResults()
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    private fun setupFilterButtons() {
        lostButton.setOnClickListener {
            statusFilter = if (statusFilter == "lost") "" else "lost"
            updateButtonStyles()
            updateResults()
        }

        foundButton.setOnClickListener {
            statusFilter = if (statusFilter == "found") "" else "found"
            updateButtonStyles()
            updateResults()
        }

        val clearButton: Button = findViewById(R.id.clear_button)
        clearButton.setOnClickListener {
            categorySpinner.setSelection(0)
            locationSpinner.setSelection(0)
            statusFilter = ""
            searchEditText.text.clear()
            updateButtonStyles()
            updateResults()
        }
    }

    private fun updateButtonStyles() {
        val defaultColor = ContextCompat.getColor(this, R.color.color_text_hint)
        val lostColor = ContextCompat.getColor(this, R.color.color_lost)
        val foundColor = ContextCompat.getColor(this, R.color.color_found)

        lostButton.setBackgroundColor(defaultColor)
        foundButton.setBackgroundColor(defaultColor)

        when (statusFilter) {
            "lost" -> {
                lostButton.setBackgroundColor(lostColor)
                lostButton.setTextColor(ContextCompat.getColor(this, android.R.color.white))
                foundButton.setTextColor(ContextCompat.getColor(this, R.color.color_black))
            }
            "found" -> {
                foundButton.setBackgroundColor(foundColor)
                foundButton.setTextColor(ContextCompat.getColor(this, android.R.color.white))
                lostButton.setTextColor(ContextCompat.getColor(this, R.color.color_black))
            }
            else -> {
                lostButton.setTextColor(ContextCompat.getColor(this, R.color.color_black))
                foundButton.setTextColor(ContextCompat.getColor(this, R.color.color_black))
            }
        }
    }

    private fun updateResults() {
        showLoadingStates()

        Handler(Looper.getMainLooper()).postDelayed({
            filteredItems.clear()

            val dbItems = databaseRepository.searchItems(
                query = searchEditText.text.toString(),
                category = categoryFilter,
                location = locationFilter,
                status = statusFilter
            )

            filteredItems.addAll(dbItems)
            displayItems()
            hideLoadingStates()
        }, 200) // Shorter delay for search results
    }

    private fun displayItems() {
        itemsContainer.removeAllViews()

        val lostCount = items.count { it.status == "lost" }
        val foundCount = items.count { it.status == "found" }
        resultsCountText.text = "${filteredItems.size} items found"

        // FIX: Get the badge text view properly
        val badgeText = findViewById<TextView>(R.id.badge_text)
        badgeText.text = "$lostCount lost, $foundCount found"

        if (filteredItems.isEmpty()) {
            val emptyView = LayoutInflater.from(this).inflate(R.layout.item_empty_search, itemsContainer, false)
            itemsContainer.addView(emptyView)
            return
        }

        for (item in filteredItems) {
            val itemView = LayoutInflater.from(this).inflate(R.layout.item_feed, itemsContainer, false)

            val userAvatar = itemView.findViewById<TextView>(R.id.user_avatar)
            val userName = itemView.findViewById<TextView>(R.id.user_name)
            val postTime = itemView.findViewById<TextView>(R.id.post_time)
            val itemTitle = itemView.findViewById<TextView>(R.id.item_title)
            val itemDescription = itemView.findViewById<TextView>(R.id.item_description)
            val itemLocation = itemView.findViewById<TextView>(R.id.item_location)
            val itemDate = itemView.findViewById<TextView>(R.id.item_date)
            val itemTime = itemView.findViewById<TextView>(R.id.item_time)
            val statusBadge = itemView.findViewById<TextView>(R.id.status_badge)
            val likeButton = itemView.findViewById<ImageButton>(R.id.like_button)
            val commentButton = itemView.findViewById<ImageButton>(R.id.comment_button)
            val shareButton = itemView.findViewById<ImageButton>(R.id.share_button)
            val messageButton = itemView.findViewById<ImageButton>(R.id.message_button)
            val likesCount = itemView.findViewById<TextView>(R.id.likes_count)
            val commentsCount = itemView.findViewById<TextView>(R.id.comments_count)
            val itemImage = itemView.findViewById<ImageView>(R.id.item_image)
            val flagButton = itemView.findViewById<ImageButton>(R.id.flag_button)

            // Set item data
            userAvatar.text = item.reportedBy.take(1).uppercase()
            userName.text = item.reportedBy
            postTime.text = item.timeAgo
            itemTitle.text = item.title
            itemDescription.text = item.description
            itemLocation.text = "📍 ${item.location}"
            itemDate.text = "📅 ${item.date}"
            itemTime.text = "⏰ ${item.time}"

            // Get like and comment counts
            val likeCount = databaseRepository.getLikeCount(item.id.toString())
            val commentCount = databaseRepository.getCommentCount(item.id.toString())
            val isLiked = databaseRepository.isLikedByUser(item.id.toString(), user.email)

            likesCount.text = likeCount.toString()
            commentsCount.text = commentCount.toString()

            // Load image using Glide
            val firstImage = if (item.images.isNotEmpty() && item.images[0].isNotEmpty()) {
                item.images[0]
            } else {
                ""
            }

            // Load image
            if (firstImage.isNotEmpty()) {
                itemImage.visibility = View.VISIBLE
                try {
                    if (firstImage.startsWith("/")) {
                        val imageFile = File(firstImage)
                        if (imageFile.exists()) {
                            Glide.with(this)
                                .load(imageFile)
                                .placeholder(R.drawable.ic_placeholder)
                                .error(R.drawable.ic_placeholder)
                                .centerCrop()
                                .into(itemImage)
                        } else {
                            itemImage.visibility = View.GONE
                        }
                    } else if (firstImage.startsWith("data:image")) {
                        Glide.with(this)
                            .load(firstImage)
                            .placeholder(R.drawable.ic_placeholder)
                            .error(R.drawable.ic_placeholder)
                            .centerCrop()
                            .into(itemImage)
                    } else {
                        itemImage.visibility = View.GONE
                    }
                } catch (e: Exception) {
                    itemImage.visibility = View.GONE
                    e.printStackTrace()
                }
            } else {
                itemImage.visibility = View.GONE
            }

            // Set status badge
            statusBadge.text = item.status.uppercase()
            statusBadge.setBackgroundColor(
                ContextCompat.getColor(this,
                    if (item.status == "lost") R.color.color_lost else R.color.color_found
                )
            )

            // Update like button state
            updateLikeButton(likeButton, isLiked)

            // Set click listeners for social actions
            likeButton.setOnClickListener {
                toggleLike(item, likeButton, likesCount, isLiked)
            }

            commentButton.setOnClickListener {
                showCommentsDialog(item)
            }

            shareButton.setOnClickListener {
                shareItem(item)
            }

            // NEW: Flag button functionality
            flagButton.setOnClickListener {
                showFlagDialog(item)
            }

            itemsContainer.addView(itemView)
        }
    }

    private fun toggleLike(item: DatabaseRepository.Item, likeButton: ImageButton, likesCount: TextView, isLiked: Boolean) {
        if (isLiked) {
            databaseRepository.removeLike(item.id.toString(), user.email)
            likesCount.text = (likesCount.text.toString().toInt() - 1).toString()
            updateLikeButton(likeButton, false)
        } else {
            databaseRepository.addLike(item.id.toString(), user.email)
            likesCount.text = (likesCount.text.toString().toInt() + 1).toString()
            updateLikeButton(likeButton, true)
        }
    }

    private fun updateLikeButton(likeButton: ImageButton, isLiked: Boolean) {
        if (isLiked) {
            likeButton.setImageResource(android.R.drawable.btn_star_big_on)
            likeButton.setColorFilter(ContextCompat.getColor(this, R.color.color_accent))
        } else {
            likeButton.setImageResource(android.R.drawable.btn_star_big_off)
            likeButton.setColorFilter(ContextCompat.getColor(this, R.color.color_text_secondary))
        }
    }

    private fun showCommentsDialog(item: DatabaseRepository.Item) {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_comments)

        val commentsList = dialog.findViewById<LinearLayout>(R.id.comments_list)
        val commentInput = dialog.findViewById<EditText>(R.id.comment_input)
        val postCommentButton = dialog.findViewById<Button>(R.id.post_comment_button)

        loadComments(item.id.toString(), commentsList)

        postCommentButton.setOnClickListener {
            val commentText = commentInput.text.toString().trim()
            if (commentText.isNotEmpty()) {
                postComment(item.id.toString(), commentText, commentsList)
                commentInput.text.clear()
            }
        }

        dialog.show()
    }

    private fun loadComments(itemId: String, commentsList: LinearLayout) {
        val comments = databaseRepository.getComments(itemId)

        commentsList.removeAllViews()

        for (comment in comments) {
            val commentView = LayoutInflater.from(this).inflate(R.layout.item_comment, commentsList, false)

            val userName = commentView.findViewById<TextView>(R.id.user_name)
            val commentText = commentView.findViewById<TextView>(R.id.comment_text)
            val commentTime = commentView.findViewById<TextView>(R.id.comment_time)

            userName.text = comment.userName
            commentText.text = comment.commentText
            commentTime.text = comment.timeAgo

            commentsList.addView(commentView)
        }
    }

    private fun postComment(itemId: String, commentText: String, commentsList: LinearLayout) {
        databaseRepository.addComment(itemId, user.email, user.name, commentText)
        loadComments(itemId, commentsList)
    }

    private fun shareItem(item: DatabaseRepository.Item) {
        val shareMessage = """
            ${if (item.status.lowercase() == "lost") "🚨 LOST ITEM" else "🎉 FOUND ITEM"}
            
            📋 ${item.title}
            📍 ${item.location}
            📅 ${item.date} at ${item.time}
            
            ${item.description}
            
            👤 Contact: ${item.reportedBy}
            
            ${if (item.status.lowercase() == "lost") "Please help find this item!" else "Please contact if this is yours!"}
        """.trimIndent()

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "${item.status.uppercase()}: ${item.title}")
            putExtra(Intent.EXTRA_TEXT, shareMessage)
        }

        startActivity(Intent.createChooser(shareIntent,
            if (item.status.lowercase() == "lost") "Share Lost Item" else "Share Found Item"
        ))
    }

    // NEW: Contact button functionality
    private fun setupContactButton(item: DatabaseRepository.Item, contactButton: Button) {
        // Check if it's user's own post
        val isOwnPost = item.reportedBy.equals(user.name, ignoreCase = true) ||
                item.contactEmail.equals(user.email, ignoreCase = true)

        if (isOwnPost) {
            contactButton.visibility = View.GONE
            return
        }

        contactButton.visibility = View.VISIBLE

        // Change button text based on item status
        val buttonText = if (item.status.lowercase() == "found") {
            "📋 Claim This Item"
        } else {
            "💬 Contact Poster"
        }

        contactButton.text = buttonText
        contactButton.setOnClickListener {
            if (item.status.lowercase() == "found") {
                showClaimOptions(item)
            } else {
                showContactOptions(item)
            }
        }
    }

    // NEW: Claim options for found items
    private fun showClaimOptions(item: DatabaseRepository.Item) {
        val options = arrayOf("💬 Contact First", "📋 Submit Claim Proof", "🔍 How to Verify?")

        AlertDialog.Builder(this)
            .setTitle("Claim Item: ${item.title}")
            .setMessage("Untuk barang yang dijumpai, sila hubungi poster dahulu atau hantar bukti pemilikan")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> showContactOptions(item)
                    1 -> showVerificationDialog(item)
                    2 -> showVerificationGuide()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // NEW: Contact options
    private fun showContactOptions(item: DatabaseRepository.Item) {
        val options = arrayOf("📧 Send Email", "📋 Copy Email", "💬 Message in App")

        AlertDialog.Builder(this)
            .setTitle("Contact ${item.reportedBy}")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> sendEmailToPoster(item)
                    1 -> copyContactInfo(item)
                    2 -> openInAppChat(item)  // NEW: In-app messaging
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // NEW: Send email to poster
    private fun sendEmailToPoster(item: DatabaseRepository.Item) {
        var contactEmail = item.contactEmail

        // If contact email is empty or invalid, create a fallback
        if (contactEmail.isEmpty() || !contactEmail.contains("@")) {
            contactEmail = "${item.reportedBy.replace(" ", ".").lowercase()}@student.uptm.edu.my"
        }

        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$contactEmail")
            putExtra(Intent.EXTRA_SUBJECT, "Regarding your ${item.status} item: ${item.title}")
            putExtra(Intent.EXTRA_TEXT, """
            Hello ${item.reportedBy},
            
            I saw your ${item.status} item "${item.title}" on ReUnite App.
            
            Item Details:
            - Category: ${item.category}
            - Location: ${item.location} 
            - Date: ${item.date} at ${item.time}
            
            ${if (item.status.lowercase() == "lost")
                "I think I might have found your item!"
            else
                "I believe this might be my lost item!"
            }
            
            Please contact me so we can discuss further.
            
            Best regards,
            ${user.name}
        """.trimIndent())
        }

        try {
            startActivity(Intent.createChooser(emailIntent, "Send Email via..."))
        } catch (e: Exception) {
            Toast.makeText(this, "No email app found", Toast.LENGTH_SHORT).show()
        }
    }

    // NEW: Copy contact info
    private fun copyContactInfo(item: DatabaseRepository.Item) {
        val contactEmail = if (item.contactEmail.isNotEmpty()) item.contactEmail else "Email not available"

        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Contact Email", contactEmail)
        clipboard.setPrimaryClip(clip)

        Toast.makeText(this, "Contact email copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    // NEW: In-app messaging system
    private fun openInAppChat(item: DatabaseRepository.Item) {
        val dialog = Dialog(this)

        // Create chat dialog programmatically
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 20, 30, 20)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val title = TextView(this).apply {
            text = "💬 Message ${item.reportedBy}"
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 15)
            setTextColor(ContextCompat.getColor(this@SearchItemsActivity, R.color.color_primary))
        }

        val messageInput = EditText(this).apply {
            hint = "Type your message to ${item.reportedBy}..."
            setLines(4)
            setMinLines(4)
            gravity = Gravity.TOP
            setPadding(20, 15, 20, 15)
            setBackgroundResource(android.R.drawable.edit_text)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 15)
            }
        }

        val buttonLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val cancelButton = Button(this).apply {
            text = "Cancel"
            setBackgroundColor(ContextCompat.getColor(this@SearchItemsActivity, R.color.color_text_hint))
            setTextColor(ContextCompat.getColor(this@SearchItemsActivity, android.R.color.white))
            setOnClickListener { dialog.dismiss() }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = 8
            }
        }

        val sendButton = Button(this).apply {
            text = "Send Message"
            setBackgroundColor(ContextCompat.getColor(this@SearchItemsActivity, R.color.color_primary))
            setTextColor(ContextCompat.getColor(this@SearchItemsActivity, android.R.color.white))
            setOnClickListener {
                val message = messageInput.text.toString().trim()
                if (message.isNotEmpty()) {
                    sendInAppMessage(item, message)
                    Toast.makeText(this@SearchItemsActivity, "Message sent to ${item.reportedBy}!", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                } else {
                    Toast.makeText(this@SearchItemsActivity, "Please type a message", Toast.LENGTH_SHORT).show()
                }
            }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = 8
            }
        }

        buttonLayout.addView(cancelButton)
        buttonLayout.addView(sendButton)

        layout.addView(title)
        layout.addView(messageInput)
        layout.addView(buttonLayout)

        dialog.setContentView(layout)
        dialog.window?.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        dialog.show()
    }

    // NEW: Send in-app message (store in database)
    private fun sendInAppMessage(item: DatabaseRepository.Item, messageText: String) {
        // Store message in database
        databaseRepository.addInAppMessage(
            senderEmail = user.email,
            senderName = user.name,
            receiverName = item.reportedBy,
            itemId = item.id.toLong(),
            messageText = messageText
        )

        Toast.makeText(this, "Message sent to ${item.reportedBy}!", Toast.LENGTH_SHORT).show()
    }

    // NEW: Flag dialog
    private fun showFlagDialog(item: DatabaseRepository.Item) {
        AlertDialog.Builder(this)
            .setTitle("Report Item")
            .setMessage("Why are you reporting this item?")
            .setPositiveButton("Inappropriate Content") { dialog, _ ->
                flagItem(item, "Inappropriate Content")
                dialog.dismiss()
            }
            .setNeutralButton("False Information") { dialog, _ ->
                flagItem(item, "False Information")
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    // In SearchItemsActivity.kt - UPDATE the flagItem method:

    private fun flagItem(item: DatabaseRepository.Item, reason: String) {
        val result = databaseRepository.flagItem(item.id)
        if (result > 0) {
            Toast.makeText(this, "Item reported for review", Toast.LENGTH_SHORT).show()
            databaseRepository.createNotification(
                type = "flag",
                title = "Item Flagged for Review",
                message = "Item '${item.title}' was flagged for: $reason",
                userId = "admin",
                category = item.category,
                location = item.location,
                itemId = item.id.toString()
            )
        } else {
            Toast.makeText(this, "Failed to report item", Toast.LENGTH_SHORT).show()
        }
    }

    // NEW: Verification dialog
    private fun showVerificationDialog(item: DatabaseRepository.Item) {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_verification)

        val proofInput = dialog.findViewById<EditText>(R.id.proof_input)
        val submitButton = dialog.findViewById<Button>(R.id.submit_button)
        val cancelButton = dialog.findViewById<Button>(R.id.cancel_button)

        submitButton.setOnClickListener {
            val proof = proofInput.text.toString().trim()
            if (proof.isNotEmpty()) {
                databaseRepository.addVerificationRequest(
                    itemId = item.id,
                    claimantEmail = user.email,
                    proofDescription = proof
                )
                Toast.makeText(this, "Tuntutan dihantar untuk semakan", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Sila berikan bukti pemilikan", Toast.LENGTH_SHORT).show()
            }
        }

        cancelButton.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    // NEW: Verification guide
    private fun showVerificationGuide() {
        AlertDialog.Builder(this)
            .setTitle("🔍 Cara Mengesahkan Pemilikan")
            .setMessage("""
            Untuk mengesahkan barang adalah milik anda, sediakan:
            
            ✅ Resit pembelian
            ✅ Gambar barang dengan anda
            ✅ Butiran khusus (serial number, etc.)
            ✅ Sebarang bukti pemilikan lain
            
            Selepas hantar bukti, poster akan hubungi anda untuk pengesahan.
            
            Tips: Sentiasa berjumpa di tempat selamat & awam!
        """.trimIndent())
            .setPositiveButton("Faham", null)
            .show()
    }

    private fun navigateToHome() {
        val intent = Intent(this, DashboardActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        startActivity(intent)
    }

    private fun navigateToProfile() {
        val intent = Intent(this, ProfileActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_ROLE", user.role)
        intent.putExtra("USER_EMAIL", user.email)
        intent.putExtra("USER_ID", user.studentId)
        startActivity(intent)
    }

    private fun navigateToMessages() {
        val intent = Intent(this, MessagesActivity::class.java)
        intent.putExtra("USER_NAME", user.name)
        intent.putExtra("USER_EMAIL", user.email)
        startActivity(intent)
    }

    override fun onResume() {
        super.onResume()
        loadData()
        updateResults()
    }
}