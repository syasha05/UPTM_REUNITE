package com.example.reunitetest

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "FCMService"
        private const val CHANNEL_ID_MESSAGES = "messages_channel"
        private const val CHANNEL_ID_REPORTS = "reports_channel"
        private const val CHANNEL_ID_STATUS = "status_channel"
        private const val CHANNEL_ID_GENERAL = "general_channel"
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "Refreshed FCM token: $token")
        
        // Store the token in SharedPreferences
        getSharedPreferences("FCM", Context.MODE_PRIVATE)
            .edit()
            .putString("fcm_token", token)
            .apply()
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        
        Log.d(TAG, "Message received from: ${message.from}")
        
        // Check if message contains data payload
        message.data.isNotEmpty().let {
            Log.d(TAG, "Message data payload: ${message.data}")
            handleDataPayload(message.data)
        }
        
        // Check if message contains notification payload
        message.notification?.let {
            Log.d(TAG, "Message Notification Body: ${it.body}")
            sendNotification(
                title = it.title ?: "ReUnite",
                body = it.body ?: "",
                type = message.data["type"] ?: "general"
            )
        }
    }

    private fun handleDataPayload(data: Map<String, String>) {
        val type = data["type"] ?: "general"
        val title = data["title"] ?: "ReUnite"
        val body = data["body"] ?: data["message"] ?: ""
        val itemId = data["itemId"]
        val category = data["category"]
        val location = data["location"]
        
        sendNotification(title, body, type, itemId, category, location)
    }

    private fun sendNotification(
        title: String,
        body: String,
        type: String = "general",
        itemId: String? = null,
        category: String? = null,
        location: String? = null
    ) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        // Create notification channels for Android O and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannels(notificationManager)
        }
        
        // Determine which channel to use based on notification type
        val channelId = when (type) {
            "message", "chat" -> CHANNEL_ID_MESSAGES
            "report", "upload" -> CHANNEL_ID_REPORTS
            "status_update", "found", "reunited" -> CHANNEL_ID_STATUS
            else -> CHANNEL_ID_GENERAL
        }
        
        // Create intent based on notification type
        val intent = createIntentForNotificationType(type, itemId, category, location)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        
        val pendingIntent = PendingIntent.getActivity(
            this, 
            System.currentTimeMillis().toInt(),
            intent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )
        
        // Get notification icon based on type
        val iconRes = getNotificationIcon(type)
        
        // Get notification sound
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        
        // Build notification
        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(iconRes)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
        
        // Add action buttons based on type
        when (type) {
            "message", "chat" -> {
                notificationBuilder.setCategory(NotificationCompat.CATEGORY_MESSAGE)
            }
            "report", "upload" -> {
                notificationBuilder.setCategory(NotificationCompat.CATEGORY_STATUS)
            }
            "status_update", "found", "reunited" -> {
                notificationBuilder.setCategory(NotificationCompat.CATEGORY_EVENT)
            }
        }
        
        // Show notification
        val notificationId = System.currentTimeMillis().toInt()
        notificationManager.notify(notificationId, notificationBuilder.build())
        
        Log.d(TAG, "Notification sent: $title - $body")
    }

    private fun createNotificationChannels(notificationManager: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Messages Channel
            val messagesChannel = NotificationChannel(
                CHANNEL_ID_MESSAGES,
                "Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for new chat messages"
                enableLights(true)
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(messagesChannel)
            
            // Reports Channel
            val reportsChannel = NotificationChannel(
                CHANNEL_ID_REPORTS,
                "Reports",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for new item reports"
                enableLights(true)
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(reportsChannel)
            
            // Status Updates Channel
            val statusChannel = NotificationChannel(
                CHANNEL_ID_STATUS,
                "Status Updates",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for item status changes (found, reunited)"
                enableLights(true)
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(statusChannel)
            
            // General Channel
            val generalChannel = NotificationChannel(
                CHANNEL_ID_GENERAL,
                "General",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "General notifications"
                enableLights(true)
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(generalChannel)
        }
    }

    private fun createIntentForNotificationType(
        type: String,
        itemId: String?,
        category: String?,
        location: String?
    ): Intent {
        return when (type) {
            "message", "chat" -> {
                // Open Messages Activity
                Intent(this, MessagesActivity::class.java).apply {
                    putExtra("NOTIFICATION_TYPE", type)
                    itemId?.let { putExtra("ITEM_ID", it) }
                }
            }
            "report", "upload" -> {
                // Open Dashboard (Feed)
                Intent(this, DashboardActivity::class.java).apply {
                    putExtra("NOTIFICATION_TYPE", type)
                    category?.let { putExtra("CATEGORY", it) }
                    location?.let { putExtra("LOCATION", it) }
                }
            }
            "status_update", "found", "reunited" -> {
                // Open Dashboard (Feed) and potentially scroll to item
                Intent(this, DashboardActivity::class.java).apply {
                    putExtra("NOTIFICATION_TYPE", type)
                    itemId?.let { putExtra("ITEM_ID", it) }
                }
            }
            else -> {
                // Default to main activity
                Intent(this, MainActivity::class.java)
            }
        }
    }

    private fun getNotificationIcon(type: String): Int {
        return when (type) {
            "message", "chat" -> R.drawable.ic_messagesfeed
            "report", "upload" -> R.drawable.ic_upload
            "status_update", "found", "reunited" -> R.drawable.ic_heart_outline
            else -> R.drawable.ic_launcher_foreground
        }
    }
}
