package com.example.reunitetest

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil.setContentView
import com.example.reunitetest.utils.NotificationHelper
import com.example.reunitetest.utils.FCMTokenManager

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        // Apply saved theme before calling super
        applyThemePreference()
        
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize notification channels
        NotificationHelper.createNotificationChannels(this)
        
        // Get and save FCM token
        FCMTokenManager.getAndSaveToken(this)

        // Wait for 2 seconds then navigate to LoginActivity
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish() // Close the splash activity
        }, 2000)
    }

    private fun applyThemePreference() {
        val sharedPreferences = getSharedPreferences("ReUnitePrefs", Context.MODE_PRIVATE)
        val isDarkMode = sharedPreferences.getBoolean("dark_mode", false)
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }
}